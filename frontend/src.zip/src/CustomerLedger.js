import React, { useMemo, useState } from "react";

function CustomerLedger({ setPage, goBack }) {
  const [selectedCustomer, setSelectedCustomer] =
    useState(null);

  const [search, setSearch] = useState("");

  const [showBills, setShowBills] =
    useState(false);

  const [refresh, setRefresh] = useState(0);

  // =====================================================
  // SAFE LOCAL STORAGE
  // =====================================================

  const loadArray = (key) => {
    try {
      const data = JSON.parse(
        localStorage.getItem(key) || "[]"
      );

      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  };

  // =====================================================
  // BILLS
  // =====================================================

  const bills = useMemo(() => {
    return loadArray("bills");
  }, [refresh]);

  // =====================================================
  // CUSTOMER PAYMENTS
  // =====================================================

  const customerPayments = useMemo(() => {
    return loadArray("customerPayments");
  }, [refresh]);

  // =====================================================
  // MONEY
  // =====================================================

  const money = (value) => {
    return `₹${Number(value || 0).toFixed(2)}`;
  };

  // =====================================================
  // CUSTOMER NAME
  // =====================================================

  const getCustomerName = (item) => {
    return String(
      item?.customer ||
        item?.customerName ||
        item?.name ||
        ""
    ).trim();
  };

  // =====================================================
  // CUSTOMER MOBILE
  // =====================================================

  const getCustomerMobile = (item) => {
    return String(
      item?.mobile ||
        item?.phone ||
        item?.customerMobile ||
        ""
    ).trim();
  };

  // =====================================================
  // BILL TOTAL
  // =====================================================

  const getBillTotal = (bill) => {
    if (bill?.total != null) {
      return Number(bill.total) || 0;
    }

    if (bill?.grandTotal != null) {
      return Number(bill.grandTotal) || 0;
    }

    if (bill?.totalAmount != null) {
      return Number(bill.totalAmount) || 0;
    }

    if (bill?.amount != null) {
      return Number(bill.amount) || 0;
    }

    return 0;
  };

  // =====================================================
  // BILL UDHARI
  //
  // Billing में pendingAmount / udhari
  // actual bill Udhari माना जाएगा.
  // =====================================================

  const getBillUdhari = (bill) => {
    if (bill?.pendingAmount != null) {
      return Number(bill.pendingAmount) || 0;
    }

    if (bill?.udhari != null) {
      return Number(bill.udhari) || 0;
    }

    if (bill?.creditAmount != null) {
      return Number(bill.creditAmount) || 0;
    }

    if (bill?.pending != null) {
      return Number(bill.pending) || 0;
    }

    return 0;
  };

  // =====================================================
  // BILL PAID
  // =====================================================

  const getBillPaid = (bill) => {
    const total = getBillTotal(bill);
    const udhari = getBillUdhari(bill);

    return Math.max(total - udhari, 0);
  };

  // =====================================================
  // PAYMENT AMOUNT
  // =====================================================

  const getPaymentAmount = (payment) => {
    return Number(
      payment?.amount ||
        payment?.paidAmount ||
        payment?.payment ||
        0
    );
  };

  // =====================================================
  // CUSTOMER KEY
  // =====================================================

  const makeCustomerKey = (name, mobile) => {
    const cleanName = String(name || "")
      .trim()
      .toLowerCase();

    const cleanMobile = String(mobile || "")
      .trim();

    if (cleanName && cleanMobile) {
      return `${cleanName}_${cleanMobile}`;
    }

    return cleanName || "cash customer";
  };

  // =====================================================
  // ALL CUSTOMERS
  // =====================================================

  const customers = useMemo(() => {
    const map = new Map();

    // -----------------------------------------------
    // FROM BILLS
    // -----------------------------------------------

    bills.forEach((bill) => {
      const name = getCustomerName(bill);
      const mobile = getCustomerMobile(bill);

      if (!name) {
        return;
      }

      const key = makeCustomerKey(
        name,
        mobile
      );

      if (!map.has(key)) {
        map.set(key, {
          name,
          mobile,
        });
      }
    });

    // -----------------------------------------------
    // FROM PAYMENTS
    // -----------------------------------------------

    customerPayments.forEach((payment) => {
      const name = getCustomerName(payment);
      const mobile = getCustomerMobile(payment);

      if (!name) {
        return;
      }

      const key = makeCustomerKey(
        name,
        mobile
      );

      if (!map.has(key)) {
        map.set(key, {
          name,
          mobile,
        });
      }
    });

    return Array.from(map.values()).sort(
      (a, b) =>
        a.name.localeCompare(b.name)
    );
  }, [
    bills,
    customerPayments,
  ]);

  // =====================================================
  // SEARCH
  // =====================================================

  const filteredCustomers =
    customers.filter((customer) => {
      const text =
        `${customer.name} ${customer.mobile}`
          .toLowerCase();

      return text.includes(
        search.trim().toLowerCase()
      );
    });

  // =====================================================
  // SELECTED CUSTOMER BILLS
  // =====================================================

  const selectedBills = useMemo(() => {
    if (!selectedCustomer) {
      return [];
    }

    const name =
      selectedCustomer.name
        .trim()
        .toLowerCase();

    const mobile =
      selectedCustomer.mobile.trim();

    return bills.filter((bill) => {
      const billName =
        getCustomerName(bill)
          .toLowerCase();

      const billMobile =
        getCustomerMobile(bill);

      // ---------------------------------------------
      // Name + mobile match
      // ---------------------------------------------

      if (mobile) {
        return (
          billName === name &&
          billMobile === mobile
        );
      }

      // ---------------------------------------------
      // If mobile not available
      // ---------------------------------------------

      return billName === name;
    });
  }, [
    bills,
    selectedCustomer,
  ]);

  // =====================================================
  // SELECTED CUSTOMER PAYMENTS
  // =====================================================

  const selectedPayments = useMemo(() => {
    if (!selectedCustomer) {
      return [];
    }

    const name =
      selectedCustomer.name
        .trim()
        .toLowerCase();

    const mobile =
      selectedCustomer.mobile.trim();

    return customerPayments.filter(
      (payment) => {
        const paymentName =
          getCustomerName(payment)
            .toLowerCase();

        const paymentMobile =
          getCustomerMobile(payment);

        if (mobile) {
          return (
            paymentName === name &&
            paymentMobile === mobile
          );
        }

        return paymentName === name;
      }
    );
  }, [
    customerPayments,
    selectedCustomer,
  ]);

  // =====================================================
  // TOTAL BILL
  // =====================================================

  const totalBill = useMemo(() => {
    return selectedBills.reduce(
      (sum, bill) =>
        sum + getBillTotal(bill),
      0
    );
  }, [selectedBills]);

  // =====================================================
  // BILL PAID
  // =====================================================

  const billPaid = useMemo(() => {
    return selectedBills.reduce(
      (sum, bill) =>
        sum + getBillPaid(bill),
      0
    );
  }, [selectedBills]);

  // =====================================================
  // ORIGINAL BILL UDHARI
  // =====================================================

  const originalUdhari = useMemo(() => {
    return selectedBills.reduce(
      (sum, bill) =>
        sum + getBillUdhari(bill),
      0
    );
  }, [selectedBills]);

  // =====================================================
  // CUSTOMER PAYMENT
  // =====================================================

  const paymentPaid = useMemo(() => {
    return selectedPayments.reduce(
      (sum, payment) =>
        sum + getPaymentAmount(payment),
      0
    );
  }, [selectedPayments]);

  // =====================================================
  // CURRENT UDHARI
  // =====================================================

  const currentUdhari = Math.max(
    originalUdhari -
      paymentPaid,
    0
  );

  // =====================================================
  // SELECT CUSTOMER
  // =====================================================

  const openCustomer = (customer) => {
    setSelectedCustomer(customer);

    setShowBills(false);

    localStorage.setItem(
      "selectedCustomerForPayment",
      JSON.stringify(customer)
    );
  };

  // =====================================================
  // CLOSE CUSTOMER
  // =====================================================

  const closeCustomer = () => {
    setSelectedCustomer(null);

    setShowBills(false);
  };

  // =====================================================
  // OPEN CUSTOMER PAYMENT
  // =====================================================

  const openPayment = () => {
    if (!selectedCustomer) {
      return;
    }

    localStorage.setItem(
      "selectedCustomerForPayment",
      JSON.stringify(selectedCustomer)
    );

    if (typeof setPage === "function") {
      setPage("customerPayment");
    }
  };

  // =====================================================
  // PAYMENT UPDATED
  // =====================================================

  const refreshLedger = () => {
    setRefresh(
      (value) => value + 1
    );
  };

  // =====================================================
  // UI
  // =====================================================

  return (
    <div style={pageStyle}>

      {/* =================================================
          HEADER
      ================================================= */}

      <div style={headerStyle}>

        <div>
          <h1 style={headerTitle}>
            👥 Customer Ledger
          </h1>

          <div style={subtitle}>
            Customer-wise Bill, Payment &
            Udhari हिसाब
          </div>
        </div>

        <button
          type="button"
          onClick={goBack}
          style={backButton}
        >
          ⬅️ Dashboard
        </button>

      </div>

      {/* =================================================
          SEARCH
      ================================================= */}

      {!selectedCustomer && (
        <div style={cardStyle}>

          <input
            type="text"
            placeholder="🔎 Customer Name या Mobile Search करें..."
            value={search}
            onChange={(e) =>
              setSearch(
                e.target.value
              )
            }
            style={searchInput}
          />

        </div>
      )}

      {/* =================================================
          CUSTOMER LIST
      ================================================= */}

      {!selectedCustomer && (
        <div style={cardStyle}>

          <h2 style={sectionTitle}>
            👥 Customers
          </h2>

          {filteredCustomers.length ===
          0 ? (

            <div style={emptyBox}>
              ⚠️ कोई Customer उपलब्ध
              नहीं है।

              <br />
              <br />

              पहले Billing में
              Customer Name save करें।
            </div>

          ) : (

            <div style={customerGrid}>

              {filteredCustomers.map(
                (customer) => {

                  // -------------------------------------
                  // CUSTOMER BILLS
                  // -------------------------------------

                  const customerBills =
                    bills.filter(
                      (bill) => {

                        const billName =
                          getCustomerName(
                            bill
                          ).toLowerCase();

                        const billMobile =
                          getCustomerMobile(
                            bill
                          );

                        const customerName =
                          customer.name
                            .toLowerCase();

                        if (
                          customer.mobile
                        ) {
                          return (
                            billName ===
                              customerName &&
                            billMobile ===
                              customer.mobile
                          );
                        }

                        return (
                          billName ===
                          customerName
                        );
                      }
                    );

                  // -------------------------------------
                  // PURCHASE / BILL TOTAL
                  // -------------------------------------

                  const customerTotalBill =
                    customerBills.reduce(
                      (sum, bill) =>
                        sum +
                        getBillTotal(
                          bill
                        ),
                      0
                    );

                  // -------------------------------------
                  // BILL UDHARI
                  // -------------------------------------

                  const customerUdhari =
                    customerBills.reduce(
                      (sum, bill) =>
                        sum +
                        getBillUdhari(
                          bill
                        ),
                      0
                    );

                  // -------------------------------------
                  // PAYMENTS
                  // -------------------------------------

                  const customerPaid =
                    customerPayments
                      .filter(
                        (payment) => {

                          const paymentName =
                            getCustomerName(
                              payment
                            ).toLowerCase();

                          const paymentMobile =
                            getCustomerMobile(
                              payment
                            );

                          const customerName =
                            customer.name
                              .toLowerCase();

                          if (
                            customer.mobile
                          ) {
                            return (
                              paymentName ===
                                customerName &&
                              paymentMobile ===
                                customer.mobile
                            );
                          }

                          return (
                            paymentName ===
                            customerName
                          );
                        }
                      )
                      .reduce(
                        (
                          sum,
                          payment
                        ) =>
                          sum +
                          getPaymentAmount(
                            payment
                          ),
                        0
                      );

                  const pending =
                    Math.max(
                      customerUdhari -
                        customerPaid,
                      0
                    );

                  return (
                    <button
                      type="button"
                      key={makeCustomerKey(
                        customer.name,
                        customer.mobile
                      )}
                      onClick={() =>
                        openCustomer(
                          customer
                        )
                      }
                      style={{
                        ...customerCard,

                        borderLeft:
                          `5px solid ${
                            pending > 0
                              ? "#d32f2f"
                              : "#2e7d32"
                          }`,
                      }}
                    >

                      <div
                        style={
                          customerCardTop
                        }
                      >

                        <span
                          style={{
                            fontSize:
                              28,
                          }}
                        >
                          👤
                        </span>

                        <span
                          style={{
                            color:
                              "#1565c0",
                            fontWeight:
                              "bold",
                          }}
                        >
                          Open →
                        </span>

                      </div>

                      <div
                        style={{
                          fontSize:
                            17,
                          fontWeight:
                            "bold",
                          color:
                            "#222",
                        }}
                      >
                        {customer.name}
                      </div>

                      {customer.mobile && (
                        <div
                          style={
                            smallText
                          }
                        >
                          📱{" "}
                          {customer.mobile}
                        </div>
                      )}

                      <div
                        style={
                          smallText
                        }
                      >
                        Total Bill:{" "}
                        <b>
                          {money(
                            customerTotalBill
                          )}
                        </b>
                      </div>

                      <div
                        style={
                          smallText
                        }
                      >
                        Udhari:{" "}
                        <b
                          style={{
                            color:
                              "#d32f2f",
                          }}
                        >
                          {money(
                            customerUdhari
                          )}
                        </b>
                      </div>

                      <div
                        style={{
                          marginTop:
                            6,
                          fontWeight:
                            "bold",
                          color:
                            pending > 0
                              ? "#d32f2f"
                              : "#2e7d32",
                        }}
                      >
                        Current Udhari:{" "}
                        {money(
                          pending
                        )}
                      </div>

                    </button>
                  );
                }
              )}

            </div>
          )}

        </div>
      )}

      {/* =================================================
          CUSTOMER DETAIL
      ================================================= */}

      {selectedCustomer && (
        <div style={cardStyle}>

          {/* CUSTOMER HEADER */}

          <div
            style={customerHeader}
          >

            <div>

              <div
                style={{
                  fontSize:
                    12,
                  color:
                    "#777",
                }}
              >
                Selected Customer
              </div>

              <h2
                style={{
                  margin:
                    "3px 0",
                }}
              >
                👤{" "}
                {selectedCustomer.name}
              </h2>

              {selectedCustomer.mobile && (
                <div
                  style={{
                    fontSize:
                      13,
                    color:
                      "#666",
                  }}
                >
                  📱{" "}
                  {
                    selectedCustomer.mobile
                  }
                </div>
              )}

            </div>

            <div
              style={{
                textAlign:
                  "right",
              }}
            >

              <div
                style={{
                  color:
                    currentUdhari >
                    0
                      ? "#d32f2f"
                      : "#2e7d32",

                  fontSize:
                    21,

                  fontWeight:
                    "bold",
                }}
              >
                {money(
                  currentUdhari
                )}
              </div>

              <div
                style={{
                  fontSize:
                    11,
                  color:
                    "#777",
                }}
              >
                Current Udhari
              </div>

            </div>

          </div>

          {/* =================================================
              ACTION BUTTONS
          ================================================= */}

          <div
            style={
              actionBox
            }
          >

            <button
              type="button"
              onClick={
                closeCustomer
              }
              style={
                grayButton
              }
            >
              ⬅️ All Customers
            </button>

            <button
              type="button"
              onClick={
                openPayment
              }
              style={
                paymentButton
              }
            >
              💳 Customer Payment
            </button>

            <button
              type="button"
              onClick={
                refreshLedger
              }
              style={
                refreshButton
              }
            >
              🔄 Refresh
            </button>

          </div>

          {/* =================================================
              CUSTOMER SUMMARY
          ================================================= */}

          <div
            style={
              summaryGrid
            }
          >

            {/* =============================================
                CLICKABLE TOTAL BILL
            ============================================= */}

            <button
              type="button"
              onClick={() =>
                setShowBills(
                  true
                )
              }
              style={
                clickableSummaryButton
              }
            >
              <SummaryCard
                title="Total Bill"
                value={money(
                  totalBill
                )}
                color="#1565c0"
              />

              <div
                style={
                  clickHint
                }
              >
                👆 Bills देखें
              </div>
            </button>

            <SummaryCard
              title="Bill Paid"
              value={money(
                billPaid
              )}
              color="#2e7d32"
            />

            <SummaryCard
              title="Bill Udhari"
              value={money(
                originalUdhari
              )}
              color="#ef6c00"
            />

            <SummaryCard
              title="Customer Payment"
              value={money(
                paymentPaid
              )}
              color="#00838f"
            />

            <SummaryCard
              title="Current Udhari"
              value={money(
                currentUdhari
              )}
              color={
                currentUdhari >
                0
                  ? "#d32f2f"
                  : "#2e7d32"
              }
            />

          </div>

          {/* =================================================
              BILL DETAILS
              TOTAL BILL CLICK करने पर
            ================================================= */}

          {showBills && (
            <div
              style={
                billDetailBox
              }
            >

              <div
                style={
                  detailHeader
                }
              >

                <div>

                  <h3
                    style={{
                      margin:
                        0,
                    }}
                  >
                    🧾 Customer Bills
                  </h3>

                  <div
                    style={{
                      fontSize:
                        12,
                      color:
                        "#777",
                      marginTop:
                        3,
                    }}
                  >
                    {
                      selectedCustomer.name
                    }
                  </div>

                </div>

                <button
                  type="button"
                  onClick={() =>
                    setShowBills(
                      false
                    )
                  }
                  style={
                    closeButton
                  }
                >
                  ✖ Close
                </button>

              </div>

              {selectedBills.length ===
              0 ? (

                <div
                  style={
                    emptyBox
                  }
                >
                  इस Customer का कोई
                  Bill नहीं मिला।
                </div>

              ) : (

                <div
                  style={{
                    overflowX:
                      "auto",
                  }}
                >

                  <table
                    style={
                      tableStyle
                    }
                  >

                    <thead>

                      <tr>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Date
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Bill No.
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Total
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Paid
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Udhari
                        </th>

                      </tr>

                    </thead>

                    <tbody>

                      {selectedBills.map(
                        (
                          bill,
                          index
                        ) => {

                          const total =
                            getBillTotal(
                              bill
                            );

                          const udhari =
                            getBillUdhari(
                              bill
                            );

                          const paid =
                            getBillPaid(
                              bill
                            );

                          return (
                            <tr
                              key={
                                bill?.id ||
                                bill?.billNo ||
                                index
                              }
                            >

                              <td
                                style={
                                  tdStyle
                                }
                              >
                                {bill?.date ||
                                  bill?.billDate ||
                                  bill?.createdDate ||
                                  "-"}
                              </td>

                              <td
                                style={
                                  tdStyle
                                }
                              >
                                {bill?.billNo ||
                                  bill?.invoiceNo ||
                                  bill?.invoiceNumber ||
                                  bill?.id ||
                                  "-"}
                              </td>

                              <td
                                style={{
                                  ...tdStyle,
                                  color:
                                    "#1565c0",
                                  fontWeight:
                                    "bold",
                                }}
                              >
                                {money(
                                  total
                                )}
                              </td>

                              <td
                                style={{
                                  ...tdStyle,
                                  color:
                                    "#2e7d32",
                                  fontWeight:
                                    "bold",
                                }}
                              >
                                {money(
                                  paid
                                )}
                              </td>

                              <td
                                style={{
                                  ...tdStyle,
                                  color:
                                    udhari >
                                    0
                                      ? "#d32f2f"
                                      : "#2e7d32",
                                  fontWeight:
                                    "bold",
                                }}
                              >
                                {money(
                                  udhari
                                )}
                              </td>

                            </tr>
                          );
                        }
                      )}

                    </tbody>

                    {/* TOTAL */}

                    <tfoot>

                      <tr>

                        <td
                          colSpan="2"
                          style={{
                            ...tdStyle,
                            fontWeight:
                              "bold",
                            background:
                              "#f1f5f9",
                          }}
                        >
                          TOTAL
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            fontWeight:
                              "bold",
                            color:
                              "#1565c0",
                            background:
                              "#f1f5f9",
                          }}
                        >
                          {money(
                            totalBill
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            fontWeight:
                              "bold",
                            color:
                              "#2e7d32",
                            background:
                              "#f1f5f9",
                          }}
                        >
                          {money(
                            billPaid
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            fontWeight:
                              "bold",
                            color:
                              "#d32f2f",
                            background:
                              "#f1f5f9",
                          }}
                        >
                          {money(
                            originalUdhari
                          )}
                        </td>

                      </tr>

                    </tfoot>

                  </table>

                </div>
              )}

            </div>
          )}

          {/* =================================================
              CUSTOMER PAYMENTS
          ================================================= */}

          <h3
            style={
              subHeading
            }
          >
            💳 Customer Payments
          </h3>

          {selectedPayments.length ===
          0 ? (

            <div
              style={
                emptyBox
              }
            >
              इस Customer से कोई
              Payment जमा नहीं हुआ है।
            </div>

          ) : (

            <div
              style={{
                overflowX:
                  "auto",
              }}
            >

              <table
                style={
                  tableStyle
                }
              >

                <thead>

                  <tr>

                    <th
                      style={
                        thStyle
                      }
                    >
                      Date
                    </th>

                    <th
                      style={
                        thStyle
                      }
                    >
                      Time
                    </th>

                    <th
                      style={
                        thStyle
                      }
                    >
                      Mode
                    </th>

                    <th
                      style={
                        thStyle
                      }
                    >
                      Amount
                    </th>

                    <th
                      style={
                        thStyle
                      }
                    >
                      Note
                    </th>

                  </tr>

                </thead>

                <tbody>

                  {selectedPayments.map(
                    (
                      payment,
                      index
                    ) => (

                      <tr
                        key={
                          payment?.id ||
                          index
                        }
                      >

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {payment?.date ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {payment?.time ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {payment?.mode ||
                            payment?.paymentMode ||
                            "-"}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              "#2e7d32",
                            fontWeight:
                              "bold",
                          }}
                        >
                          {money(
                            getPaymentAmount(
                              payment
                            )
                          )}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {payment?.note ||
                            "-"}
                        </td>

                      </tr>

                    )
                  )}

                </tbody>

                <tfoot>

                  <tr>

                    <td
                      colSpan="3"
                      style={{
                        ...tdStyle,
                        fontWeight:
                          "bold",
                        background:
                          "#f1f5f9",
                      }}
                    >
                      TOTAL PAYMENT
                    </td>

                    <td
                      style={{
                        ...tdStyle,
                        fontWeight:
                          "bold",
                        color:
                          "#2e7d32",
                        background:
                          "#f1f5f9",
                      }}
                    >
                      {money(
                        paymentPaid
                      )}
                    </td>

                    <td
                      style={{
                        ...tdStyle,
                        background:
                          "#f1f5f9",
                      }}
                    >
                      -
                    </td>

                  </tr>

                </tfoot>

              </table>

            </div>
          )}

          {/* =================================================
              FINAL BALANCE
          ================================================= */}

          <div
            style={{
              marginTop:
                15,

              padding:
                15,

              borderRadius:
                9,

              background:
                currentUdhari >
                0
                  ? "#ffebee"
                  : "#e8f5e9",

              border:
                currentUdhari >
                0
                  ? "1px solid #ef9a9a"
                  : "1px solid #a5d6a7",

              textAlign:
                "center",
            }}
          >

            <div
              style={{
                fontSize:
                  13,
                color:
                  "#666",
              }}
            >
              Customer का Final
              Current Udhari
            </div>

            <div
              style={{
                fontSize:
                  26,
                fontWeight:
                  "bold",

                color:
                  currentUdhari >
                  0
                    ? "#d32f2f"
                    : "#2e7d32",

                marginTop:
                  5,
              }}
            >
              {money(
                currentUdhari
              )}
            </div>

            {currentUdhari <=
              0 && (
              <div
                style={{
                  marginTop:
                    5,
                  color:
                    "#2e7d32",
                  fontWeight:
                    "bold",
                }}
              >
                ✅ Customer की Udhari
                पूरी तरह Settled है।
              </div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}

// =====================================================
// SUMMARY CARD
// =====================================================

function SummaryCard({
  title,
  value,
  color,
}) {
  return (
    <div
      style={{
        background:
          "#ffffff",

        padding:
          "12px",

        borderRadius:
          "8px",

        borderLeft:
          `4px solid ${color}`,

        boxShadow:
          "0 2px 6px rgba(0,0,0,0.05)",

        minHeight:
          "65px",

        boxSizing:
          "border-box",
      }}
    >

      <div
        style={{
          fontSize:
            "11px",
          color:
            "#777",
        }}
      >
        {title}
      </div>

      <div
        style={{
          marginTop:
            "5px",

          fontSize:
            "19px",

          fontWeight:
            "bold",

          color,
        }}
      >
        {value}
      </div>

    </div>
  );
}

// =====================================================
// STYLES
// =====================================================

const pageStyle = {
  minHeight:
    "100vh",

  padding:
    "12px",

  background:
    "#f2f5f9",

  fontFamily:
    "Arial, sans-serif",

  boxSizing:
    "border-box",
};

const headerStyle = {
  background:
    "linear-gradient(135deg,#0d47a1,#1976d2,#42a5f5)",

  color:
    "white",

  padding:
    "17px",

  borderRadius:
    "11px",

  marginBottom:
    "13px",

  display:
    "flex",

  justifyContent:
    "space-between",

  alignItems:
    "center",

  gap:
    "10px",

  flexWrap:
    "wrap",

  boxShadow:
    "0 3px 10px rgba(0,0,0,0.12)",
};

const headerTitle = {
  margin:
    0,

  fontSize:
    "24px",
};

const subtitle = {
  marginTop:
    "4px",

  fontSize:
    "13px",
};

const backButton = {
  padding:
    "9px 14px",

  background:
    "rgba(255,255,255,0.18)",

  color:
    "white",

  border:
    "1px solid rgba(255,255,255,0.4)",

  borderRadius:
    "7px",

  cursor:
    "pointer",

  fontWeight:
    "bold",
};

const cardStyle = {
  background:
    "white",

  padding:
    "14px",

  borderRadius:
    "10px",

  marginBottom:
    "13px",

  boxShadow:
    "0 2px 7px rgba(0,0,0,0.06)",
};

const searchInput = {
  width:
    "100%",

  boxSizing:
    "border-box",

  padding:
    "11px",

  border:
    "1px solid #ccc",

  borderRadius:
    "7px",

  fontSize:
    "14px",
};

const sectionTitle = {
  margin:
    "0 0 10px",

  fontSize:
    "18px",
};

const customerGrid = {
  display:
    "grid",

  gridTemplateColumns:
    "repeat(auto-fit,minmax(220px,1fr))",

  gap:
    "10px",
};

const customerCard = {
  textAlign:
    "left",

  width:
    "100%",

  minHeight:
    "155px",

  padding:
    "13px",

  background:
    "#f8fafc",

  borderTop:
    "none",

  borderRight:
    "none",

  borderBottom:
    "none",

  borderRadius:
    "9px",

  cursor:
    "pointer",

  boxSizing:
    "border-box",

  boxShadow:
    "0 2px 6px rgba(0,0,0,0.06)",
};

const customerCardTop = {
  display:
    "flex",

  justifyContent:
    "space-between",

  alignItems:
    "center",

  marginBottom:
    "8px",
};

const smallText = {
  marginTop:
    "7px",

  fontSize:
    "12px",

  color:
    "#555",
};

const customerHeader = {
  display:
    "flex",

  justifyContent:
    "space-between",

  alignItems:
    "center",

  gap:
    "10px",

  flexWrap:
    "wrap",

  padding:
    "11px",

  background:
    "#f5f7fa",

  borderRadius:
    "8px",

  marginBottom:
    "12px",
};

const actionBox = {
  display:
    "flex",

  gap:
    "8px",

  flexWrap:
    "wrap",

  marginBottom:
    "13px",
};

const grayButton = {
  padding:
    "9px 13px",

  background:
    "#555",

  color:
    "white",

  border:
    "none",

  borderRadius:
    "6px",

  cursor:
    "pointer",

  fontWeight:
    "bold",
};

const paymentButton = {
  padding:
    "9px 13px",

  background:
    "#6a1b9a",

  color:
    "white",

  border:
    "none",

  borderRadius:
    "6px",

  cursor:
    "pointer",

  fontWeight:
    "bold",
};

const refreshButton = {
  padding:
    "9px 13px",

  background:
    "#0277bd",

  color:
    "white",

  border:
    "none",

  borderRadius:
    "6px",

  cursor:
    "pointer",

  fontWeight:
    "bold",
};

const summaryGrid = {
  display:
    "grid",

  gridTemplateColumns:
    "repeat(auto-fit,minmax(150px,1fr))",

  gap:
    "9px",

  marginBottom:
    "14px",
};

const clickableSummaryButton = {
  position:
    "relative",

  border:
    "none",

  background:
    "transparent",

  padding:
    0,

  margin:
    0,

  width:
    "100%",

  cursor:
    "pointer",

  textAlign:
    "left",
};

const clickHint = {
  position:
    "absolute",

  right:
    "7px",

  bottom:
    "5px",

  fontSize:
    "10px",

  color:
    "#1565c0",

  fontWeight:
    "bold",
};

const billDetailBox = {
  marginTop:
    "10px",

  padding:
    "14px",

  background:
    "#f8fafc",

  border:
    "1px solid #d9e0e7",

  borderRadius:
    "10px",

  marginBottom:
    "15px",
};

const detailHeader = {
  display:
    "flex",

  justifyContent:
    "space-between",

  alignItems:
    "center",

  gap:
    "10px",

  marginBottom:
    "12px",
};

const closeButton = {
  padding:
    "7px 11px",

  background:
    "#555",

  color:
    "white",

  border:
    "none",

  borderRadius:
    "6px",

  cursor:
    "pointer",
};

const subHeading = {
  margin:
    "16px 0 9px",

  fontSize:
    "16px",
};

const emptyBox = {
  padding:
    "20px",

  textAlign:
    "center",

  color:
    "#777",

  background:
    "#f7f8fa",

  borderRadius:
    "7px",
};

const tableStyle = {
  width:
    "100%",

  borderCollapse:
    "collapse",

  fontSize:
    "12px",
};

const thStyle = {
  border:
    "1px solid #ddd",

  padding:
    "8px",

  background:
    "#f1f5f9",

  whiteSpace:
    "nowrap",
};

const tdStyle = {
  border:
    "1px solid #ddd",

  padding:
    "8px",

  whiteSpace:
    "nowrap",
};

export default CustomerLedger;