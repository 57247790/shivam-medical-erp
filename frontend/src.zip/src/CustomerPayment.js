import React, { useEffect, useMemo, useState } from "react";

function CustomerPayment({ goBack }) {
  const [customer, setCustomer] = useState("");
  const [mobile, setMobile] = useState("");
  const [amount, setAmount] = useState("");
  const [mode, setMode] = useState("Cash");
  const [note, setNote] = useState("");

  // =====================================================
  // CLICKED DETAIL
  // =====================================================

  const [activeDetail, setActiveDetail] = useState("");

  // =====================================================
  // LOAD SELECTED CUSTOMER
  // =====================================================

  useEffect(() => {
    try {
      const selected = JSON.parse(
        localStorage.getItem(
          "selectedCustomerForPayment"
        ) || "null"
      );

      if (selected) {
        setCustomer(selected.name || "");
        setMobile(selected.mobile || "");
      }
    } catch {
      // ignore
    }
  }, []);

  // =====================================================
  // LOAD BILLS
  // =====================================================

  const getBills = () => {
    try {
      const data = JSON.parse(
        localStorage.getItem("bills") || "[]"
      );

      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  };

  // =====================================================
  // LOAD CUSTOMER PAYMENTS
  // =====================================================

  const getPayments = () => {
    try {
      const data = JSON.parse(
        localStorage.getItem(
          "customerPayments"
        ) || "[]"
      );

      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  };

  // =====================================================
  // LOAD CUSTOMER ADVANCES
  // =====================================================

  const getAdvances = () => {
    try {
      const data = JSON.parse(
        localStorage.getItem(
          "customerAdvances"
        ) || "{}"
      );

      if (
        data &&
        typeof data === "object" &&
        !Array.isArray(data)
      ) {
        return data;
      }

      return {};
    } catch {
      return {};
    }
  };

  // =====================================================
  // CUSTOMER KEY
  // =====================================================

  const makeCustomerKey = (
    name,
    mobileNumber
  ) => {
    const cleanName = String(name || "")
      .trim()
      .toLowerCase();

    const cleanMobile = String(
      mobileNumber || ""
    ).trim();

    if (
      cleanName &&
      cleanMobile
    ) {
      return `${cleanName}_${cleanMobile}`;
    }

    return cleanName || "cash customer";
  };

  // =====================================================
  // CURRENT CUSTOMER KEY
  // =====================================================

  const customerKey = useMemo(() => {
    return makeCustomerKey(
      customer,
      mobile
    );
  }, [customer, mobile]);

  // =====================================================
  // CUSTOMER BILLS
  // =====================================================

  const customerBills = useMemo(() => {
    const bills = getBills();

    const name = customer
      .trim()
      .toLowerCase();

    const phone = mobile.trim();

    if (!name) {
      return [];
    }

    return bills.filter((bill) => {
      const billName = String(
        bill.customer || ""
      )
        .trim()
        .toLowerCase();

      const billPhone = String(
        bill.mobile || ""
      ).trim();

      return (
        billName === name &&
        billPhone === phone
      );
    });
  }, [customer, mobile]);

  // =====================================================
  // CUSTOMER PAYMENTS
  // =====================================================

  const customerPayments = useMemo(() => {
    const payments = getPayments();

    const name = customer
      .trim()
      .toLowerCase();

    const phone = mobile.trim();

    if (!name) {
      return [];
    }

    return payments.filter((payment) => {
      const paymentName = String(
        payment.customer || ""
      )
        .trim()
        .toLowerCase();

      const paymentPhone = String(
        payment.mobile || ""
      ).trim();

      return (
        paymentName === name &&
        paymentPhone === phone
      );
    });
  }, [customer, mobile]);

  // =====================================================
  // CUSTOMER ADVANCE
  // =====================================================

  const customerAdvance = useMemo(() => {
    const advances = getAdvances();

    return Number(
      advances[customerKey] || 0
    );
  }, [customerKey]);

  // =====================================================
  // TOTAL BILL
  // =====================================================

  const totalBill = useMemo(() => {
    return customerBills.reduce(
      (sum, bill) =>
        sum + Number(
          bill.total || 0
        ),
      0
    );
  }, [customerBills]);

  // =====================================================
  // ORIGINAL BILL UDHARI
  // =====================================================

  const originalUdhari = useMemo(() => {
    return customerBills.reduce(
      (sum, bill) => {
        const udhari = Number(
          bill.pendingAmount ??
          bill.udhari ??
          0
        );

        return sum + udhari;
      },
      0
    );
  }, [customerBills]);

  // =====================================================
  // BILL PAID
  // =====================================================

  const billPaid = useMemo(() => {
    return Math.max(
      totalBill -
        originalUdhari,
      0
    );
  }, [
    totalBill,
    originalUdhari,
  ]);

  // =====================================================
  // CUSTOMER PAYMENT TOTAL
  // =====================================================

  const paymentPaid = useMemo(() => {
    return customerPayments.reduce(
      (sum, payment) =>
        sum +
        Number(
          payment.amount || 0
        ),
      0
    );
  }, [customerPayments]);

  // =====================================================
  // CURRENT UDHARI
  // =====================================================

  const pending = useMemo(() => {
    return Math.max(
      originalUdhari -
        paymentPaid,
      0
    );
  }, [
    originalUdhari,
    paymentPaid,
  ]);

  // =====================================================
  // MONEY
  // =====================================================

  const money = (value) => {
    return `₹${Number(
      value || 0
    ).toFixed(2)}`;
  };

  // =====================================================
  // GET BILL UDHARI
  // =====================================================

  const getBillUdhari = (bill) => {
    return Number(
      bill.pendingAmount ??
      bill.udhari ??
      0
    );
  };

  // =====================================================
  // GET BILL PAID
  // =====================================================

  const getBillPaid = (bill) => {
    const total = Number(
      bill.total || 0
    );

    const udhari =
      getBillUdhari(bill);

    return Math.max(
      total - udhari,
      0
    );
  };

  // =====================================================
  // BILL DATE
  // =====================================================

  const getBillDate = (bill) => {
    return (
      bill.date ||
      bill.billDate ||
      bill.createdDate ||
      "-"
    );
  };

  // =====================================================
  // BILL NUMBER
  // =====================================================

  const getBillNumber = (bill) => {
    return (
      bill.billNo ||
      bill.billNumber ||
      bill.invoiceNo ||
      bill.id ||
      "-"
    );
  };

  // =====================================================
  // GET PAYMENT MODE
  // =====================================================

  const getPaymentMode = (payment) => {
    return (
      payment.mode ||
      payment.paymentMode ||
      "-"
    );
  };

  // =====================================================
  // SAVE PAYMENT
  // =====================================================

  const savePayment = () => {
    const name = customer.trim();
    const phone = mobile.trim();

    const paymentAmount =
      Number(amount || 0);

    if (!name) {
      alert(
        "⚠️ Customer Name डालें"
      );
      return;
    }

    if (
      !paymentAmount ||
      paymentAmount <= 0
    ) {
      alert(
        "⚠️ Payment Amount सही डालें"
      );
      return;
    }

    if (paymentAmount > pending) {
      alert(
        `❌ Payment बाकी Udhari से ज्यादा है\n\nबाकी Udhari: ${money(
          pending
        )}`
      );

      return;
    }

    const now = new Date();

    const date =
      `${now.getFullYear()}-${String(
        now.getMonth() + 1
      ).padStart(2, "0")}-${String(
        now.getDate()
      ).padStart(2, "0")}`;

    const time =
      now.toLocaleTimeString();

    const payment = {
      id:
        Date.now() +
        Math.random(),

      customer: name,

      mobile: phone,

      amount:
        Number(
          paymentAmount.toFixed(2)
        ),

      mode,

      paymentMode: mode,

      note: note.trim(),

      date,

      time,

      createdAt: Date.now(),

      customerKey,

      paymentType:
        "udhari_settlement",
    };

    const payments =
      getPayments();

    const updatedPayments = [
      payment,
      ...payments,
    ];

    localStorage.setItem(
      "customerPayments",
      JSON.stringify(
        updatedPayments
      )
    );

    window.dispatchEvent(
      new Event(
        "customerPaymentUpdated"
      )
    );

    localStorage.setItem(
      "customerPaymentUpdatedAt",
      String(Date.now())
    );

    const newPending =
      Math.max(
        pending -
          paymentAmount,
        0
      );

    alert(
      `✅ Payment जमा हो गया\n\n` +
      `Customer: ${name}\n` +
      `Payment: ${money(
        paymentAmount
      )}\n` +
      `Mode: ${mode}\n\n` +
      `पहले बाकी Udhari: ${money(
        pending
      )}\n` +
      `अब बाकी Udhari: ${money(
        newPending
      )}`
    );

    setAmount("");
    setMode("Cash");
    setNote("");

    setActiveDetail(
      "payment"
    );

    if (goBack) {
      setTimeout(() => {
        goBack();
      }, 100);
    }
  };

  // =====================================================
  // DETAIL TITLE
  // =====================================================

  const detailTitle = useMemo(() => {
    switch (activeDetail) {
      case "totalBill":
        return "📋 Total Bill Details";

      case "billPaid":
        return "💵 Bill Paid Details";

      case "billUdhari":
        return "📒 Bill Udhari Details";

      case "payment":
        return "💳 Customer Payment Details";

      case "pending":
        return "⚠️ Current Udhari Details";

      case "advance":
        return "💰 Customer Advance Details";

      default:
        return "";
    }
  }, [activeDetail]);

  // =====================================================
  // DETAIL BILLS
  // =====================================================

  const detailBills = useMemo(() => {
    if (
      activeDetail ===
      "totalBill"
    ) {
      return customerBills;
    }

    if (
      activeDetail ===
      "billPaid"
    ) {
      return customerBills.filter(
        (bill) =>
          getBillPaid(bill) > 0
      );
    }

    if (
      activeDetail ===
      "billUdhari"
    ) {
      return customerBills.filter(
        (bill) =>
          getBillUdhari(bill) > 0
      );
    }

    if (
      activeDetail ===
      "pending"
    ) {
      return customerBills.filter(
        (bill) =>
          getBillUdhari(bill) > 0
      );
    }

    return [];
  }, [
    activeDetail,
    customerBills,
  ]);

  // =====================================================
  // CLOSE DETAIL
  // =====================================================

  const closeDetail = () => {
    setActiveDetail("");
  };

  // =====================================================
  // UI
  // =====================================================

  return (
    <div
      style={{
        minHeight:
          "100vh",
        padding: 15,
        background:
          "#f2f5f9",
        fontFamily:
          "Arial, sans-serif",
        boxSizing:
          "border-box",
      }}
    >
      {/* =================================================
          HEADER
      ================================================= */}

      <div
        style={{
          background:
            "linear-gradient(135deg,#1565c0,#42a5f5)",
          color: "white",
          padding: 15,
          borderRadius: 10,
          marginBottom: 12,
          display: "flex",
          justifyContent:
            "space-between",
          alignItems: "center",
          gap: 10,
        }}
      >
        <div>
          <h2
            style={{
              margin: 0,
            }}
          >
            💰 Customer Payment
          </h2>

          <div
            style={{
              fontSize: 13,
              marginTop: 3,
            }}
          >
            Shivam Medical ERP
          </div>
        </div>

        <button
          type="button"
          onClick={goBack}
          style={{
            background:
              "white",
            color:
              "#1565c0",
            border:
              "none",
            padding:
              "9px 14px",
            borderRadius:
              7,
            fontWeight:
              "bold",
            cursor:
              "pointer",
          }}
        >
          ⬅️ Back
        </button>
      </div>

      {/* =================================================
          CUSTOMER DETAILS
      ================================================= */}

      <div
        style={{
          background:
            "white",
          padding: 15,
          borderRadius:
            10,
          marginBottom:
            12,
          boxShadow:
            "0 2px 8px rgba(0,0,0,0.06)",
        }}
      >
        <h3>
          👤 Customer Details
        </h3>

        <input
          type="text"
          placeholder="Customer Name"
          value={customer}
          onChange={(e) => {
            setCustomer(
              e.target.value
            );
            setActiveDetail("");
          }}
          style={
            inputStyle
          }
        />

        <input
          type="text"
          placeholder="Mobile Number"
          value={mobile}
          onChange={(e) => {
            setMobile(
              e.target.value
            );
            setActiveDetail("");
          }}
          style={
            inputStyle
          }
        />
      </div>

      {/* =================================================
          BALANCE
      ================================================= */}

      <div
        style={{
          background:
            "#fff",
          border:
            "1px solid #ddd",
          padding: 15,
          borderRadius:
            10,
          marginBottom:
            12,
        }}
      >
        <h3
          style={{
            marginTop: 0,
            color:
              "#1565c0",
          }}
        >
          📊 Customer Balance
        </h3>

        <div
          style={{
            display:
              "grid",
            gridTemplateColumns:
              "repeat(auto-fit,minmax(160px,1fr))",
            gap: 10,
          }}
        >
          {/* TOTAL BILL */}

          <BalanceBox
            title="Total Bill"
            value={
              totalBill
            }
            color="#1565c0"
            active={
              activeDetail ===
              "totalBill"
            }
            onClick={() =>
              setActiveDetail(
                "totalBill"
              )
            }
          />

          {/* BILL PAID */}

          <BalanceBox
            title="Bill Paid"
            value={
              billPaid
            }
            color="#2e7d32"
            active={
              activeDetail ===
              "billPaid"
            }
            onClick={() =>
              setActiveDetail(
                "billPaid"
              )
            }
          />

          {/* BILL UDHARI */}

          <BalanceBox
            title="Bill Udhari"
            value={
              originalUdhari
            }
            color="#d32f2f"
            active={
              activeDetail ===
              "billUdhari"
            }
            onClick={() =>
              setActiveDetail(
                "billUdhari"
              )
            }
          />

          {/* CUSTOMER PAYMENT */}

          <BalanceBox
            title="Payment"
            value={
              paymentPaid
            }
            color="#00838f"
            active={
              activeDetail ===
              "payment"
            }
            onClick={() =>
              setActiveDetail(
                "payment"
              )
            }
          />

          {/* CURRENT UDHARI */}

          <BalanceBox
            title="Current Udhari"
            value={
              pending
            }
            color="#c62828"
            active={
              activeDetail ===
              "pending"
            }
            onClick={() =>
              setActiveDetail(
                "pending"
              )
            }
          />
        </div>

        {/* ADVANCE */}

        <button
          type="button"
          onClick={() =>
            setActiveDetail(
              "advance"
            )
          }
          style={{
            marginTop: 12,
            width: "100%",
            background:
              "#e3f2fd",
            border:
              activeDetail ===
              "advance"
                ? "2px solid #1565c0"
                : "1px solid #64b5f6",
            padding: 12,
            borderRadius: 8,
            textAlign:
              "center",
            cursor:
              "pointer",
          }}
        >
          <div
            style={{
              fontSize: 12,
              color:
                "#1565c0",
            }}
          >
            💰 Customer Advance Balance
          </div>

          <div
            style={{
              fontSize: 22,
              fontWeight:
                "bold",
              color:
                "#1565c0",
              marginTop: 4,
            }}
          >
            {money(
              customerAdvance
            )}
          </div>

          <div
            style={{
              fontSize: 10,
              color:
                "#1565c0",
              marginTop: 3,
            }}
          >
            👆 Detail देखने के लिए क्लिक करें
          </div>
        </button>
      </div>

      {/* =================================================
          CLICKABLE DETAIL PANEL
      ================================================= */}

      {activeDetail && (
        <div
          style={{
            background:
              "white",
            padding: 15,
            borderRadius:
              10,
            marginBottom:
              12,
            boxShadow:
              "0 2px 8px rgba(0,0,0,0.08)",
          }}
        >
          {/* DETAIL HEADER */}

          <div
            style={{
              display:
                "flex",
              justifyContent:
                "space-between",
              alignItems:
                "center",
              gap: 10,
              marginBottom:
                12,
            }}
          >
            <h3
              style={{
                margin: 0,
                color:
                  "#1565c0",
              }}
            >
              {detailTitle}
            </h3>

            <button
              type="button"
              onClick={
                closeDetail
              }
              style={{
                background:
                  "#555",
                color:
                  "white",
                border:
                  "none",
                padding:
                  "7px 12px",
                borderRadius:
                  6,
                cursor:
                  "pointer",
              }}
            >
              ✖ Close
            </button>
          </div>

          {/* =================================================
              BILL DETAILS
          ================================================= */}

          {[
            "totalBill",
            "billPaid",
            "billUdhari",
            "pending",
          ].includes(
            activeDetail
          ) && (
            <>
              <div
                style={{
                  display:
                    "grid",
                  gridTemplateColumns:
                    "repeat(auto-fit,minmax(140px,1fr))",
                  gap: 8,
                  marginBottom:
                    12,
                }}
              >
                <MiniBox
                  title="Bills"
                  value={
                    detailBills.length
                  }
                />

                <MiniBox
                  title="Total"
                  value={money(
                    detailBills.reduce(
                      (
                        sum,
                        bill
                      ) =>
                        sum +
                        Number(
                          bill.total ||
                            0
                        ),
                      0
                    )
                  )}
                />
              </div>

              {detailBills.length ===
              0 ? (
                <div
                  style={
                    emptyBox
                  }
                >
                  कोई Bill Detail उपलब्ध नहीं है।
                </div>
              ) : (
                <div
                  style={{
                    overflowX:
                      "auto",
                  }}
                >
                  <table
                    style={
                      tableStyle
                    }
                  >
                    <thead>
                      <tr>
                        <th
                          style={
                            thStyle
                          }
                        >
                          Date
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Bill No.
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Customer
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Total
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Paid
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Udhari
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {detailBills.map(
                        (
                          bill,
                          index
                        ) => (
                          <tr
                            key={
                              bill?.id ||
                              index
                            }
                          >
                            <td
                              style={
                                tdStyle
                              }
                            >
                              {getBillDate(
                                bill
                              )}
                            </td>

                            <td
                              style={
                                tdStyle
                              }
                            >
                              {
                                getBillNumber(
                                  bill
                                )
                              }
                            </td>

                            <td
                              style={
                                tdStyle
                              }
                            >
                              {
                                bill.customer ||
                                customer
                              }
                            </td>

                            <td
                              style={
                                tdStyle
                              }
                            >
                              {money(
                                bill.total
                              )}
                            </td>

                            <td
                              style={{
                                ...tdStyle,
                                color:
                                  "#2e7d32",
                                fontWeight:
                                  "bold",
                              }}
                            >
                              {money(
                                getBillPaid(
                                  bill
                                )
                              )}
                            </td>

                            <td
                              style={{
                                ...tdStyle,
                                color:
                                  "#d32f2f",
                                fontWeight:
                                  "bold",
                              }}
                            >
                              {money(
                                getBillUdhari(
                                  bill
                                )
                              )}
                            </td>
                          </tr>
                        )
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}

          {/* =================================================
              PAYMENT DETAILS
          ================================================= */}

          {activeDetail ===
            "payment" && (
            <>
              <div
                style={{
                  display:
                    "grid",
                  gridTemplateColumns:
                    "repeat(auto-fit,minmax(140px,1fr))",
                  gap: 8,
                  marginBottom:
                    12,
                }}
              >
                <MiniBox
                  title="Payment Entries"
                  value={
                    customerPayments.length
                  }
                />

                <MiniBox
                  title="Total Payment"
                  value={money(
                    paymentPaid
                  )}
                />
              </div>

              {customerPayments.length ===
              0 ? (
                <div
                  style={
                    emptyBox
                  }
                >
                  इस Customer की कोई Payment Entry नहीं है।
                </div>
              ) : (
                <div
                  style={{
                    overflowX:
                      "auto",
                  }}
                >
                  <table
                    style={
                      tableStyle
                    }
                  >
                    <thead>
                      <tr>
                        <th
                          style={
                            thStyle
                          }
                        >
                          Date
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Time
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Customer
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Mode
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Amount
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          Note
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {customerPayments.map(
                        (
                          payment,
                          index
                        ) => (
                          <tr
                            key={
                              payment?.id ||
                              index
                            }
                          >
                            <td
                              style={
                                tdStyle
                              }
                            >
                              {payment.date ||
                                "-"}
                            </td>

                            <td
                              style={
                                tdStyle
                              }
                            >
                              {payment.time ||
                                "-"}
                            </td>

                            <td
                              style={
                                tdStyle
                              }
                            >
                              {payment.customer ||
                                customer}
                            </td>

                            <td
                              style={
                                tdStyle
                              }
                            >
                              {getPaymentMode(
                                payment
                              )}
                            </td>

                            <td
                              style={{
                                ...tdStyle,
                                color:
                                  "#00838f",
                                fontWeight:
                                  "bold",
                              }}
                            >
                              {money(
                                payment.amount
                              )}
                            </td>

                            <td
                              style={
                                tdStyle
                              }
                            >
                              {payment.note ||
                                "-"}
                            </td>
                          </tr>
                        )
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}

          {/* =================================================
              ADVANCE DETAILS
          ================================================= */}

          {activeDetail ===
            "advance" && (
            <div
              style={{
                background:
                  "#e3f2fd",
                border:
                  "1px solid #90caf9",
                padding:
                  20,
                borderRadius:
                  8,
                textAlign:
                  "center",
              }}
            >
              <div
                style={{
                  fontSize:
                    14,
                  color:
                    "#1565c0",
                }}
              >
                👤 Customer
              </div>

              <div
                style={{
                  fontSize:
                    18,
                  fontWeight:
                    "bold",
                  marginTop:
                    5,
                }}
              >
                {customer}
              </div>

              <div
                style={{
                  marginTop:
                    15,
                  fontSize:
                    13,
                  color:
                    "#1565c0",
                }}
              >
                💰 Current Advance Balance
              </div>

              <div
                style={{
                  fontSize:
                    28,
                  fontWeight:
                    "bold",
                  color:
                    "#1565c0",
                  marginTop:
                    5,
                }}
              >
                {money(
                  customerAdvance
                )}
              </div>

              <div
                style={{
                  marginTop:
                    12,
                  fontSize:
                    12,
                  color:
                    "#555",
                }}
              >
                Advance और Customer Payment
                अलग-अलग balance हैं।
              </div>
            </div>
          )}
        </div>
      )}

      {/* =================================================
          SETTLEMENT INFORMATION
      ================================================= */}

      {pending > 0 ? (
        <div
          style={{
            background:
              "#ffebee",
            border:
              "1px solid #ef9a9a",
            padding: 15,
            borderRadius: 10,
            marginBottom: 12,
          }}
        >
          <h3
            style={{
              marginTop: 0,
              color:
                "#c62828",
            }}
          >
            ⚠️ Udhari Settlement
          </h3>

          <div
            style={{
              fontSize: 14,
              lineHeight: 1.8,
            }}
          >
            <div>
              Original Bill Udhari:{" "}
              <b>
                {money(
                  originalUdhari
                )}
              </b>
            </div>

            <div>
              Customer Payment:{" "}
              <b
                style={{
                  color:
                    "#2e7d32",
                }}
              >
                {money(
                  paymentPaid
                )}
              </b>
            </div>

            <div
              style={{
                fontWeight:
                  "bold",
                color:
                  "#c62828",
              }}
            >
              Current Udhari:{" "}
              {money(pending)}
            </div>
          </div>
        </div>
      ) : (
        <div
          style={{
            background:
              "#e8f5e9",
            border:
              "1px solid #a5d6a7",
            padding: 15,
            borderRadius: 10,
            marginBottom: 12,
          }}
        >
          <h3
            style={{
              margin: 0,
              color:
                "#2e7d32",
            }}
          >
            ✅ Customer की Udhari पूरी तरह Settled है।
          </h3>
        </div>
      )}

      {/* =================================================
          PAYMENT FORM
      ================================================= */}

      {pending > 0 && (
        <div
          style={{
            background:
              "white",
            padding: 15,
            borderRadius: 10,
            boxShadow:
              "0 2px 8px rgba(0,0,0,0.06)",
          }}
        >
          <h3>
            💵 Payment जमा करें
          </h3>

          <input
            type="number"
            min="0"
            max={pending}
            step="0.01"
            placeholder="Payment Amount ₹"
            value={amount}
            onChange={(e) =>
              setAmount(
                e.target.value
              )
            }
            style={
              inputStyle
            }
          />

          {/* QUICK AMOUNT */}

          <div
            style={{
              display:
                "flex",
              gap: 7,
              flexWrap:
                "wrap",
              marginBottom:
                9,
            }}
          >
            <button
              type="button"
              onClick={() =>
                setAmount(
                  pending.toFixed(
                    2
                  )
                )
              }
              style={
                quickButton
              }
            >
              Full Udhari
            </button>

            <button
              type="button"
              onClick={() =>
                setAmount(
                  Math.min(
                    500,
                    pending
                  ).toFixed(
                    2
                  )
                )
              }
              style={
                quickButton
              }
            >
              ₹500
            </button>

            <button
              type="button"
              onClick={() =>
                setAmount(
                  Math.min(
                    1000,
                    pending
                  ).toFixed(
                    2
                  )
                )
              }
              style={
                quickButton
              }
            >
              ₹1000
            </button>
          </div>

          <select
            value={mode}
            onChange={(e) =>
              setMode(
                e.target.value
              )
            }
            style={
              inputStyle
            }
          >
            <option value="Cash">
              💵 Cash
            </option>

            <option value="UPI">
              📱 UPI
            </option>

            <option value="Card">
              💳 Card
            </option>

            <option value="Bank">
              🏦 Bank
            </option>
          </select>

          <input
            type="text"
            placeholder="Note"
            value={note}
            onChange={(e) =>
              setNote(
                e.target.value
              )
            }
            style={
              inputStyle
            }
          />

          <button
            type="button"
            onClick={
              savePayment
            }
            style={{
              width:
                "100%",
              padding:
                12,
              background:
                "#2e7d32",
              color:
                "white",
              border:
                "none",
              borderRadius:
                7,
              fontSize:
                16,
              fontWeight:
                "bold",
              cursor:
                "pointer",
            }}
          >
            💰 Payment जमा करें
          </button>
        </div>
      )}

      {/* =================================================
          ADVANCE NOTE
      ================================================= */}

      {customerAdvance >
        0 && (
        <div
          style={{
            marginTop:
              12,
            background:
              "#e3f2fd",
            border:
              "1px solid #90caf9",
            padding:
              12,
            borderRadius:
              8,
            color:
              "#1565c0",
            fontSize:
              13,
          }}
        >
          💡 <b>Advance:</b>{" "}
          {money(
            customerAdvance
          )}
          <br />
          यह Advance अलग balance है। Customer Payment
          जमा करने पर Advance कम नहीं होगा। Advance
          केवल नए Bill में settlement के लिए इस्तेमाल होगा।
        </div>
      )}
    </div>
  );
}

// =====================================================
// BALANCE BOX
// =====================================================

function BalanceBox({
  title,
  value,
  color,
  onClick,
  active,
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        background:
          active
            ? "#e3f2fd"
            : "#fff",
        padding: 12,
        borderRadius: 8,
        border:
          active
            ? `2px solid ${color}`
            : "1px solid #eee",
        borderLeft:
          `5px solid ${color}`,
        boxShadow:
          "0 2px 6px rgba(0,0,0,0.06)",
        textAlign:
          "left",
        cursor:
          "pointer",
        width:
          "100%",
        boxSizing:
          "border-box",
      }}
    >
      <div
        style={{
          fontSize:
            12,
          color:
            "#666",
        }}
      >
        {title}
      </div>

      <div
        style={{
          fontSize:
            18,
          fontWeight:
            "bold",
          color,
          marginTop:
            4,
        }}
      >
        ₹
        {Number(
          value || 0
        ).toFixed(2)}
      </div>

      <div
        style={{
          fontSize:
            10,
          color:
            color,
          marginTop:
            5,
        }}
      >
        👆 Detail देखने के लिए क्लिक करें
      </div>
    </button>
  );
}

// =====================================================
// MINI BOX
// =====================================================

function MiniBox({
  title,
  value,
}) {
  return (
    <div
      style={{
        background:
          "#f5f7fa",
        padding:
          10,
        borderRadius:
          7,
      }}
    >
      <div
        style={{
          fontSize:
            11,
          color:
            "#777",
        }}
      >
        {title}
      </div>

      <div
        style={{
          marginTop:
            4,
          fontSize:
            16,
          fontWeight:
            "bold",
          color:
            "#1565c0",
        }}
      >
        {value}
      </div>
    </div>
  );
}

// =====================================================
// INPUT STYLE
// =====================================================

const inputStyle = {
  width:
    "100%",
  boxSizing:
    "border-box",
  padding:
    11,
  marginBottom:
    9,
  border:
    "1px solid #ccc",
  borderRadius:
    7,
  fontSize:
    14,
};

// =====================================================
// QUICK BUTTON
// =====================================================

const quickButton = {
  padding:
    "7px 12px",
  border:
    "1px solid #90caf9",
  background:
    "#e3f2fd",
  color:
    "#1565c0",
  borderRadius:
    6,
  cursor:
    "pointer",
  fontWeight:
    "bold",
};

// =====================================================
// EMPTY BOX
// =====================================================

const emptyBox = {
  padding:
    20,
  textAlign:
    "center",
  color:
    "#777",
  background:
    "#f7f8fa",
  borderRadius:
    7,
};

// =====================================================
// TABLE
// =====================================================

const tableStyle = {
  width:
    "100%",
  borderCollapse:
    "collapse",
  fontSize:
    12,
};

const thStyle = {
  border:
    "1px solid #ddd",
  padding:
    8,
  background:
    "#f1f5f9",
  whiteSpace:
    "nowrap",
};

const tdStyle = {
  border:
    "1px solid #ddd",
  padding:
    8,
  whiteSpace:
    "nowrap",
};

export default CustomerPayment;