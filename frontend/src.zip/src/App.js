import React, { useEffect, useState } from "react";

import Login from "./Login";
import Dashboard from "./Dashboard";
import Purchase from "./Purchase";
import Stock from "./Stock";
import Billing from "./Billing";
import Sale from "./Sale";
import Expiry from "./Expiry";
import Reports from "./Reports";

import SalesHistory from "./SalesHistory";
import PurchaseHistory from "./PurchaseHistory";
import CustomerLedger from "./CustomerLedger";
import CustomerPayment from "./CustomerPayment";
import SupplierLedger from "./SupplierLedger";
import SupplierPayment from "./SupplierPayment";
import Backup from "./Backup";

// BARCODE
import Barcode from "./Barcode";

function App() {
  // =====================================================
  // LOGIN
  // =====================================================

  const [loggedIn, setLoggedIn] = useState(() => {
    return localStorage.getItem("loggedIn") === "true";
  });

  // =====================================================
  // PAGE
  // =====================================================

  const [page, setPage] = useState("dashboard");

  // =====================================================
  // STOCK
  // =====================================================

  const [stock, setStock] = useState(() => {
    try {
      const savedStock = JSON.parse(
        localStorage.getItem("stock") || "[]"
      );

      return Array.isArray(savedStock)
        ? savedStock
        : [];
    } catch (error) {
      console.error("Stock load error:", error);
      return [];
    }
  });

  // =====================================================
  // SAVE STOCK
  // =====================================================

  useEffect(() => {
    try {
      localStorage.setItem(
        "stock",
        JSON.stringify(stock)
      );
    } catch (error) {
      console.error("Stock save error:", error);
    }
  }, [stock]);

  // =====================================================
  // LOGIN
  // =====================================================

  const handleLogin = () => {
    localStorage.setItem(
      "loggedIn",
      "true"
    );

    setLoggedIn(true);
    setPage("dashboard");
  };

  // =====================================================
  // LOGOUT
  // =====================================================

  const logout = () => {
    localStorage.removeItem(
      "loggedIn"
    );

    setLoggedIn(false);
    setPage("dashboard");
  };

  // =====================================================
  // LOGIN PAGE
  // =====================================================

  if (!loggedIn) {
    return (
      <Login
        onLogin={handleLogin}
      />
    );
  }

  // =====================================================
  // DASHBOARD
  // =====================================================

  if (page === "dashboard") {
    return (
      <Dashboard
        stock={stock}
        setPage={setPage}
        logout={logout}
      />
    );
  }

  // =====================================================
  // PURCHASE
  // =====================================================

  if (page === "purchase") {
    return (
      <Purchase
        stock={stock}
        setStock={setStock}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // STOCK
  // =====================================================

  if (page === "stock") {
    return (
      <Stock
        stock={stock}
        setStock={setStock}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // BILLING
  // =====================================================

  if (page === "billing") {
    return (
      <Billing
        stock={stock}
        setStock={setStock}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // SALE
  // =====================================================

  if (page === "sale") {
    return (
      <Sale
        stock={stock}
        setStock={setStock}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // BARCODE SCANNER
  // =====================================================

  if (page === "barcode") {
    return (
      <Barcode
        stock={stock}
        setStock={setStock}
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // SALES HISTORY
  // =====================================================

  if (page === "salesHistory") {
    return (
      <SalesHistory
        stock={stock}
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // PURCHASE HISTORY
  // =====================================================

  if (page === "purchaseHistory") {
    return (
      <PurchaseHistory
        stock={stock}
        setStock={setStock}
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // CUSTOMER LEDGER
  // =====================================================

  if (page === "customerLedger") {
    return (
      <CustomerLedger
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // CUSTOMER PAYMENT
  // =====================================================

  if (page === "customerPayment") {
    return (
      <CustomerPayment
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // SUPPLIER LEDGER
  // =====================================================

  if (page === "supplierLedger") {
    return (
      <SupplierLedger
        stock={stock}
        setStock={setStock}
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // SUPPLIER PAYMENT
  // =====================================================

  if (page === "supplierPayment") {
    return (
      <SupplierPayment
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // EXPIRY
  // =====================================================

  if (page === "expiry") {
    return (
      <Expiry
        stock={stock}
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // REPORTS
  // =====================================================

  if (page === "reports") {
    return (
      <Reports
        stock={stock}
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // BACKUP
  // =====================================================

  if (page === "backup") {
    return (
      <Backup
        stock={stock}
        setStock={setStock}
        setPage={setPage}
        goBack={() =>
          setPage("dashboard")
        }
      />
    );
  }

  // =====================================================
  // UNKNOWN PAGE
  // =====================================================

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        gap: "12px",
        fontFamily:
          "Arial, sans-serif",
        background: "#f2f5f9",
      }}
    >
      <h2>
        ⚠️ Page नहीं मिली
      </h2>

      <button
        type="button"
        onClick={() =>
          setPage("dashboard")
        }
        style={{
          padding:
            "10px 18px",
          background:
            "#1565c0",
          color: "white",
          border: "none",
          borderRadius: "7px",
          cursor: "pointer",
          fontWeight: "bold",
        }}
      >
        ⬅️ Dashboard
      </button>
    </div>
  );
}

export default App;