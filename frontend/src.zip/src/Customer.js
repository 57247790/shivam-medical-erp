import { useState } from "react";

function Customer({ goBack }) {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");

  const saveCustomer = () => {
    if (!name || !mobile) {
      alert("Please fill all fields");
      return;
    }

    alert("Customer Saved Successfully");

    setName("");
    setMobile("");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>👥 Customer</h2>

      <input
        type="text"
        placeholder="Customer Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <br /><br />

      <input
        type="text"
        placeholder="Mobile Number"
        value={mobile}
        onChange={(e) => setMobile(e.target.value)}
      />

      <br /><br />

      <button onClick={saveCustomer}>
        Save Customer
      </button>

      <button
        onClick={goBack}
        style={{ marginLeft: "10px" }}
      >
        ⬅️ Back
      </button>
    </div>
  );
}

export default Customer;