import React, { useMemo, useState } from "react";

function SaleHistory({ goBack }) {
  const [search, setSearch] = useState("");

  const getSales = () => {
    try {
      const data = JSON.parse(
        localStorage.getItem("sales") || "[]"
      );

      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  };

  const sales = getSales();

  const filteredSales = useMemo(() => {
    const text = search.trim().toLowerCase();

    if (!text) {
      return sales;
    }

    return sales.filter((sale) => {
      return (
        String(sale.medicine || "")
          .toLowerCase()
          .includes(text) ||
        String(sale.customer || "")
          .toLowerCase()
          .includes(text) ||
        String(sale.mobile || "")
          .toLowerCase()
          .includes(text) ||
        String(sale.billNumber || "")
          .toLowerCase()
          .includes(text) ||
        String(sale.barcode || "")
          .toLowerCase()
          .includes(text)
      );
    });
  }, [sales, search]);

  const totalAmount = filteredSales.reduce(
    (sum, sale) =>
      sum + Number(sale.saleAmount || sale.amount || 0),
    0
  );

  const totalProfit = filteredSales.reduce(
    (sum, sale) =>
      sum + Number(sale.profit || 0),
    0
  );

  const totalQty = filteredSales.reduce(
    (sum, sale) =>
      sum + Number(sale.quantity || 0),
    0
  );

  const money = (value) =>
    `₹${Number(value || 0).toFixed(2)}`;

  return (
    <div style={pageStyle}>

      {/* HEADER */}
      <div style={headerStyle}>
        <div>
          <h2 style={{ margin: 0 }}>
            📊 Sale History
          </h2>

          <div style={{ fontSize: 13, marginTop: 3 }}>
            Shivam Medical ERP
          </div>
        </div>

        <button
          type="button"
          onClick={goBack}
          style={backButton}
        >
          ⬅️ Dashboard
        </button>
      </div>

      {/* SEARCH */}
      <div style={boxStyle}>
        <input
          type="text"
          placeholder="🔍 Medicine / Customer / Bill No. / Barcode"
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
          style={inputStyle}
        />
      </div>

      {/* SUMMARY */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(3, minmax(150px, 1fr))",
          gap: 10,
          marginBottom: 12,
        }}
      >

        <Summary
          title="Total Quantity"
          value={totalQty}
          color="#1565c0"
        />

        <Summary
          title="Sale Amount"
          value={money(totalAmount)}
          color="#2e7d32"
        />

        <Summary
          title="Profit"
          value={money(totalProfit)}
          color="#00838f"
        />

      </div>

      {/* TABLE */}
      <div style={boxStyle}>

        <h3 style={{ marginTop: 0 }}>
          🧾 Sales
        </h3>

        {filteredSales.length === 0 ? (
          <div style={emptyStyle}>
            कोई Sale History उपलब्ध नहीं है।
          </div>
        ) : (
          <div style={{ overflowX: "auto" }}>

            <table style={tableStyle}>

              <thead>
                <tr>

                  <th style={thStyle}>
                    #
                  </th>

                  <th style={thStyle}>
                    Bill No.
                  </th>

                  <th style={thStyle}>
                    Date
                  </th>

                  <th style={thStyle}>
                    Customer
                  </th>

                  <th style={thStyle}>
                    Medicine
                  </th>

                  <th style={thStyle}>
                    Barcode
                  </th>

                  <th style={thStyle}>
                    Batch
                  </th>

                  <th style={thStyle}>
                    Qty
                  </th>

                  <th style={thStyle}>
                    Sale Rate
                  </th>

                  <th style={thStyle}>
                    Amount
                  </th>

                  <th style={thStyle}>
                    Profit
                  </th>

                  <th style={thStyle}>
                    Udhari
                  </th>

                </tr>
              </thead>

              <tbody>

                {filteredSales.map(
                  (sale, index) => {

                    const amount =
                      Number(
                        sale.saleAmount ||
                          sale.amount ||
                          0
                      );

                    const profit =
                      Number(
                        sale.profit || 0
                      );

                    const udhari =
                      Number(
                        sale.pendingAmount ||
                          sale.udhari ||
                          0
                      );

                    return (
                      <tr
                        key={
                          sale.id ||
                          `${sale.billNumber}-${index}`
                        }
                      >

                        <td style={tdStyle}>
                          {index + 1}
                        </td>

                        <td style={tdStyle}>
                          <b>
                            {sale.billNumber || "-"}
                          </b>
                        </td>

                        <td style={tdStyle}>
                          {sale.date || "-"}
                          <br />
                          <small>
                            {sale.time || ""}
                          </small>
                        </td>

                        <td style={tdStyle}>
                          {sale.customer ||
                            "Cash Customer"}

                          {sale.mobile && (
                            <>
                              <br />
                              <small>
                                📱 {sale.mobile}
                              </small>
                            </>
                          )}
                        </td>

                        <td style={tdStyle}>
                          <b>
                            {sale.medicine || "-"}
                          </b>

                          <br />

                          <small>
                            {sale.company || ""}
                          </small>
                        </td>

                        <td style={tdStyle}>
                          {sale.barcode || "-"}
                        </td>

                        <td style={tdStyle}>
                          {sale.batch || "-"}
                        </td>

                        <td style={tdStyle}>
                          {sale.quantity || 0}
                        </td>

                        <td style={tdStyle}>
                          {money(
                            sale.saleRate
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            fontWeight: "bold",
                          }}
                        >
                          {money(amount)}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              profit >= 0
                                ? "#2e7d32"
                                : "#d32f2f",
                            fontWeight: "bold",
                          }}
                        >
                          {money(profit)}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              udhari > 0
                                ? "#d32f2f"
                                : "#2e7d32",
                            fontWeight: "bold",
                          }}
                        >
                          {money(udhari)}
                        </td>

                      </tr>
                    );
                  }
                )}

              </tbody>

            </table>

          </div>
        )}

      </div>

    </div>
  );
}

function Summary({
  title,
  value,
  color,
}) {
  return (
    <div
      style={{
        background: "white",
        padding: 14,
        borderRadius: 9,
        borderLeft:
          `4px solid ${color}`,
        boxShadow:
          "0 2px 7px rgba(0,0,0,0.06)",
      }}
    >

      <div
        style={{
          fontSize: 12,
          color: "#666",
        }}
      >
        {title}
      </div>

      <div
        style={{
          marginTop: 4,
          fontSize: 20,
          fontWeight: "bold",
          color,
        }}
      >
        {value}
      </div>

    </div>
  );
}

const pageStyle = {
  minHeight: "100vh",
  padding: 12,
  background: "#f2f5f9",
  fontFamily: "Arial, sans-serif",
  boxSizing: "border-box",
};

const headerStyle = {
  background:
    "linear-gradient(135deg,#1565c0,#42a5f5)",
  color: "white",
  padding: 15,
  borderRadius: 10,
  marginBottom: 12,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
};

const boxStyle = {
  background: "white",
  padding: 14,
  borderRadius: 10,
  marginBottom: 12,
  boxShadow:
    "0 2px 8px rgba(0,0,0,0.06)",
};

const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: 11,
  border: "1px solid #ccc",
  borderRadius: 7,
  fontSize: 14,
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse",
  fontSize: 12,
};

const thStyle = {
  border: "1px solid #ddd",
  padding: 8,
  background: "#f1f5f9",
  whiteSpace: "nowrap",
};

const tdStyle = {
  border: "1px solid #ddd",
  padding: 8,
  whiteSpace: "nowrap",
};

const backButton = {
  background: "white",
  color: "#1565c0",
  border: "none",
  padding: "9px 14px",
  borderRadius: 7,
  fontWeight: "bold",
  cursor: "pointer",
};

const emptyStyle = {
  padding: 25,
  textAlign: "center",
  color: "#777",
};

export default SaleHistory;