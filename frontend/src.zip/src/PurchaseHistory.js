import React, { useMemo, useState } from "react";

function PurchaseHistory({ goBack }) {
  const [search, setSearch] = useState("");
  const [supplierFilter, setSupplierFilter] = useState("All");
  const [selectedPurchase, setSelectedPurchase] = useState(null);

  // ==============================
  // LOAD PURCHASE HISTORY
  // ==============================

  const loadPurchases = () => {
    try {
      const saved = localStorage.getItem("purchaseHistory");

      if (!saved) {
        return [];
      }

      const data = JSON.parse(saved);

      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error("Purchase history load error:", error);
      return [];
    }
  };

  const purchases = loadPurchases();

  // ==============================
  // SUPPLIER LIST
  // ==============================

  const suppliers = useMemo(() => {
    const names = purchases
      .map((item) =>
        String(item.supplier || "Unknown").trim()
      )
      .filter(Boolean);

    return ["All", ...new Set(names)];
  }, [purchases]);

  // ==============================
  // GET PURCHASE AMOUNT
  // ==============================

  const getPurchaseAmount = (purchase) => {
    const savedAmount = Number(
      purchase.purchaseAmount || 0
    );

    if (savedAmount > 0) {
      return savedAmount;
    }

    const quantity = Number(
      purchase.quantity || 0
    );

    const rate = Number(
      purchase.rate ||
        purchase.purchaseRate ||
        0
    );

    return quantity * rate;
  };

  // ==============================
  // FILTER
  // ==============================

  const filteredPurchases = useMemo(() => {
    const text = search
      .trim()
      .toLowerCase();

    return purchases.filter((purchase) => {
      const medicine = String(
        purchase.medicine || ""
      ).toLowerCase();

      const company = String(
        purchase.company || ""
      ).toLowerCase();

      const supplier = String(
        purchase.supplier || "Unknown"
      ).toLowerCase();

      const batch = String(
        purchase.batch || ""
      ).toLowerCase();

      const date = String(
        purchase.date || ""
      ).toLowerCase();

      const matchesSearch =
        !text ||
        medicine.includes(text) ||
        company.includes(text) ||
        supplier.includes(text) ||
        batch.includes(text) ||
        date.includes(text);

      const matchesSupplier =
        supplierFilter === "All" ||
        String(
          purchase.supplier || "Unknown"
        ).trim() === supplierFilter;

      return (
        matchesSearch &&
        matchesSupplier
      );
    });
  }, [
    purchases,
    search,
    supplierFilter,
  ]);

  // ==============================
  // SUMMARY
  // ==============================

  const totalPurchaseAmount =
    filteredPurchases.reduce(
      (sum, purchase) =>
        sum +
        getPurchaseAmount(purchase),
      0
    );

  const totalQuantity =
    filteredPurchases.reduce(
      (sum, purchase) =>
        sum +
        Number(
          purchase.quantity || 0
        ),
      0
    );

  // ==============================
  // DELETE PURCHASE
  // ==============================

  const deletePurchase = (index) => {
    const purchase =
      filteredPurchases[index];

    if (!purchase) {
      return;
    }

    const confirmDelete =
      window.confirm(
        "क्या आप यह Purchase History delete करना चाहते हैं?"
      );

    if (!confirmDelete) {
      return;
    }

    const originalIndex =
      purchases.indexOf(purchase);

    if (originalIndex === -1) {
      return;
    }

    const updatedPurchases = [
      ...purchases,
    ];

    updatedPurchases.splice(
      originalIndex,
      1
    );

    localStorage.setItem(
      "purchaseHistory",
      JSON.stringify(
        updatedPurchases
      )
    );

    alert(
      "✅ Purchase deleted successfully"
    );

    window.location.reload();
  };

  // ==============================
  // CLEAR ALL HISTORY
  // ==============================

  const clearHistory = () => {
    if (purchases.length === 0) {
      alert(
        "Purchase History पहले से खाली है।"
      );
      return;
    }

    const confirmClear =
      window.confirm(
        "⚠️ क्या आप पूरी Purchase History delete करना चाहते हैं?\n\nयह action वापस नहीं किया जा सकता।"
      );

    if (!confirmClear) {
      return;
    }

    localStorage.removeItem(
      "purchaseHistory"
    );

    alert(
      "✅ पूरी Purchase History delete हो गई।"
    );

    window.location.reload();
  };

  // ==============================
  // SELECTED PURCHASE DETAIL
  // ==============================

  if (selectedPurchase) {
    const amount =
      getPurchaseAmount(
        selectedPurchase
      );

    return (
      <div
        style={{
          minHeight: "100vh",
          padding: "20px",
          background: "#f2f5f9",
          fontFamily:
            "Arial, sans-serif",
        }}
      >
        <button
          onClick={() =>
            setSelectedPurchase(null)
          }
          style={backButtonStyle}
        >
          ⬅️ Purchase History
        </button>

        <div
          style={{
            maxWidth: "900px",
            margin: "0 auto",
            background: "white",
            padding: "25px",
            borderRadius: "14px",
            boxShadow:
              "0 3px 12px rgba(0,0,0,0.08)",
          }}
        >
          <h1>
            🧾 Purchase Details
          </h1>

          <hr />

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit,minmax(220px,1fr))",
              gap: "15px",
            }}
          >
            <InfoBox
              title="💊 Medicine"
              value={
                selectedPurchase.medicine ||
                "-"
              }
            />

            <InfoBox
              title="🏢 Company"
              value={
                selectedPurchase.company ||
                "-"
              }
            />

            <InfoBox
              title="🏭 Supplier"
              value={
                selectedPurchase.supplier ||
                "Unknown"
              }
            />

            <InfoBox
              title="🔢 Batch"
              value={
                selectedPurchase.batch ||
                "-"
              }
            />

            <InfoBox
              title="📦 Quantity"
              value={
                selectedPurchase.quantity ||
                0
              }
            />

            <InfoBox
              title="💰 Purchase Rate"
              value={
                "₹" +
                Number(
                  selectedPurchase.rate ||
                    selectedPurchase.purchaseRate ||
                    0
                ).toFixed(2)
              }
            />

            <InfoBox
              title="💵 Purchase Amount"
              value={
                "₹" +
                amount.toFixed(2)
              }
            />

            <InfoBox
              title="📅 Date"
              value={
                selectedPurchase.date ||
                "-"
              }
            />

            <InfoBox
              title="⏰ Time"
              value={
                selectedPurchase.time ||
                "-"
              }
            />

            <InfoBox
              title="📅 Expiry"
              value={
                selectedPurchase.expiry ||
                "-"
              }
            />
          </div>

          <div
            style={{
              marginTop: "25px",
              padding: "20px",
              background: "#e8f5e9",
              borderRadius: "10px",
              textAlign: "center",
            }}
          >
            <h2
              style={{
                margin: 0,
                color: "#2e7d32",
              }}
            >
              Total Purchase: ₹
              {amount.toFixed(2)}
            </h2>
          </div>
        </div>
      </div>
    );
  }

  // ==============================
  // MAIN PAGE
  // ==============================

  return (
    <div
      style={{
        minHeight: "100vh",
        padding: "20px",
        background: "#f2f5f9",
        fontFamily:
          "Arial, sans-serif",
      }}
    >
      {/* HEADER */}

      <div
        style={{
          background:
            "linear-gradient(135deg,#6a1b9a,#ab47bc)",
          color: "white",
          padding: "25px",
          borderRadius: "14px",
          marginBottom: "20px",
        }}
      >
        <h1
          style={{
            margin: 0,
          }}
        >
          🧾 Purchase History
        </h1>

        <p
          style={{
            marginBottom: 0,
          }}
        >
          सभी Purchase Entries की पूरी history
        </p>
      </div>

      {/* BACK BUTTON */}

      <button
        onClick={goBack}
        style={backButtonStyle}
      >
        ⬅️ Dashboard
      </button>

      {/* SUMMARY */}

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit,minmax(200px,1fr))",
          gap: "15px",
          marginTop: "20px",
          marginBottom: "20px",
        }}
      >
        <div
          style={{
            background: "white",
            padding: "20px",
            borderRadius: "12px",
            boxShadow:
              "0 3px 10px rgba(0,0,0,0.07)",
          }}
        >
          <b>🧾 Total Entries</b>

          <h2
            style={{
              marginBottom: 0,
              color: "#6a1b9a",
            }}
          >
            {filteredPurchases.length}
          </h2>
        </div>

        <div
          style={{
            background: "white",
            padding: "20px",
            borderRadius: "12px",
            boxShadow:
              "0 3px 10px rgba(0,0,0,0.07)",
          }}
        >
          <b>📦 Total Quantity</b>

          <h2
            style={{
              marginBottom: 0,
              color: "#1976d2",
            }}
          >
            {totalQuantity}
          </h2>
        </div>

        <div
          style={{
            background: "white",
            padding: "20px",
            borderRadius: "12px",
            boxShadow:
              "0 3px 10px rgba(0,0,0,0.07)",
          }}
        >
          <b>💰 Total Purchase</b>

          <h2
            style={{
              marginBottom: 0,
              color: "#2e7d32",
            }}
          >
            ₹
            {totalPurchaseAmount.toFixed(
              2
            )}
          </h2>
        </div>
      </div>

      {/* SEARCH */}

      <div
        style={{
          background: "white",
          padding: "20px",
          borderRadius: "12px",
          marginBottom: "20px",
          boxShadow:
            "0 3px 10px rgba(0,0,0,0.06)",
        }}
      >
        <input
          type="text"
          placeholder="🔍 Medicine / Supplier / Company / Batch Search करें"
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
          style={{
            width: "100%",
            boxSizing: "border-box",
            padding: "13px",
            fontSize: "16px",
            border:
              "1px solid #ccc",
            borderRadius: "7px",
            marginBottom: "12px",
          }}
        />

        <select
          value={supplierFilter}
          onChange={(e) =>
            setSupplierFilter(
              e.target.value
            )
          }
          style={{
            width: "100%",
            padding: "13px",
            fontSize: "16px",
            border:
              "1px solid #ccc",
            borderRadius: "7px",
          }}
        >
          {suppliers.map(
            (supplier, index) => (
              <option
                key={index}
                value={supplier}
              >
                {supplier === "All"
                  ? "🏭 सभी Supplier"
                  : supplier}
              </option>
            )
          )}
        </select>
      </div>

      {/* ACTION */}

      <div
        style={{
          marginBottom: "20px",
        }}
      >
        <button
          onClick={clearHistory}
          style={{
            padding: "11px 18px",
            background: "#d32f2f",
            color: "white",
            border: "none",
            borderRadius: "7px",
            cursor: "pointer",
            fontWeight: "bold",
          }}
        >
          🗑️ Clear Purchase History
        </button>
      </div>

      {/* TABLE */}

      <div
        style={{
          background: "white",
          padding: "20px",
          borderRadius: "12px",
          overflowX: "auto",
          boxShadow:
            "0 3px 10px rgba(0,0,0,0.06)",
        }}
      >
        <h2>
          📋 Purchase Entries
        </h2>

        {filteredPurchases.length ===
        0 ? (
          <div
            style={{
              padding: "30px",
              textAlign: "center",
            }}
          >
            <h3>
              📭 कोई Purchase Record नहीं मिला।
            </h3>

            <p>
              Purchase करने के बाद entries
              यहाँ दिखाई देंगी।
            </p>
          </div>
        ) : (
          <table
            border="1"
            cellPadding="9"
            style={{
              borderCollapse:
                "collapse",
              width: "100%",
              minWidth: "1200px",
            }}
          >
            <thead
              style={{
                background: "#f3e5f5",
              }}
            >
              <tr>
                <th>#</th>
                <th>Date</th>
                <th>Medicine</th>
                <th>Company</th>
                <th>Supplier</th>
                <th>Batch</th>
                <th>Qty</th>
                <th>Rate</th>
                <th>Amount</th>
                <th>Expiry</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {filteredPurchases.map(
                (purchase, index) => {
                  const amount =
                    getPurchaseAmount(
                      purchase
                    );

                  return (
                    <tr key={index}>
                      <td>
                        {index + 1}
                      </td>

                      <td>
                        {purchase.date ||
                          "-"}

                        <br />

                        <small>
                          {purchase.time ||
                            ""}
                        </small>
                      </td>

                      <td>
                        <b>
                          {purchase.medicine ||
                            "-"}
                        </b>
                      </td>

                      <td>
                        {purchase.company ||
                          "-"}
                      </td>

                      <td>
                        {purchase.supplier ||
                          "Unknown"}
                      </td>

                      <td>
                        {purchase.batch ||
                          "-"}
                      </td>

                      <td>
                        {purchase.quantity ||
                          0}
                      </td>

                      <td>
                        ₹
                        {Number(
                          purchase.rate ||
                            purchase.purchaseRate ||
                            0
                        ).toFixed(2)}
                      </td>

                      <td
                        style={{
                          fontWeight:
                            "bold",
                        }}
                      >
                        ₹
                        {amount.toFixed(2)}
                      </td>

                      <td>
                        {purchase.expiry ||
                          "-"}
                      </td>

                      <td>
                        <button
                          onClick={() =>
                            setSelectedPurchase(
                              purchase
                            )
                          }
                          style={{
                            padding:
                              "7px 10px",
                            background:
                              "#1976d2",
                            color:
                              "white",
                            border:
                              "none",
                            borderRadius:
                              "5px",
                            cursor:
                              "pointer",
                            marginRight:
                              "5px",
                          }}
                        >
                          👁️ View
                        </button>

                        <button
                          onClick={() =>
                            deletePurchase(
                              index
                            )
                          }
                          style={{
                            padding:
                              "7px 10px",
                            background:
                              "#d32f2f",
                            color:
                              "white",
                            border:
                              "none",
                            borderRadius:
                              "5px",
                            cursor:
                              "pointer",
                          }}
                        >
                          🗑️
                        </button>
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ==============================
// INFO BOX
// ==============================

function InfoBox({ title, value }) {
  return (
    <div
      style={{
        padding: "16px",
        background: "#f5f5f5",
        borderRadius: "9px",
        border:
          "1px solid #e0e0e0",
      }}
    >
      <div
        style={{
          fontSize: "14px",
          color: "#666",
          marginBottom: "6px",
        }}
      >
        {title}
      </div>

      <strong
        style={{
          fontSize: "17px",
        }}
      >
        {value}
      </strong>
    </div>
  );
}

// ==============================
// BACK BUTTON STYLE
// ==============================

const backButtonStyle = {
  padding: "11px 20px",
  background: "#555",
  color: "white",
  border: "none",
  borderRadius: "7px",
  cursor: "pointer",
  fontSize: "15px",
};

export default PurchaseHistory;