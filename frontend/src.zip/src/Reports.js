import React, { useMemo, useState } from "react";

function Reports({ goBack }) {
  const [filter, setFilter] = useState("sale");
  const [search, setSearch] = useState("");

  // =========================================
  // GET ARRAY FROM LOCAL STORAGE
  // =========================================

  const getArray = (key) => {
    try {
      const data = JSON.parse(
        localStorage.getItem(key) || "[]"
      );

      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  };

  // =========================================
  // LOAD DATA
  // =========================================

  const bills = getArray("bills");
  const sales = getArray("sales");

  const purchases = getArray("purchases");
  const purchaseHistory = getArray("purchaseHistory");

  const customerPayments = getArray(
    "customerPayments"
  );

  const supplierPayments = getArray(
    "supplierPayments"
  );

  const stock = useMemo(() => {
    try {
      const data = JSON.parse(
        localStorage.getItem("stock") || "[]"
      );

      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  }, []);

  // =========================================
  // MONEY
  // =========================================

  const money = (value) =>
    `₹${Number(value || 0).toFixed(2)}`;

  const text = search.trim().toLowerCase();

  // =========================================
  // DATE + TIME HELPER
  // =========================================

  const getDateTime = (item) => {
    const date = String(
      item?.date || ""
    ).trim();

    const time = String(
      item?.time || ""
    ).trim();

    if (date && time) {
      return `${date} ${time}`;
    }

    if (date) {
      return date;
    }

    if (time) {
      return time;
    }

    // पुराने records में createdAt हो तो
    if (item?.createdAt) {
      try {
        const d = new Date(
          item.createdAt
        );

        if (!Number.isNaN(d.getTime())) {
          return d.toLocaleString("en-IN", {
            dateStyle: "short",
            timeStyle: "short",
          });
        }
      } catch {
        return "-";
      }
    }

    return "-";
  };

  // =========================================
  // SUPPLIER NAME
  // =========================================

  const getSupplierName = (item) => {
    return String(
      item?.supplier ||
        item?.supplierName ||
        item?.vendor ||
        item?.vendorName ||
        ""
    ).trim();
  };

  // =========================================
  // PURCHASE AMOUNT
  // =========================================

  const getPurchaseAmount = (item) => {
    const directAmount = Number(
      item?.total ??
        item?.purchaseAmount ??
        item?.totalAmount ??
        item?.amount ??
        item?.purchaseTotal ??
        0
    );

    if (
      Number.isFinite(directAmount) &&
      directAmount > 0
    ) {
      return directAmount;
    }

    const quantity = Number(
      item?.quantity ??
        item?.qty ??
        item?.quantityPurchased ??
        0
    );

    const rate = Number(
      item?.purchaseRate ??
        item?.rate ??
        item?.buyRate ??
        0
    );

    return quantity * rate;
  };

  // =========================================
  // PAYMENT AMOUNT
  // =========================================

  const getPaymentAmount = (item) => {
    return Number(
      item?.amount ??
        item?.paidAmount ??
        item?.payment ??
        item?.paymentAmount ??
        0
    );
  };

  // =========================================
  // SALE REPORT
  // =========================================

  const saleReport = useMemo(() => {
    return sales.filter((item) => {
      if (!text) return true;

      return (
        String(item.billNumber || "")
          .toLowerCase()
          .includes(text) ||
        String(item.customer || "")
          .toLowerCase()
          .includes(text) ||
        String(item.mobile || "")
          .toLowerCase()
          .includes(text) ||
        String(item.medicine || "")
          .toLowerCase()
          .includes(text) ||
        String(item.barcode || "")
          .toLowerCase()
          .includes(text)
      );
    });
  }, [sales, text]);

  const totalSale = saleReport.reduce(
    (sum, item) =>
      sum +
      Number(
        item.saleAmount ||
          item.amount ||
          0
      ),
    0
  );

  const totalProfit = saleReport.reduce(
    (sum, item) =>
      sum + Number(item.profit || 0),
    0
  );

  // =========================================
  // CUSTOMER UDHARI
  // =========================================

  const customerReport = useMemo(() => {
    const map = {};

    // -----------------------------------------
    // BILLS
    // -----------------------------------------

    bills.forEach((bill) => {
      const name = String(
        bill.customer || "Cash Customer"
      ).trim();

      const mobile = String(
        bill.mobile || ""
      ).trim();

      const key =
        `${name.toLowerCase()}_${mobile}`;

      if (!map[key]) {
        map[key] = {
          name,
          mobile,
          total: 0,
          paid: 0,
          udhari: 0,
          lastDate: "",
          lastTime: "",
          lastCreatedAt: 0,
        };
      }

      map[key].total += Number(
        bill.total ||
          bill.totalAmount ||
          bill.amount ||
          0
      );

      map[key].paid += Number(
        bill.paidAmount ||
          bill.paid ||
          0
      );

      // Last transaction
      const created =
        Number(bill.createdAt || 0);

      if (
        created >=
        Number(map[key].lastCreatedAt || 0)
      ) {
        map[key].lastDate =
          bill.date || "";

        map[key].lastTime =
          bill.time || "";

        map[key].lastCreatedAt =
          created;
      }
    });

    // -----------------------------------------
    // CUSTOMER PAYMENTS
    // -----------------------------------------

    customerPayments.forEach(
      (payment) => {
        const name = String(
          payment.customer ||
            payment.customerName ||
            ""
        ).trim();

        const mobile = String(
          payment.mobile ||
            payment.phone ||
            ""
        ).trim();

        if (!name) return;

        const key =
          `${name.toLowerCase()}_${mobile}`;

        if (!map[key]) {
          map[key] = {
            name,
            mobile,
            total: 0,
            paid: 0,
            udhari: 0,
            lastDate: "",
            lastTime: "",
            lastCreatedAt: 0,
          };
        }

        map[key].paid += Number(
          payment.amount ||
            payment.paidAmount ||
            payment.payment ||
            0
        );

        // Payment date/time
        const created =
          Number(payment.createdAt || 0);

        if (
          created >=
          Number(map[key].lastCreatedAt || 0)
        ) {
          map[key].lastDate =
            payment.date || "";

          map[key].lastTime =
            payment.time || "";

          map[key].lastCreatedAt =
            created;
        }
      }
    );

    return Object.values(map)
      .map((item) => ({
        ...item,

        udhari: Math.max(
          item.total - item.paid,
          0
        ),
      }))
      .filter((item) => {
        if (!text) return true;

        return (
          item.name
            .toLowerCase()
            .includes(text) ||
          item.mobile
            .toLowerCase()
            .includes(text)
        );
      });
  }, [
    bills,
    customerPayments,
    text,
  ]);

  // =========================================
  // SUPPLIER UDHARI
  // =========================================

  const supplierReport = useMemo(() => {
    const map = {};

    const allPurchases = [
      ...purchases,
      ...purchaseHistory,
    ];

    // -----------------------------------------
    // PURCHASES
    // -----------------------------------------

    allPurchases.forEach((purchase) => {
      const name =
        getSupplierName(purchase);

      if (!name) return;

      const key =
        name.toLowerCase();

      if (!map[key]) {
        map[key] = {
          supplier: name,
          total: 0,
          paid: 0,
          udhari: 0,
          lastDate: "",
          lastTime: "",
          lastCreatedAt: 0,
        };
      }

      map[key].total +=
        getPurchaseAmount(
          purchase
        );

      const created =
        Number(
          purchase.createdAt || 0
        );

      if (
        created >=
        Number(
          map[key].lastCreatedAt || 0
        )
      ) {
        map[key].lastDate =
          purchase.date || "";

        map[key].lastTime =
          purchase.time || "";

        map[key].lastCreatedAt =
          created;
      }
    });

    // -----------------------------------------
    // SUPPLIER PAYMENTS
    // -----------------------------------------

    supplierPayments.forEach(
      (payment) => {
        const name =
          getSupplierName(payment);

        if (!name) return;

        const key =
          name.toLowerCase();

        if (!map[key]) {
          map[key] = {
            supplier: name,
            total: 0,
            paid: 0,
            udhari: 0,
            lastDate: "",
            lastTime: "",
            lastCreatedAt: 0,
          };
        }

        map[key].paid +=
          getPaymentAmount(
            payment
          );

        const created =
          Number(
            payment.createdAt || 0
          );

        if (
          created >=
          Number(
            map[key].lastCreatedAt || 0
          )
        ) {
          map[key].lastDate =
            payment.date || "";

          map[key].lastTime =
            payment.time || "";

          map[key].lastCreatedAt =
            created;
        }
      }
    );

    // -----------------------------------------
    // FINAL
    // -----------------------------------------

    return Object.values(map)
      .map((item) => ({
        ...item,

        udhari: Math.max(
          item.total - item.paid,
          0
        ),
      }))
      .filter((item) => {
        if (!text) return true;

        return item.supplier
          .toLowerCase()
          .includes(text);
      });
  }, [
    purchases,
    purchaseHistory,
    supplierPayments,
    text,
  ]);

  // =========================================
  // SUPPLIER TOTALS
  // =========================================

  const supplierTotalPurchase =
    supplierReport.reduce(
      (sum, item) =>
        sum +
        Number(item.total || 0),
      0
    );

  const supplierTotalPaid =
    supplierReport.reduce(
      (sum, item) =>
        sum +
        Number(item.paid || 0),
      0
    );

  const supplierTotalUdhari =
    supplierReport.reduce(
      (sum, item) =>
        sum +
        Number(item.udhari || 0),
      0
    );

  // =========================================
  // PURCHASE REPORT
  // =========================================

  const purchaseReport = useMemo(() => {
    const allPurchases = [
      ...purchases,
      ...purchaseHistory,
    ];

    return allPurchases.filter(
      (item) => {
        if (!text) return true;

        return (
          String(item.medicine || "")
            .toLowerCase()
            .includes(text) ||
          getSupplierName(item)
            .toLowerCase()
            .includes(text) ||
          String(item.company || "")
            .toLowerCase()
            .includes(text) ||
          String(
            item.invoiceNumber || ""
          )
            .toLowerCase()
            .includes(text)
        );
      }
    );
  }, [
    purchases,
    purchaseHistory,
    text,
  ]);

  const totalPurchase =
    purchaseReport.reduce(
      (sum, item) =>
        sum +
        getPurchaseAmount(item),
      0
    );

  // =========================================
  // STOCK REPORT
  // =========================================

  const stockReport =
    stock.filter((item) => {
      if (!text) return true;

      return (
        String(item.medicine || "")
          .toLowerCase()
          .includes(text) ||
        String(item.company || "")
          .toLowerCase()
          .includes(text) ||
        String(item.barcode || "")
          .toLowerCase()
          .includes(text)
      );
    });

  // =========================================
  // EXPIRY REPORT
  // =========================================

  const expiryReport =
    stockReport.filter((item) => {
      if (!item.expiry) {
        return false;
      }

      const expiry = new Date(
        item.expiry
      );

      if (
        Number.isNaN(
          expiry.getTime()
        )
      ) {
        return false;
      }

      const today = new Date();

      const diff =
        expiry.getTime() -
        today.getTime();

      const days =
        diff /
        (1000 * 60 * 60 * 24);

      return (
        days >= 0 &&
        days <= 30
      );
    });

  // =========================================
  // UI
  // =========================================

  return (
    <div style={pageStyle}>

      {/* HEADER */}

      <div style={headerStyle}>

        <div>
          <h2
            style={{
              margin: 0,
            }}
          >
            📊 Reports
          </h2>

          <div
            style={{
              fontSize: 13,
              marginTop: 4,
            }}
          >
            Shivam Medical ERP
          </div>
        </div>

        <button
          onClick={goBack}
          style={backButton}
        >
          ⬅️ Dashboard
        </button>

      </div>

      {/* FILTER */}

      <div style={filterBox}>

        <h3
          style={{
            marginTop: 0,
          }}
        >
          🔎 Report Filter
        </h3>

        <select
          value={filter}
          onChange={(e) =>
            setFilter(
              e.target.value
            )
          }
          style={selectStyle}
        >

          <option value="sale">
            💰 Sale Report
          </option>

          <option value="profit">
            📈 Profit Report
          </option>

          <option value="customer">
            👤 Customer Udhari
          </option>

          <option value="supplier">
            🏭 Supplier Udhari
          </option>

          <option value="purchase">
            🛒 Purchase Report
          </option>

          <option value="stock">
            📦 Stock Report
          </option>

          <option value="expiry">
            📅 Expiry Report
          </option>

        </select>

        <input
          type="text"
          value={search}
          onChange={(e) =>
            setSearch(
              e.target.value
            )
          }
          placeholder="🔍 Search..."
          style={inputStyle}
        />

      </div>

      {/* =====================================
          SALE / PROFIT
      ===================================== */}

      {(filter === "sale" ||
        filter === "profit") && (
        <div style={boxStyle}>

          <div style={summaryGrid}>

            <Summary
              title="Total Sale"
              value={money(
                totalSale
              )}
              color="#1565c0"
            />

            <Summary
              title="Total Profit"
              value={money(
                totalProfit
              )}
              color="#2e7d32"
            />

            <Summary
              title="Entries"
              value={
                saleReport.length
              }
              color="#00838f"
            />

          </div>

          <h3>
            {filter === "sale"
              ? "💰 Sale Report"
              : "📈 Profit Report"}
          </h3>

          <div style={scroll}>

            <table
              style={tableStyle}
            >

              <thead>

                <tr>

                  <th
                    style={thStyle}
                  >
                    #
                  </th>

                  <th
                    style={thStyle}
                  >
                    Bill No.
                  </th>

                  <th
                    style={thStyle}
                  >
                    Date & Time
                  </th>

                  <th
                    style={thStyle}
                  >
                    Customer
                  </th>

                  <th
                    style={thStyle}
                  >
                    Medicine
                  </th>

                  <th
                    style={thStyle}
                  >
                    Qty
                  </th>

                  <th
                    style={thStyle}
                  >
                    Sale Rate
                  </th>

                  <th
                    style={thStyle}
                  >
                    Sale
                  </th>

                  <th
                    style={thStyle}
                  >
                    Profit
                  </th>

                  <th
                    style={thStyle}
                  >
                    Udhari
                  </th>

                </tr>

              </thead>

              <tbody>

                {saleReport.length ===
                0 ? (

                  <tr>

                    <td
                      colSpan="10"
                      style={{
                        ...tdStyle,
                        textAlign:
                          "center",
                        padding: 25,
                        color:
                          "#777",
                      }}
                    >
                      ⚠️ कोई Sale
                      Record नहीं मिला।
                    </td>

                  </tr>

                ) : (

                  saleReport.map(
                    (
                      item,
                      index
                    ) => (

                      <tr
                        key={
                          item.id ||
                          index
                        }
                      >

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {index + 1}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.billNumber ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          <b>
                            {getDateTime(
                              item
                            )}
                          </b>
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.customer ||
                            "Cash Customer"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.medicine ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.quantity ||
                            0}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {money(
                            item.saleRate
                          )}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {money(
                            item.saleAmount ||
                              item.amount
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              "#2e7d32",
                            fontWeight:
                              "bold",
                          }}
                        >
                          {money(
                            item.profit
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              "#d32f2f",
                          }}
                        >
                          {money(
                            item.pendingAmount ||
                              item.udhari
                          )}
                        </td>

                      </tr>

                    )
                  )

                )}

              </tbody>

            </table>

          </div>

        </div>
      )}

      {/* =====================================
          CUSTOMER UDHARI
      ===================================== */}

      {filter === "customer" && (
        <div style={boxStyle}>

          <h3>
            👤 Customer Udhari Report
          </h3>

          <div style={scroll}>

            <table
              style={tableStyle}
            >

              <thead>

                <tr>

                  <th
                    style={thStyle}
                  >
                    #
                  </th>

                  <th
                    style={thStyle}
                  >
                    Customer
                  </th>

                  <th
                    style={thStyle}
                  >
                    Mobile
                  </th>

                  <th
                    style={thStyle}
                  >
                    Last Date & Time
                  </th>

                  <th
                    style={thStyle}
                  >
                    Total Bill
                  </th>

                  <th
                    style={thStyle}
                  >
                    Paid
                  </th>

                  <th
                    style={thStyle}
                  >
                    Udhari
                  </th>

                </tr>

              </thead>

              <tbody>

                {customerReport.length ===
                0 ? (

                  <tr>

                    <td
                      colSpan="7"
                      style={{
                        ...tdStyle,
                        textAlign:
                          "center",
                        padding: 25,
                        color:
                          "#777",
                      }}
                    >
                      ⚠️ कोई Customer
                      Data नहीं मिला।
                    </td>

                  </tr>

                ) : (

                  customerReport.map(
                    (
                      item,
                      index
                    ) => (

                      <tr
                        key={index}
                      >

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {index + 1}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          <b>
                            {item.name}
                          </b>
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.mobile ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          <b>
                            {getDateTime(
                              {
                                date:
                                  item.lastDate,
                                time:
                                  item.lastTime,
                              }
                            )}
                          </b>
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {money(
                            item.total
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              "#2e7d32",
                          }}
                        >
                          {money(
                            item.paid
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              item.udhari >
                              0
                                ? "#d32f2f"
                                : "#2e7d32",
                            fontWeight:
                              "bold",
                          }}
                        >
                          {money(
                            item.udhari
                          )}
                        </td>

                      </tr>

                    )
                  )

                )}

              </tbody>

            </table>

          </div>

        </div>
      )}

      {/* =====================================
          SUPPLIER UDHARI
      ===================================== */}

      {filter === "supplier" && (
        <div style={boxStyle}>

          <div style={summaryGrid}>

            <Summary
              title="Total Purchase"
              value={money(
                supplierTotalPurchase
              )}
              color="#ef6c00"
            />

            <Summary
              title="Total Paid"
              value={money(
                supplierTotalPaid
              )}
              color="#2e7d32"
            />

            <Summary
              title="Total Supplier Udhari"
              value={money(
                supplierTotalUdhari
              )}
              color="#d32f2f"
            />

          </div>

          <h3>
            🏭 Supplier Udhari Report
          </h3>

          <div style={scroll}>

            <table
              style={tableStyle}
            >

              <thead>

                <tr>

                  <th
                    style={thStyle}
                  >
                    #
                  </th>

                  <th
                    style={thStyle}
                  >
                    Supplier
                  </th>

                  <th
                    style={thStyle}
                  >
                    Last Date & Time
                  </th>

                  <th
                    style={thStyle}
                  >
                    Purchase
                  </th>

                  <th
                    style={thStyle}
                  >
                    Paid
                  </th>

                  <th
                    style={thStyle}
                  >
                    Udhari
                  </th>

                </tr>

              </thead>

              <tbody>

                {supplierReport.length ===
                0 ? (

                  <tr>

                    <td
                      colSpan="6"
                      style={{
                        ...tdStyle,
                        textAlign:
                          "center",
                        padding: 25,
                        color:
                          "#777",
                      }}
                    >
                      ⚠️ कोई Supplier
                      Purchase या
                      Payment Data
                      नहीं मिला।
                    </td>

                  </tr>

                ) : (

                  supplierReport.map(
                    (
                      item,
                      index
                    ) => (

                      <tr
                        key={index}
                      >

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {index + 1}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          <b>
                            {item.supplier}
                          </b>
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          <b>
                            {getDateTime(
                              {
                                date:
                                  item.lastDate,
                                time:
                                  item.lastTime,
                              }
                            )}
                          </b>
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {money(
                            item.total
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              "#2e7d32",
                            fontWeight:
                              "bold",
                          }}
                        >
                          {money(
                            item.paid
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              item.udhari >
                              0
                                ? "#d32f2f"
                                : "#2e7d32",
                            fontWeight:
                              "bold",
                          }}
                        >
                          {money(
                            item.udhari
                          )}
                        </td>

                      </tr>

                    )
                  )

                )}

              </tbody>

            </table>

          </div>

        </div>
      )}

      {/* =====================================
          PURCHASE
      ===================================== */}

      {filter === "purchase" && (
        <div style={boxStyle}>

          <h3>
            🛒 Purchase Report
          </h3>

          <Summary
            title="Total Purchase"
            value={money(
              totalPurchase
            )}
            color="#ef6c00"
          />

          <br />

          <div style={scroll}>

            <table
              style={tableStyle}
            >

              <thead>

                <tr>

                  <th
                    style={thStyle}
                  >
                    #
                  </th>

                  <th
                    style={thStyle}
                  >
                    Date & Time
                  </th>

                  <th
                    style={thStyle}
                  >
                    Supplier
                  </th>

                  <th
                    style={thStyle}
                  >
                    Medicine
                  </th>

                  <th
                    style={thStyle}
                  >
                    Company
                  </th>

                  <th
                    style={thStyle}
                  >
                    Qty
                  </th>

                  <th
                    style={thStyle}
                  >
                    Amount
                  </th>

                </tr>

              </thead>

              <tbody>

                {purchaseReport.length ===
                0 ? (

                  <tr>

                    <td
                      colSpan="7"
                      style={{
                        ...tdStyle,
                        textAlign:
                          "center",
                        padding: 25,
                        color:
                          "#777",
                      }}
                    >
                      ⚠️ कोई Purchase
                      Record नहीं मिला।
                    </td>

                  </tr>

                ) : (

                  purchaseReport.map(
                    (
                      item,
                      index
                    ) => (

                      <tr
                        key={
                          item.id ||
                          index
                        }
                      >

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {index + 1}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          <b>
                            {getDateTime(
                              item
                            )}
                          </b>
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {getSupplierName(
                            item
                          ) || "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.medicine ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.company ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.quantity ||
                            item.qty ||
                            0}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {money(
                            getPurchaseAmount(
                              item
                            )
                          )}
                        </td>

                      </tr>

                    )
                  )

                )}

              </tbody>

            </table>

          </div>

        </div>
      )}

      {/* =====================================
          STOCK
      ===================================== */}

      {filter === "stock" && (
        <div style={boxStyle}>

          <h3>
            📦 Stock Report
          </h3>

          <div style={scroll}>

            <table
              style={tableStyle}
            >

              <thead>

                <tr>

                  <th
                    style={thStyle}
                  >
                    #
                  </th>

                  <th
                    style={thStyle}
                  >
                    Medicine
                  </th>

                  <th
                    style={thStyle}
                  >
                    Company
                  </th>

                  <th
                    style={thStyle}
                  >
                    Barcode
                  </th>

                  <th
                    style={thStyle}
                  >
                    Qty
                  </th>

                  <th
                    style={thStyle}
                  >
                    Purchase Rate
                  </th>

                  <th
                    style={thStyle}
                  >
                    Sale Rate
                  </th>

                  <th
                    style={thStyle}
                  >
                    Expiry
                  </th>

                </tr>

              </thead>

              <tbody>

                {stockReport.map(
                  (
                    item,
                    index
                  ) => (

                    <tr
                      key={
                        item.id ||
                        index
                      }
                    >

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {index + 1}
                      </td>

                      <td
                        style={
                          tdStyle
                        }
                      >
                        <b>
                          {item.medicine ||
                            "-"}
                        </b>
                      </td>

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {item.company ||
                          "-"}
                      </td>

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {item.barcode ||
                          "-"}
                      </td>

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {item.quantity ||
                          0}
                      </td>

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {money(
                          item.purchaseRate ||
                            item.rate
                        )}
                      </td>

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {money(
                          item.saleRate ||
                            item.mrp
                        )}
                      </td>

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {item.expiry ||
                          "-"}
                      </td>

                    </tr>

                  )
                )}

              </tbody>

            </table>

          </div>

        </div>
      )}

      {/* =====================================
          EXPIRY
      ===================================== */}

      {filter === "expiry" && (
        <div style={boxStyle}>

          <h3
            style={{
              color:
                "#d32f2f",
            }}
          >
            📅 Expiry Alert Report
          </h3>

          <div style={scroll}>

            <table
              style={tableStyle}
            >

              <thead>

                <tr>

                  <th
                    style={thStyle}
                  >
                    #
                  </th>

                  <th
                    style={thStyle}
                  >
                    Medicine
                  </th>

                  <th
                    style={thStyle}
                  >
                    Company
                  </th>

                  <th
                    style={thStyle}
                  >
                    Batch
                  </th>

                  <th
                    style={thStyle}
                  >
                    Qty
                  </th>

                  <th
                    style={thStyle}
                  >
                    Expiry
                  </th>

                </tr>

              </thead>

              <tbody>

                {expiryReport.length ===
                0 ? (

                  <tr>

                    <td
                      colSpan="6"
                      style={{
                        ...tdStyle,
                        textAlign:
                          "center",
                        padding: 25,
                        color:
                          "#777",
                      }}
                    >
                      ✅ अगले 30 दिनों
                      में कोई Expiry
                      नहीं है।
                    </td>

                  </tr>

                ) : (

                  expiryReport.map(
                    (
                      item,
                      index
                    ) => (

                      <tr
                        key={
                          item.id ||
                          index
                        }
                      >

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {index + 1}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          <b>
                            {item.medicine ||
                              "-"}
                          </b>
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.company ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.batch ||
                            "-"}
                        </td>

                        <td
                          style={
                            tdStyle
                          }
                        >
                          {item.quantity ||
                            0}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              "#d32f2f",
                            fontWeight:
                              "bold",
                          }}
                        >
                          {item.expiry}
                        </td>

                      </tr>

                    )
                  )

                )}

              </tbody>

            </table>

          </div>

        </div>
      )}

    </div>
  );
}

// =========================================
// SUMMARY COMPONENT
// =========================================

function Summary({
  title,
  value,
  color,
}) {
  return (
    <div
      style={{
        background: "white",
        padding: 14,
        borderRadius: 9,
        borderLeft:
          `4px solid ${color}`,
        boxShadow:
          "0 2px 7px rgba(0,0,0,0.06)",
      }}
    >

      <div
        style={{
          fontSize: 12,
          color: "#777",
        }}
      >
        {title}
      </div>

      <div
        style={{
          fontSize: 20,
          fontWeight: "bold",
          color,
          marginTop: 4,
        }}
      >
        {value}
      </div>

    </div>
  );
}

// =========================================
// STYLES
// =========================================

const pageStyle = {
  minHeight: "100vh",
  padding: 15,
  background: "#f2f5f9",
  fontFamily:
    "Arial, sans-serif",
  boxSizing: "border-box",
};

const headerStyle = {
  background:
    "linear-gradient(135deg,#1565c0,#42a5f5)",
  color: "white",
  padding: "16px 18px",
  borderRadius: 12,
  marginBottom: 12,
  display: "flex",
  justifyContent:
    "space-between",
  alignItems: "center",
};

const backButton = {
  background: "white",
  color: "#1565c0",
  border: "none",
  padding: "9px 14px",
  borderRadius: 7,
  fontWeight: "bold",
  cursor: "pointer",
};

const filterBox = {
  background: "white",
  padding: 15,
  borderRadius: 10,
  marginBottom: 15,
  boxShadow:
    "0 2px 8px rgba(0,0,0,0.06)",
  display: "grid",
  gap: 10,
};

const selectStyle = {
  padding: 11,
  border:
    "1px solid #ccc",
  borderRadius: 7,
  fontSize: 14,
  background: "white",
};

const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: 11,
  border:
    "1px solid #ccc",
  borderRadius: 7,
  fontSize: 14,
};

const boxStyle = {
  background: "white",
  padding: 15,
  borderRadius: 10,
  marginBottom: 15,
  boxShadow:
    "0 2px 8px rgba(0,0,0,0.06)",
};

const summaryGrid = {
  display: "grid",
  gridTemplateColumns:
    "repeat(auto-fit,minmax(170px,1fr))",
  gap: 10,
  marginBottom: 15,
};

const scroll = {
  overflowX: "auto",
};

const tableStyle = {
  width: "100%",
  borderCollapse:
    "collapse",
  fontSize: 12,
};

const thStyle = {
  border:
    "1px solid #ddd",
  padding: 8,
  background:
    "#f1f5f9",
  whiteSpace:
    "nowrap",
};

const tdStyle = {
  border:
    "1px solid #ddd",
  padding: 8,
  whiteSpace:
    "nowrap",
};

export default Reports;