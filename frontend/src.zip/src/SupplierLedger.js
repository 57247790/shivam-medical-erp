import React, { useMemo, useState } from "react";

function SupplierLedger({
  stock = [],
  setPage,
  goBack,
}) {
  const [selectedSupplier, setSelectedSupplier] =
    useState("");

  const [search, setSearch] = useState("");
  const [refresh, setRefresh] = useState(0);

  const safeStock = Array.isArray(stock)
    ? stock
    : [];

  const loadArray = (key) => {
    try {
      const data = JSON.parse(
        localStorage.getItem(key) || "[]"
      );

      return Array.isArray(data)
        ? data
        : [];
    } catch {
      return [];
    }
  };

  const loadObject = (key) => {
    try {
      const data = JSON.parse(
        localStorage.getItem(key) || "{}"
      );

      return data &&
        typeof data === "object" &&
        !Array.isArray(data)
        ? data
        : {};
    } catch {
      return {};
    }
  };

  const purchases = useMemo(
    () => loadArray("purchaseHistory"),
    [refresh]
  );

  const supplierPayments = useMemo(
    () => loadArray("supplierPayments"),
    [refresh]
  );

  const advances = useMemo(
    () => loadObject("supplierAdvances"),
    [refresh]
  );

  const getSupplierName = (item) => {
    return String(
      item?.supplier ||
        item?.supplierName ||
        item?.vendor ||
        ""
    ).trim();
  };

  const getPurchaseAmount = (item) => {
    if (item?.purchaseAmount != null) {
      return Number(item.purchaseAmount) || 0;
    }

    if (item?.totalAmount != null) {
      return Number(item.totalAmount) || 0;
    }

    if (item?.amount != null) {
      return Number(item.amount) || 0;
    }

    const quantity = Number(
      item?.quantity ??
        item?.qty ??
        0
    );

    const rate = Number(
      item?.purchaseRate ??
        item?.rate ??
        0
    );

    return quantity * rate;
  };

  const getPaymentAmount = (item) => {
    return Number(
      item?.amount ??
        item?.paidAmount ??
        item?.payment ??
        0
    );
  };

  const supplierNames = useMemo(() => {
    const names = new Set();

    purchases.forEach((item) => {
      const name = getSupplierName(item);

      if (name) names.add(name);
    });

    supplierPayments.forEach((item) => {
      const name = getSupplierName(item);

      if (name) names.add(name);
    });

    Object.keys(advances).forEach((name) => {
      if (name) names.add(name);
    });

    safeStock.forEach((item) => {
      const name = getSupplierName(item);

      if (name) names.add(name);
    });

    return Array.from(names).sort(
      (a, b) => a.localeCompare(b)
    );
  }, [
    purchases,
    supplierPayments,
    advances,
    safeStock,
  ]);

  const filteredSuppliers =
    supplierNames.filter((supplier) =>
      supplier
        .toLowerCase()
        .includes(
          search.trim().toLowerCase()
        )
    );

  const getSupplierData = (supplier) => {
    const key = supplier
      .trim()
      .toLowerCase();

    const supplierPurchases =
      purchases.filter(
        (item) =>
          getSupplierName(item)
            .toLowerCase() === key
      );

    const supplierPayments =
      supplierPaymentsSafe.filter(
        (item) =>
          getSupplierName(item)
            .toLowerCase() === key
      );

    const purchaseTotal =
      supplierPurchases.reduce(
        (sum, item) =>
          sum + getPurchaseAmount(item),
        0
      );

    const paidTotal =
      supplierPayments.reduce(
        (sum, item) =>
          sum + getPaymentAmount(item),
        0
      );

    /*
      Payment में जो amount आया है,
      वह Pending settlement + Advance हो सकता है।

      इसलिए actual advance अलग से दिखाया जाएगा।
    */

    const advance =
      Number(advances[key] || 0);

    const pending =
      Math.max(
        purchaseTotal - paidTotal,
        0
      );

    return {
      supplierPurchases,
      supplierPayments,
      purchaseTotal,
      paidTotal,
      pending,
      advance,
    };
  };

  const supplierPaymentsSafe =
    supplierPayments;

  const selectedData = selectedSupplier
    ? getSupplierData(selectedSupplier)
    : null;

  const money = (value) =>
    `₹${Number(value || 0).toFixed(2)}`;

  const openSupplier = (supplier) => {
    setSelectedSupplier(supplier);

    localStorage.setItem(
      "selectedSupplierForPayment",
      supplier
    );
  };

  const openPayment = () => {
    if (typeof setPage === "function") {
      setPage("supplierPayment");
    }
  };

  const closeSupplier = () => {
    setSelectedSupplier("");
  };

  return (
    <div style={pageStyle}>
      <div style={headerStyle}>
        <div>
          <h1 style={headerTitle}>
            🏢 Supplier Ledger
          </h1>

          <div style={subtitle}>
            Purchase • Payment • Advance • Pending
          </div>
        </div>

        <button
          type="button"
          onClick={goBack}
          style={backButton}
        >
          ⬅️ Dashboard
        </button>
      </div>

      {/* SUMMARY */}

      <div style={summaryGrid}>
        <SummaryCard
          title="Total Purchase"
          value={money(
            purchases.reduce(
              (sum, item) =>
                sum + getPurchaseAmount(item),
              0
            )
          )}
          color="#ef6c00"
        />

        <SummaryCard
          title="Total Paid"
          value={money(
            supplierPayments.reduce(
              (sum, item) =>
                sum + getPaymentAmount(item),
              0
            )
          )}
          color="#2e7d32"
        />

        <SummaryCard
          title="Total Advance"
          value={money(
            Object.values(advances).reduce(
              (sum, value) =>
                sum + Number(value || 0),
              0
            )
          )}
          color="#6a1b9a"
        />

        <SummaryCard
          title="Suppliers"
          value={supplierNames.length}
          color="#1565c0"
        />
      </div>

      {/* ACTION */}

      <div style={actionBox}>
        <button
          type="button"
          onClick={openPayment}
          style={paymentButton}
        >
          💳 Supplier Payment
        </button>

        {selectedSupplier && (
          <button
            type="button"
            onClick={closeSupplier}
            style={backSupplierButton}
          >
            ⬅️ All Suppliers
          </button>
        )}
      </div>

      {/* SEARCH */}

      <div style={sectionStyle}>
        <input
          type="text"
          placeholder="🔎 Supplier Name Search करें..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
          style={searchInput}
        />
      </div>

      {/* DETAIL */}

      {selectedSupplier && selectedData ? (
        <div style={sectionStyle}>
          <div style={supplierHeader}>
            <div>
              <div style={smallLabel}>
                Selected Supplier
              </div>

              <h2 style={{ margin: "3px 0" }}>
                🏢 {selectedSupplier}
              </h2>
            </div>
          </div>

          {/* DETAIL SUMMARY */}

          <div style={detailGrid}>
            <SummaryCard
              title="Purchase"
              value={money(
                selectedData.purchaseTotal
              )}
              color="#ef6c00"
            />

            <SummaryCard
              title="Paid"
              value={money(
                selectedData.paidTotal
              )}
              color="#2e7d32"
            />

            <SummaryCard
              title="Pending"
              value={money(
                selectedData.pending
              )}
              color="#d32f2f"
            />

            <SummaryCard
              title="Advance"
              value={money(
                selectedData.advance
              )}
              color="#6a1b9a"
            />
          </div>

          {/* ADVANCE STATUS */}

          {selectedData.advance > 0 && (
            <div style={advanceBox}>
              💜 <b>Supplier Advance:</b>{" "}
              {money(selectedData.advance)}
              <br />
              यह amount Supplier को पहले से दिया गया
              है और आगे की Purchase में adjust किया जा
              सकता है।
            </div>
          )}

          {/* PURCHASE HISTORY */}

          <h3 style={subHeading}>
            🛒 Purchase History
          </h3>

          {selectedData.supplierPurchases.length ===
          0 ? (
            <div style={emptyBox}>
              इस Supplier की Purchase entry नहीं मिली।
            </div>
          ) : (
            <div style={{ overflowX: "auto" }}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Date</th>
                    <th style={thStyle}>Medicine</th>
                    <th style={thStyle}>Batch</th>
                    <th style={thStyle}>Qty</th>
                    <th style={thStyle}>
                      Purchase Rate
                    </th>
                    <th style={thStyle}>Amount</th>
                  </tr>
                </thead>

                <tbody>
                  {selectedData.supplierPurchases.map(
                    (purchase, index) => (
                      <tr
                        key={
                          purchase?.id || index
                        }
                      >
                        <td style={tdStyle}>
                          {purchase?.date ||
                            purchase?.purchaseDate ||
                            "-"}
                        </td>

                        <td style={tdStyle}>
                          <b>
                            {purchase?.medicine ||
                              "-"}
                          </b>
                        </td>

                        <td style={tdStyle}>
                          {purchase?.batch || "-"}
                        </td>

                        <td style={tdStyle}>
                          {purchase?.quantity ??
                            purchase?.qty ??
                            0}
                        </td>

                        <td style={tdStyle}>
                          {money(
                            purchase?.purchaseRate ??
                              purchase?.rate ??
                              0
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            fontWeight: "bold",
                          }}
                        >
                          {money(
                            getPurchaseAmount(
                              purchase
                            )
                          )}
                        </td>
                      </tr>
                    )
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* PAYMENT HISTORY */}

          <h3 style={subHeading}>
            💳 Supplier Payments
          </h3>

          {selectedData.supplierPayments.length ===
          0 ? (
            <div style={emptyBox}>
              इस Supplier को कोई Payment नहीं किया गया है।
            </div>
          ) : (
            <div style={{ overflowX: "auto" }}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Date</th>
                    <th style={thStyle}>Amount</th>
                    <th style={thStyle}>Mode</th>
                    <th style={thStyle}>Settlement</th>
                    <th style={thStyle}>Advance</th>
                    <th style={thStyle}>Note</th>
                  </tr>
                </thead>

                <tbody>
                  {selectedData.supplierPayments.map(
                    (payment, index) => (
                      <tr
                        key={
                          payment?.id || index
                        }
                      >
                        <td style={tdStyle}>
                          {payment?.date || "-"}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            fontWeight: "bold",
                            color: "#2e7d32",
                          }}
                        >
                          {money(
                            getPaymentAmount(
                              payment
                            )
                          )}
                        </td>

                        <td style={tdStyle}>
                          {payment?.paymentMode ||
                            payment?.mode ||
                            "-"}
                        </td>

                        <td style={tdStyle}>
                          {money(
                            payment?.settlementAmount ||
                              0
                          )}
                        </td>

                        <td
                          style={{
                            ...tdStyle,
                            color:
                              Number(
                                payment?.advanceAmount ||
                                  0
                              ) > 0
                                ? "#6a1b9a"
                                : "#777",
                            fontWeight:
                              "bold",
                          }}
                        >
                          {money(
                            payment?.advanceAmount ||
                              0
                          )}
                        </td>

                        <td style={tdStyle}>
                          {payment?.note || "-"}
                        </td>
                      </tr>
                    )
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        /* SUPPLIER LIST */

        <div style={sectionStyle}>
          <h2 style={sectionTitle}>
            🏢 Suppliers
          </h2>

          {filteredSuppliers.length === 0 ? (
            <div style={emptyBox}>
              ⚠️ कोई Supplier उपलब्ध नहीं है।
              <br />
              <br />
              पहले Purchase Entry में Supplier का नाम
              save करें।
            </div>
          ) : (
            <div style={supplierGrid}>
              {filteredSuppliers.map(
                (supplier) => {
                  const data =
                    getSupplierData(
                      supplier
                    );

                  return (
                    <button
                      type="button"
                      key={supplier}
                      onClick={() =>
                        openSupplier(
                          supplier
                        )
                      }
                      style={{
                        ...supplierCard,
                        borderLeft:
                          `5px solid ${
                            data.pending > 0
                              ? "#d32f2f"
                              : data.advance > 0
                              ? "#6a1b9a"
                              : "#2e7d32"
                          }`,
                      }}
                    >
                      <div
                        style={
                          supplierCardTop
                        }
                      >
                        <span
                          style={{
                            fontSize: 28,
                          }}
                        >
                          🏢
                        </span>

                        <span
                          style={{
                            color:
                              "#1565c0",
                            fontWeight:
                              "bold",
                          }}
                        >
                          Open →
                        </span>
                      </div>

                      <div
                        style={{
                          fontSize: 16,
                          fontWeight:
                            "bold",
                        }}
                      >
                        {supplier}
                      </div>

                      <div
                        style={
                          supplierSmall
                        }
                      >
                        Purchase:{" "}
                        <b>
                          {money(
                            data.purchaseTotal
                          )}
                        </b>
                      </div>

                      <div
                        style={
                          supplierSmall
                        }
                      >
                        Paid:{" "}
                        <b
                          style={{
                            color:
                              "#2e7d32",
                          }}
                        >
                          {money(
                            data.paidTotal
                          )}
                        </b>
                      </div>

                      <div
                        style={{
                          marginTop: 6,
                          fontWeight:
                            "bold",
                          color:
                            data.pending > 0
                              ? "#d32f2f"
                              : "#2e7d32",
                        }}
                      >
                        Pending:{" "}
                        {money(
                          data.pending
                        )}
                      </div>

                      {data.advance > 0 && (
                        <div
                          style={{
                            marginTop: 5,
                            fontWeight:
                              "bold",
                            color:
                              "#6a1b9a",
                          }}
                        >
                          Advance:{" "}
                          {money(
                            data.advance
                          )}
                        </div>
                      )}
                    </button>
                  );
                }
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SummaryCard({
  title,
  value,
  color,
}) {
  return (
    <div
      style={{
        background: "#fff",
        padding: 12,
        borderRadius: 8,
        borderLeft: `4px solid ${color}`,
        boxShadow:
          "0 2px 6px rgba(0,0,0,0.05)",
      }}
    >
      <div
        style={{
          fontSize: 11,
          color: "#777",
        }}
      >
        {title}
      </div>

      <div
        style={{
          marginTop: 4,
          fontSize: 19,
          fontWeight: "bold",
          color,
        }}
      >
        {value}
      </div>
    </div>
  );
}

const pageStyle = {
  minHeight: "100vh",
  padding: 12,
  background: "#f2f5f9",
  fontFamily: "Arial, sans-serif",
  boxSizing: "border-box",
};

const headerStyle = {
  background:
    "linear-gradient(135deg,#0d47a1,#1976d2,#42a5f5)",
  color: "white",
  padding: 17,
  borderRadius: 11,
  marginBottom: 13,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  flexWrap: "wrap",
  boxShadow:
    "0 3px 10px rgba(0,0,0,0.12)",
};

const headerTitle = {
  margin: 0,
  fontSize: 24,
};

const subtitle = {
  marginTop: 4,
  fontSize: 13,
};

const backButton = {
  padding: "9px 14px",
  background: "rgba(255,255,255,0.18)",
  color: "white",
  border:
    "1px solid rgba(255,255,255,0.4)",
  borderRadius: 7,
  cursor: "pointer",
  fontWeight: "bold",
};

const summaryGrid = {
  display: "grid",
  gridTemplateColumns:
    "repeat(auto-fit,minmax(180px,1fr))",
  gap: 9,
  marginBottom: 13,
};

const actionBox = {
  background: "white",
  padding: 10,
  borderRadius: 9,
  marginBottom: 12,
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
};

const paymentButton = {
  padding: "9px 14px",
  background: "#6a1b9a",
  color: "white",
  border: "none",
  borderRadius: 6,
  cursor: "pointer",
  fontWeight: "bold",
};

const backSupplierButton = {
  padding: "9px 14px",
  background: "#555",
  color: "white",
  border: "none",
  borderRadius: 6,
  cursor: "pointer",
  fontWeight: "bold",
};

const sectionStyle = {
  background: "white",
  padding: 14,
  borderRadius: 10,
  marginBottom: 13,
  boxShadow:
    "0 2px 7px rgba(0,0,0,0.06)",
};

const sectionTitle = {
  margin: "0 0 10px",
  fontSize: 18,
};

const searchInput = {
  width: "100%",
  boxSizing: "border-box",
  padding: 10,
  border: "1px solid #ccc",
  borderRadius: 7,
  fontSize: 14,
};

const supplierGrid = {
  display: "grid",
  gridTemplateColumns:
    "repeat(auto-fit,minmax(220px,1fr))",
  gap: 10,
};

const supplierCard = {
  textAlign: "left",
  width: "100%",
  minHeight: 155,
  padding: 13,
  background: "#f8fafc",
  borderTop: "none",
  borderRight: "none",
  borderBottom: "none",
  borderRadius: 9,
  cursor: "pointer",
  boxSizing: "border-box",
  boxShadow:
    "0 2px 6px rgba(0,0,0,0.06)",
};

const supplierCardTop = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: 8,
};

const supplierSmall = {
  marginTop: 7,
  fontSize: 12,
  color: "#555",
};

const supplierHeader = {
  padding: 10,
  background: "#f5f7fa",
  borderRadius: 8,
  marginBottom: 12,
};

const smallLabel = {
  fontSize: 12,
  color: "#777",
};

const detailGrid = {
  display: "grid",
  gridTemplateColumns:
    "repeat(auto-fit,minmax(170px,1fr))",
  gap: 9,
  marginBottom: 15,
};

const advanceBox = {
  background: "#f3e5f5",
  border: "1px solid #ce93d8",
  color: "#6a1b9a",
  padding: 13,
  borderRadius: 8,
  marginBottom: 15,
  lineHeight: 1.6,
};

const subHeading = {
  margin: "16px 0 9px",
  fontSize: 16,
};

const emptyBox = {
  padding: 20,
  textAlign: "center",
  color: "#777",
  background: "#f7f8fa",
  borderRadius: 7,
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse",
  fontSize: 12,
};

const thStyle = {
  border: "1px solid #ddd",
  padding: 8,
  background: "#f1f5f9",
  whiteSpace: "nowrap",
};

const tdStyle = {
  border: "1px solid #ddd",
  padding: 8,
  whiteSpace: "nowrap",
};

export default SupplierLedger;