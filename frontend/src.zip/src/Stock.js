import { useMemo, useState } from "react";

function Stock({ stock, setStock, goBack }) {
  const [search, setSearch] = useState("");

 const currentStock = useMemo(
  () => (Array.isArray(stock) ? stock : []),
  [stock]
);

  // =====================================================
  // EXPIRY
  // =====================================================

  const expiryInfo = (expiry) => {
    if (!expiry) {
      return {
        text: "N/A",
        color: "#777",
      };
    }

    const expiryDate = new Date(expiry);

    if (Number.isNaN(expiryDate.getTime())) {
      return {
        text: expiry,
        color: "#777",
      };
    }

    const today = new Date();

    today.setHours(0, 0, 0, 0);
    expiryDate.setHours(0, 0, 0, 0);

    const diff =
      expiryDate.getTime() -
      today.getTime();

    const days = Math.ceil(
      diff / (1000 * 60 * 60 * 24)
    );

    if (days < 0) {
      return {
        text: `🔴 Expired ${Math.abs(days)}d`,
        color: "#d32f2f",
      };
    }

    if (days <= 30) {
      return {
        text: `🔴 ${expiry} (${days}d)`,
        color: "#d32f2f",
      };
    }

    return {
      text: expiry,
      color: "#2e7d32",
    };
  };

  // =====================================================
  // SEARCH
  // =====================================================

  const filteredStock = useMemo(() => {
    const text = search
      .trim()
      .toLowerCase();

    if (!text) {
      return currentStock;
    }

    return currentStock.filter((item) => {
      const medicine = String(
        item.medicine || ""
      ).toLowerCase();

      const company = String(
        item.company || ""
      ).toLowerCase();

      const barcode = String(
        item.barcode || ""
      ).toLowerCase();

      const batch = String(
        item.batch || ""
      ).toLowerCase();

      const supplier = String(
        item.supplier || ""
      ).toLowerCase();

      return (
        medicine.includes(text) ||
        company.includes(text) ||
        barcode.includes(text) ||
        batch.includes(text) ||
        supplier.includes(text)
      );
    });
  }, [currentStock, search]);

  // =====================================================
  // DELETE
  // =====================================================

  const deleteMedicine = (index) => {
    const item = filteredStock[index];

    if (!item) {
      return;
    }

    const confirmDelete = window.confirm(
      "⚠️ क्या आप इस Stock Item को Delete करना चाहते हैं?\n\n" +
        `Medicine: ${
          item.medicine || "-"
        }\n` +
        `Batch: ${
          item.batch || "-"
        }\n` +
        `Barcode: ${
          item.barcode || "-"
        }`
    );

    if (!confirmDelete) {
      return;
    }

    const itemId = item.id;

    const updatedStock =
      currentStock.filter(
        (stockItem) =>
          stockItem.id !== itemId
      );

    setStock(updatedStock);

    localStorage.setItem(
      "stock",
      JSON.stringify(updatedStock)
    );
  };

  // =====================================================
  // TOTALS
  // =====================================================

  const totalQuantity = filteredStock.reduce(
    (sum, item) =>
      sum +
      Number(item.quantity || 0),
    0
  );

  const totalPurchaseValue =
    filteredStock.reduce(
      (sum, item) =>
        sum +
        Number(item.quantity || 0) *
          Number(
            item.purchaseRate ||
              item.rate ||
              0
          ),
      0
    );

  const totalSaleValue =
    filteredStock.reduce(
      (sum, item) =>
        sum +
        Number(item.quantity || 0) *
          Number(
            item.saleRate ||
              item.mrp ||
              0
          ),
      0
    );

  // =====================================================
  // UI
  // =====================================================

  return (
    <div
      style={{
        minHeight: "100vh",
        padding: "20px",
        background: "#f2f5f9",
        fontFamily: "Arial, sans-serif",
        boxSizing: "border-box",
      }}
    >
      {/* =================================================
          HEADER
      ================================================= */}

      <div
        style={{
          background:
            "linear-gradient(135deg,#1976d2,#42a5f5)",
          color: "white",
          padding: "20px",
          borderRadius: "12px",
          marginBottom: "15px",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "10px",
            flexWrap: "wrap",
          }}
        >
          <div>
            <h1
              style={{
                margin: 0,
              }}
            >
              📦 Stock
            </h1>

            <p
              style={{
                margin:
                  "5px 0 0 0",
                fontSize: "13px",
              }}
            >
              Medicine Stock Management
            </p>
          </div>

          <div
            style={{
              background:
                "rgba(255,255,255,0.18)",
              padding:
                "10px 15px",
              borderRadius:
                "8px",
              fontWeight:
                "bold",
            }}
          >
            Items:{" "}
            {filteredStock.length}
          </div>
        </div>
      </div>

      {/* =================================================
          SEARCH
      ================================================= */}

      <div
        style={{
          background: "white",
          padding: "15px",
          borderRadius: "10px",
          marginBottom: "15px",
          boxShadow:
            "0 2px 8px rgba(0,0,0,0.06)",
        }}
      >
        <h3
          style={{
            margin:
              "0 0 10px 0",
          }}
        >
          🔎 Stock Search
        </h3>

        <input
          type="text"
          placeholder="Medicine / Company / Barcode / Batch / Supplier"
          value={search}
          onChange={(e) =>
            setSearch(
              e.target.value
            )
          }
          style={{
            width: "100%",
            boxSizing:
              "border-box",
            padding: "12px",
            fontSize: "15px",
            border:
              "2px solid #1976d2",
            borderRadius: "7px",
            outline: "none",
          }}
          autoComplete="off"
        />

        {search && (
          <div
            style={{
              marginTop: "8px",
              fontSize: "12px",
              color: "#555",
            }}
          >
            🔍{" "}
            {filteredStock.length} item(s)
            found
          </div>
        )}
      </div>

      {/* =================================================
          SUMMARY
      ================================================= */}

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(4,minmax(150px,1fr))",
          gap: "10px",
          marginBottom: "15px",
        }}
      >
        <SummaryBox
          title="Total Items"
          value={
            filteredStock.length
          }
          color="#1976d2"
        />

        <SummaryBox
          title="Total Quantity"
          value={
            totalQuantity
          }
          color="#2e7d32"
        />

        <SummaryBox
          title="Purchase Value"
          value={
            `₹${totalPurchaseValue.toFixed(
              2
            )}`
          }
          color="#ef6c00"
        />

        <SummaryBox
          title="Sale Value"
          value={
            `₹${totalSaleValue.toFixed(
              2
            )}`
          }
          color="#6a1b9a"
        />
      </div>

      {/* =================================================
          STOCK TABLE
      ================================================= */}

      <div
        style={{
          background: "white",
          padding: "15px",
          borderRadius: "10px",
          boxShadow:
            "0 2px 8px rgba(0,0,0,0.06)",
          overflowX: "auto",
        }}
      >
        <h3
          style={{
            margin:
              "0 0 10px 0",
          }}
        >
          📋 Current Stock
        </h3>

        {filteredStock.length ===
        0 ? (
          <div
            style={{
              padding: "30px",
              textAlign: "center",
              color: "#777",
            }}
          >
            {search
              ? "❌ कोई Stock Item नहीं मिला"
              : "📦 अभी Stock खाली है"}
          </div>
        ) : (
          <table
            style={{
              width: "100%",
              minWidth: "1200px",
              borderCollapse:
                "collapse",
              fontSize: "12px",
            }}
          >
            <thead>
              <tr>
                <th style={thStyle}>
                  #
                </th>

                <th style={thStyle}>
                  Medicine
                </th>

                <th style={thStyle}>
                  Company
                </th>

                <th style={thStyle}>
                  Batch
                </th>

                <th style={thStyle}>
                  Barcode
                </th>

                <th style={thStyle}>
                  Supplier
                </th>

                <th style={thStyle}>
                  Qty
                </th>

                <th style={thStyle}>
                  Purchase
                </th>

                <th style={thStyle}>
                  Sale
                </th>

                <th style={thStyle}>
                  MRP
                </th>

                <th style={thStyle}>
                  Expiry
                </th>

                <th style={thStyle}>
                  Action
                </th>
              </tr>
            </thead>

            <tbody>
              {filteredStock.map(
                (item, index) => {
                  const exp =
                    expiryInfo(
                      item.expiry ||
                        item.expiryDate ||
                        item.expiry_date
                    );

                  const qty =
                    Number(
                      item.quantity ||
                        0
                    );

                  const lowStock =
                    qty > 0 &&
                    qty <= 10;

                  return (
                    <tr
                      key={
                        item.id ||
                        `${item.medicine}-${item.batch}-${index}`
                      }
                    >
                      {/* # */}

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {index + 1}
                      </td>

                      {/* MEDICINE */}

                      <td
                        style={{
                          ...tdStyle,
                          fontWeight:
                            "bold",
                        }}
                      >
                        {item.medicine ||
                          "-"}
                      </td>

                      {/* COMPANY */}

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {item.company ||
                          "-"}
                      </td>

                      {/* BATCH */}

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {item.batch ||
                          "-"}
                      </td>

                      {/* BARCODE */}

                      <td
                        style={{
                          ...tdStyle,
                          fontWeight:
                            "bold",
                          color:
                            "#1565c0",
                        }}
                      >
                        {item.barcode ||
                          "-"}
                      </td>

                      {/* SUPPLIER */}

                      <td
                        style={
                          tdStyle
                        }
                      >
                        {item.supplier ||
                          "-"}
                      </td>

                      {/* QUANTITY */}

                      <td
                        style={{
                          ...tdStyle,
                          fontWeight:
                            "bold",
                          color:
                            qty <= 0
                              ? "#d32f2f"
                              : lowStock
                              ? "#ef6c00"
                              : "#2e7d32",
                        }}
                      >
                        {qty}

                        {qty <= 0 && (
                          <div
                            style={{
                              fontSize:
                                "10px",
                              color:
                                "#d32f2f",
                            }}
                          >
                            OUT
                          </div>
                        )}

                        {lowStock && (
                          <div
                            style={{
                              fontSize:
                                "10px",
                              color:
                                "#ef6c00",
                            }}
                          >
                            LOW
                          </div>
                        )}
                      </td>

                      {/* PURCHASE RATE */}

                      <td
                        style={
                          tdStyle
                        }
                      >
                        ₹
                        {Number(
                          item.purchaseRate ||
                            item.rate ||
                            0
                        ).toFixed(2)}
                      </td>

                      {/* SALE RATE */}

                      <td
                        style={{
                          ...tdStyle,
                          fontWeight:
                            "bold",
                          color:
                            "#2e7d32",
                        }}
                      >
                        ₹
                        {Number(
                          item.saleRate ||
                            item.mrp ||
                            item.rate ||
                            0
                        ).toFixed(2)}
                      </td>

                      {/* MRP */}

                      <td
                        style={
                          tdStyle
                        }
                      >
                        ₹
                        {Number(
                          item.mrp ||
                            0
                        ).toFixed(2)}
                      </td>

                      {/* EXPIRY */}

                      <td
                        style={{
                          ...tdStyle,
                          color:
                            exp.color,
                          fontWeight:
                            "bold",
                        }}
                      >
                        {exp.text}
                      </td>

                      {/* DELETE */}

                      <td
                        style={
                          tdStyle
                        }
                      >
                        <button
                          type="button"
                          onClick={() =>
                            deleteMedicine(
                              index
                            )
                          }
                          style={{
                            padding:
                              "6px 10px",
                            background:
                              "#d32f2f",
                            color:
                              "white",
                            border:
                              "none",
                            borderRadius:
                              "5px",
                            cursor:
                              "pointer",
                            fontWeight:
                              "bold",
                          }}
                        >
                          🗑️ Delete
                        </button>
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* =================================================
          BACK
      ================================================= */}

      <button
        type="button"
        onClick={goBack}
        style={{
          width: "100%",
          marginTop: "15px",
          padding: "13px",
          background: "#555",
          color: "white",
          border: "none",
          borderRadius: "8px",
          fontSize: "16px",
          cursor: "pointer",
          fontWeight: "bold",
        }}
      >
        ⬅️ Dashboard
      </button>
    </div>
  );
}

// =====================================================
// SUMMARY BOX
// =====================================================

function SummaryBox({
  title,
  value,
  color,
}) {
  return (
    <div
      style={{
        background: "white",
        padding: "12px",
        borderRadius: "9px",
        borderLeft:
          `4px solid ${color}`,
        boxShadow:
          "0 2px 7px rgba(0,0,0,0.05)",
      }}
    >
      <div
        style={{
          fontSize: "11px",
          color: "#666",
        }}
      >
        {title}
      </div>

      <div
        style={{
          marginTop: "4px",
          fontSize: "18px",
          fontWeight: "bold",
          color,
        }}
      >
        {value}
      </div>
    </div>
  );
}

// =====================================================
// STYLES
// =====================================================

const thStyle = {
  border:
    "1px solid #ddd",

  padding:
    "8px",

  background:
    "#e3f2fd",

  whiteSpace:
    "nowrap",

  textAlign:
    "left",
};

const tdStyle = {
  border:
    "1px solid #ddd",

  padding:
    "8px",

  whiteSpace:
    "nowrap",

  verticalAlign:
    "middle",
};

export default Stock;