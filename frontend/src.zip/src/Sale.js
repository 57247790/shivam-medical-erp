import { useState } from "react";

function Sale({ stock, setStock, goBack }) {
  const [medicine, setMedicine] = useState("");
  const [barcode, setBarcode] = useState("");
  const [quantity, setQuantity] = useState("");

  // =========================
  // CURRENT STOCK
  // =========================

  const currentStock = Array.isArray(stock)
    ? stock
    : [];

  // =========================
  // BARCODE SEARCH
  // =========================

  const findByBarcode = (value) => {
    const cleanBarcode = String(value || "")
      .trim()
      .toLowerCase();

    if (!cleanBarcode) {
      return null;
    }

    return currentStock.find(
      (item) =>
        String(item.barcode || "")
          .trim()
          .toLowerCase() === cleanBarcode
    );
  };

  // =========================
  // BARCODE CHANGE
  // =========================

  const handleBarcodeChange = (e) => {
    const value = e.target.value;

    setBarcode(value);

    const cleanValue = String(value || "").trim();

    if (!cleanValue) {
      setMedicine("");
      return;
    }

    const found = findByBarcode(cleanValue);

    if (found) {
      setMedicine(found.medicine || "");
    } else {
      setMedicine("");
    }
  };

  // =========================
  // SELECTED MEDICINE
  // =========================

  const selectedItem = currentStock.find(
    (item) =>
      item.medicine === medicine
  );

  // =========================
  // SALE RATE
  // =========================

  const saleRate = selectedItem
    ? Number(
        selectedItem.saleRate ||
          selectedItem.mrp ||
          0
      )
    : 0;

  // =========================
  // PURCHASE RATE
  // =========================

  const purchaseRate = selectedItem
    ? Number(
        selectedItem.purchaseRate ||
          selectedItem.rate ||
          0
      )
    : 0;

  // =========================
  // TOTAL SALE
  // =========================

  const totalAmount =
    Number(quantity || 0) *
    saleRate;

  // =========================
  // PURCHASE COST
  // =========================

  const totalPurchaseCost =
    Number(quantity || 0) *
    purchaseRate;

  // =========================
  // PROFIT
  // =========================

  const profit =
    totalAmount -
    totalPurchaseCost;

  // =========================
  // MEDICINE SELECT
  // =========================

  const handleMedicineChange = (e) => {
    const value = e.target.value;

    setMedicine(value);

    const found = currentStock.find(
      (item) =>
        item.medicine === value
    );

    if (found) {
      setBarcode(
        found.barcode || ""
      );
    } else {
      setBarcode("");
    }
  };

  // =========================
  // SAVE SALE
  // =========================

  const saveSale = () => {
    // ---------------------------------------------------
    // REQUIRED
    // ---------------------------------------------------

    if (!barcode.trim()) {
      alert(
        "⚠️ Barcode नहीं मिला!\n\n" +
          "कृपया Medicine का Barcode Scan करें या Barcode डालें।"
      );

      return;
    }

    // ---------------------------------------------------
    // FIND BARCODE
    // ---------------------------------------------------

    const foundByBarcode =
      findByBarcode(barcode);

    if (!foundByBarcode) {
      alert(
        "❌ Barcode नहीं मिला!\n\n" +
          "यह Barcode Stock में मौजूद नहीं है।\n\n" +
          "कृपया:\n" +
          "• सही Barcode Scan करें\n" +
          "• या पहले Purchase Entry में इस Medicine को Barcode के साथ Save करें।"
      );

      setMedicine("");
      return;
    }

    // ---------------------------------------------------
    // MEDICINE
    // ---------------------------------------------------

    if (!medicine) {
      alert(
        "⚠️ Barcode से Medicine नहीं मिली।\n\n" +
          "कृपया Barcode दोबारा Scan करें।"
      );

      return;
    }

    // ---------------------------------------------------
    // QUANTITY
    // ---------------------------------------------------

    if (!quantity) {
      alert(
        "⚠️ Quantity भरें"
      );

      return;
    }

    const saleQty =
      Number(quantity);

    if (
      Number.isNaN(saleQty) ||
      saleQty <= 0
    ) {
      alert(
        "⚠️ Quantity सही डालें"
      );

      return;
    }

    // ---------------------------------------------------
    // FIND EXACT STOCK ITEM
    // ---------------------------------------------------

    const index =
      currentStock.findIndex(
        (item) =>
          String(item.barcode || "")
            .trim()
            .toLowerCase() ===
          String(barcode || "")
            .trim()
            .toLowerCase()
      );

    if (index === -1) {
      alert(
        "❌ Barcode Stock में नहीं मिला!"
      );

      return;
    }

    const item =
      currentStock[index];

    // ---------------------------------------------------
    // AVAILABLE STOCK
    // ---------------------------------------------------

    const availableQty =
      Number(
        item.quantity || 0
      );

    if (availableQty <= 0) {
      alert(
        "❌ इस Medicine का Stock खत्म हो चुका है।\n\n" +
          "Medicine: " +
          (item.medicine || "-") +
          "\nBarcode: " +
          (item.barcode || "-")
      );

      return;
    }

    // ---------------------------------------------------
    // STOCK CHECK
    // ---------------------------------------------------

    if (
      saleQty >
      availableQty
    ) {
      alert(
        "❌ Insufficient Stock!\n\n" +
          "Medicine: " +
          (item.medicine || "-") +
          "\nAvailable Stock: " +
          availableQty +
          "\nSale Quantity: " +
          saleQty
      );

      return;
    }

    // ---------------------------------------------------
    // RATES
    // ---------------------------------------------------

    const finalPurchaseRate =
      Number(
        item.purchaseRate ||
          item.rate ||
          0
      );

    const finalSaleRate =
      Number(
        item.saleRate ||
          item.mrp ||
          0
      );

    if (
      finalSaleRate <= 0
    ) {
      alert(
        "❌ Sale Rate उपलब्ध नहीं है।\n\n" +
          "पहले Purchase Entry में Sale Rate डालें।"
      );

      return;
    }

    // ---------------------------------------------------
    // AMOUNTS
    // ---------------------------------------------------

    const saleAmount =
      finalSaleRate *
      saleQty;

    const purchaseAmount =
      finalPurchaseRate *
      saleQty;

    const finalProfit =
      saleAmount -
      purchaseAmount;

    // ---------------------------------------------------
    // DATE
    // ---------------------------------------------------

    const now =
      new Date();

    const saleDate =
      `${now.getFullYear()}-${String(
        now.getMonth() + 1
      ).padStart(2, "0")}-${String(
        now.getDate()
      ).padStart(2, "0")}`;

    // ---------------------------------------------------
    // UPDATE STOCK
    // ---------------------------------------------------

    const newStock =
      [...currentStock];

    newStock[index] = {
      ...newStock[index],

      quantity:
        availableQty -
        saleQty,
    };

    setStock(newStock);

    // ---------------------------------------------------
    // LOCAL STORAGE STOCK
    // ---------------------------------------------------

    localStorage.setItem(
      "stock",
      JSON.stringify(
        newStock
      )
    );

    // ---------------------------------------------------
    // SALE HISTORY
    // ---------------------------------------------------

    let sales = [];

    try {
      const saved =
        JSON.parse(
          localStorage.getItem(
            "sales"
          ) || "[]"
        );

      if (
        Array.isArray(saved)
      ) {
        sales = saved;
      }
    } catch {
      sales = [];
    }

    // ---------------------------------------------------
    // SALE RECORD
    // ---------------------------------------------------

    const saleRecord = {
      id: Date.now(),

      medicine:
        item.medicine || "",

      company:
        item.company || "",

      batch:
        item.batch || "",

      barcode:
        item.barcode || "",

      supplier:
        item.supplier || "",

      quantity:
        saleQty,

      purchaseRate:
        finalPurchaseRate,

      saleRate:
        finalSaleRate,

      purchaseAmount:
        purchaseAmount,

      saleAmount:
        saleAmount,

      profit:
        finalProfit,

      date:
        saleDate,

      time:
        now.toLocaleTimeString(),

      createdAt:
        Date.now(),
    };

    sales.push(
      saleRecord
    );

    localStorage.setItem(
      "sales",
      JSON.stringify(
        sales
      )
    );

    // ---------------------------------------------------
    // SUCCESS
    // ---------------------------------------------------

    alert(
      "✅ Sale Saved Successfully!\n\n" +
        "💊 Medicine: " +
        item.medicine +
        "\n" +
        "📦 Barcode: " +
        item.barcode +
        "\n" +
        "🔢 Quantity: " +
        saleQty +
        "\n" +
        "🛒 Purchase Rate: ₹" +
        finalPurchaseRate.toFixed(2) +
        "\n" +
        "💰 Sale Rate: ₹" +
        finalSaleRate.toFixed(2) +
        "\n" +
        "💵 Sale Amount: ₹" +
        saleAmount.toFixed(2) +
        "\n" +
        "📈 Profit: ₹" +
        finalProfit.toFixed(2) +
        "\n" +
        "📦 Remaining Stock: " +
        (availableQty -
          saleQty)
    );

    // ---------------------------------------------------
    // CLEAR
    // ---------------------------------------------------

    setMedicine("");
    setBarcode("");
    setQuantity("");
  };

  // =========================
  // RETURN
  // =========================

  return (
    <div
      style={{
        minHeight:
          "100vh",

        padding:
          "20px",

        background:
          "#f2f5f9",

        fontFamily:
          "Arial, sans-serif",

        boxSizing:
          "border-box",
      }}
    >
      {/* HEADER */}

      <div
        style={{
          background:
            "linear-gradient(135deg,#2e7d32,#66bb6a)",

          color:
            "white",

          padding:
            "20px",

          borderRadius:
            "12px",

          marginBottom:
            "20px",
        }}
      >
        <h1
          style={{
            margin: 0,
          }}
        >
          💰 Sale Entry
        </h1>

        <p
          style={{
            marginBottom: 0,
          }}
        >
          Barcode से Medicine Sale
        </p>
      </div>

      {/* FORM */}

      <div
        style={{
          background:
            "white",

          padding:
            "25px",

          borderRadius:
            "12px",

          maxWidth:
            "700px",

          margin:
            "auto",

          boxShadow:
            "0 3px 10px rgba(0,0,0,0.08)",
        }}
      >
        <h2>
          📷 Barcode Sale
        </h2>

        {/* BARCODE */}

        <input
          autoFocus
          placeholder="Barcode Scan / Enter Barcode"
          value={barcode}
          onChange={
            handleBarcodeChange
          }
          onKeyDown={(e) => {
            if (
              e.key === "Enter"
            ) {
              const found =
                findByBarcode(
                  barcode
                );

              if (!found) {
                alert(
                  "❌ Barcode नहीं मिला!\n\n" +
                    "यह Barcode Stock में मौजूद नहीं है।"
                );

                return;
              }

              setMedicine(
                found.medicine || ""
              );
            }
          }}
          style={{
            ...inputStyle,

            border:
              "2px solid #1976d2",

            fontSize:
              "18px",
          }}
        />

        {/* BARCODE WARNING */}

        {barcode.trim() &&
          !findByBarcode(
            barcode
          ) && (
            <div
              style={{
                background:
                  "#ffebee",

                border:
                  "1px solid #ef9a9a",

                color:
                  "#c62828",

                padding:
                  "12px",

                borderRadius:
                  "8px",

                marginTop:
                  "-8px",

                marginBottom:
                  "15px",

                fontWeight:
                  "bold",

                fontSize:
                  "13px",
              }}
            >
              ❌ Barcode नहीं मिला!
              <br />
              यह Barcode Stock में मौजूद
              नहीं है।
              <br />
              पहले Purchase Entry में
              Barcode के साथ Medicine Save
              करें।
            </div>
          )}

        {/* BARCODE SUCCESS */}

        {barcode.trim() &&
          findByBarcode(
            barcode
          ) && (
            <div
              style={{
                background:
                  "#e8f5e9",

                border:
                  "1px solid #81c784",

                color:
                  "#2e7d32",

                padding:
                  "12px",

                borderRadius:
                  "8px",

                marginTop:
                  "-8px",

                marginBottom:
                  "15px",

                fontWeight:
                  "bold",

                fontSize:
                  "13px",
              }}
            >
              ✅ Barcode मिल गया
              <br />
              Medicine:{" "}
              {
                findByBarcode(
                  barcode
                ).medicine
              }
            </div>
          )}

        {/* MEDICINE */}

        <label
          style={labelStyle}
        >
          Medicine
        </label>

        <select
          value={medicine}
          onChange={
            handleMedicineChange
          }
          style={{
            ...inputStyle,
            cursor:
              "pointer",
          }}
        >
          <option value="">
            Select Medicine
          </option>

          {currentStock.map(
            (item, index) => (
              <option
                key={
                  item.id ||
                  index
                }
                value={
                  item.medicine
                }
              >
                {item.medicine}
                {item.barcode
                  ? ` — ${item.barcode}`
                  : ""}
              </option>
            )
          )}
        </select>

        {/* MEDICINE DETAILS */}

        {selectedItem && (
          <div
            style={{
              background:
                "#f5f5f5",

              border:
                "1px solid #ddd",

              padding:
                "15px",

              borderRadius:
                "8px",

              marginBottom:
                "20px",
            }}
          >
            <p>
              💊 Medicine:{" "}
              <b>
                {
                  selectedItem.medicine
                }
              </b>
            </p>

            <p>
              📷 Barcode:{" "}
              <b>
                {
                  selectedItem.barcode ||
                  "-"
                }
              </b>
            </p>

            <p>
              🏢 Company:{" "}
              <b>
                {
                  selectedItem.company ||
                  "-"
                }
              </b>
            </p>

            <p>
              📦 Batch:{" "}
              <b>
                {
                  selectedItem.batch ||
                  "-"
                }
              </b>
            </p>

            <p>
              📦 Available Stock:{" "}
              <b>
                {
                  selectedItem.quantity
                }
              </b>
            </p>

            <p>
              🛒 Purchase Rate:{" "}
              <b>
                ₹
                {purchaseRate.toFixed(
                  2
                )}
              </b>
            </p>

            <p>
              🏷️ MRP:{" "}
              <b>
                ₹
                {Number(
                  selectedItem.mrp ||
                    0
                ).toFixed(2)}
              </b>
            </p>

            <p>
              💰 Sale Rate:{" "}
              <b>
                ₹
                {saleRate.toFixed(
                  2
                )}
              </b>
            </p>
          </div>
        )}

        {/* QUANTITY */}

        <label
          style={labelStyle}
        >
          Quantity
        </label>

        <input
          type="number"
          min="1"
          placeholder="Quantity"
          value={quantity}
          onChange={(e) =>
            setQuantity(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* CALCULATION */}

        {medicine &&
          quantity &&
          Number(quantity) > 0 && (
            <div
              style={{
                border:
                  "2px solid #ddd",

                padding:
                  "15px",

                borderRadius:
                  "8px",

                marginTop:
                  "15px",
              }}
            >
              <h3>
                💵 Sale Amount: ₹
                {totalAmount.toFixed(
                  2
                )}
              </h3>

              <p>
                🛒 Purchase Cost: ₹
                {totalPurchaseCost.toFixed(
                  2
                )}
              </p>

              <h3
                style={{
                  color:
                    profit >= 0
                      ? "#2e7d32"
                      : "#d32f2f",
                }}
              >
                📈 Profit: ₹
                {profit.toFixed(
                  2
                )}
              </h3>
            </div>
          )}

        {/* SAVE */}

        <button
          type="button"
          onClick={saveSale}
          style={{
            width:
              "100%",

            marginTop:
              "20px",

            padding:
              "14px",

            fontSize:
              "17px",

            fontWeight:
              "bold",

            background:
              "#2e7d32",

            color:
              "white",

            border:
              "none",

            borderRadius:
              "8px",

            cursor:
              "pointer",
          }}
        >
          💾 Save Sale
        </button>

        {/* BACK */}

        <button
          type="button"
          onClick={goBack}
          style={{
            width:
              "100%",

            marginTop:
              "10px",

            padding:
              "13px",

            background:
              "#555",

            color:
              "white",

            border:
              "none",

            borderRadius:
              "8px",

            fontSize:
              "16px",

            cursor:
              "pointer",
          }}
        >
          ⬅️ Back
        </button>
      </div>
    </div>
  );
}

// =========================
// STYLES
// =========================

const inputStyle = {
  display:
    "block",

  width:
    "100%",

  boxSizing:
    "border-box",

  padding:
    "12px",

  marginTop:
    "10px",

  marginBottom:
    "15px",

  fontSize:
    "16px",

  border:
    "1px solid #ccc",

  borderRadius:
    "7px",

  background:
    "white",
};

const labelStyle = {
  display:
    "block",

  fontSize:
    "13px",

  color:
    "#555",

  marginBottom:
    "5px",

  fontWeight:
    "bold",
};

export default Sale;