import React, { useEffect, useMemo, useState } from "react";

import Purchase from "./Purchase";
import Stock from "./Stock";
import Sale from "./Sale";
import Billing from "./Billing";
import Expiry from "./Expiry";
import BarcodeScanner from "./BarcodeScanner";

import CustomerLedger from "./CustomerLedger";
import CustomerPayment from "./CustomerPayment";

import SupplierLedger from "./SupplierLedger";
import SupplierPayment from "./SupplierPayment";

/* =========================================================
   DASHBOARD
========================================================= */

function Dashboard({
  stock,
  setStock,
  setPage,
  onLogout,
}) {
  const [page, setLocalPage] = useState("dashboard");
  const [refresh, setRefresh] = useState(0);

  /* =======================================================
     NAVIGATION
  ======================================================= */

  const goTo = (nextPage) => {
    setLocalPage(nextPage);

    if (setPage) {
      setPage(nextPage);
    }

    setRefresh((prev) => prev + 1);
  };

  const goDashboard = () => {
    setLocalPage("dashboard");

    if (setPage) {
      setPage("dashboard");
    }

    setRefresh((prev) => prev + 1);
  };

  /* =======================================================
     LOCAL STORAGE
  ======================================================= */

  const getArray = (key) => {
    try {
      const data = JSON.parse(
        localStorage.getItem(key) || "[]"
      );

      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  };

  /* =======================================================
     DATA
  ======================================================= */

  const bills = useMemo(
    () => getArray("bills"),
    [refresh]
  );

  const sales = useMemo(
    () => getArray("sales"),
    [refresh]
  );

  const purchases = useMemo(() => {
    const purchaseHistory =
      getArray("purchaseHistory");

    if (purchaseHistory.length > 0) {
      return purchaseHistory;
    }

    return getArray("purchases");
  }, [refresh]);

  const customerPayments = useMemo(
    () => getArray("customerPayments"),
    [refresh]
  );

  const supplierPayments = useMemo(
    () => getArray("supplierPayments"),
    [refresh]
  );

  /* =======================================================
     TOTAL SALE
  ======================================================= */

  const totalSale = useMemo(() => {
    return bills.reduce(
      (sum, bill) =>
        sum +
        Number(
          bill.total ??
            bill.saleAmount ??
            bill.amount ??
            0
        ),
      0
    );
  }, [bills]);

  /* =======================================================
     BILL PAID
  ======================================================= */

  const totalBillPaid = useMemo(() => {
    return bills.reduce(
      (sum, bill) =>
        sum +
        Number(
          bill.paidAmount ??
            bill.receivedAmount ??
            bill.paid ??
            0
        ),
      0
    );
  }, [bills]);

  /* =======================================================
     CUSTOMER PAYMENT
  ======================================================= */

  const totalCustomerPayment = useMemo(() => {
    return customerPayments.reduce(
      (sum, payment) =>
        sum +
        Number(payment.amount || 0),
      0
    );
  }, [customerPayments]);

  /* =======================================================
     CUSTOMER ORIGINAL UDHARI
     
     IMPORTANT:
     Billing में जो pendingAmount / udhari save है,
     वही actual customer credit है.
  ======================================================= */

  const totalOriginalCustomerUdhari =
    useMemo(() => {
      return bills.reduce(
        (sum, bill) => {
          const udhari = Number(
            bill.pendingAmount ??
              bill.udhari ??
              0
          );

          return sum + udhari;
        },
        0
      );
    }, [bills]);

  /* =======================================================
     CUSTOMER CURRENT UDHARI
     
     Original Udhari
            -
     Customer Payments
            =
     Current Udhari
  ======================================================= */

  const customerUdhari = useMemo(() => {
    return Math.max(
      totalOriginalCustomerUdhari -
        totalCustomerPayment,
      0
    );
  }, [
    totalOriginalCustomerUdhari,
    totalCustomerPayment,
  ]);

  /* =======================================================
     PROFIT
  ======================================================= */

  const totalProfit = useMemo(() => {
    return sales.reduce(
      (sum, sale) =>
        sum +
        Number(sale.profit || 0),
      0
    );
  }, [sales]);

  /* =======================================================
     TOTAL PURCHASE
  ======================================================= */

  const totalPurchase = useMemo(() => {
    return purchases.reduce(
      (sum, purchase) =>
        sum +
        Number(
          purchase.purchaseAmount ??
            purchase.total ??
            purchase.amount ??
            0
        ),
      0
    );
  }, [purchases]);

  /* =======================================================
     SUPPLIER PAYMENT
  ======================================================= */

  const totalSupplierPayment = useMemo(() => {
    return supplierPayments.reduce(
      (sum, payment) =>
        sum +
        Number(payment.amount || 0),
      0
    );
  }, [supplierPayments]);

  /* =======================================================
     SUPPLIER UDHARI
  ======================================================= */

  const supplierUdhari = useMemo(() => {
    return Math.max(
      totalPurchase -
        totalSupplierPayment,
      0
    );
  }, [
    totalPurchase,
    totalSupplierPayment,
  ]);

  /* =======================================================
     STOCK
  ======================================================= */

  const totalStockQuantity = useMemo(() => {
    if (!Array.isArray(stock)) {
      return 0;
    }

    return stock.reduce(
      (sum, item) =>
        sum +
        Number(item.quantity || 0),
      0
    );
  }, [stock]);

  /* =======================================================
     EXPIRY
  ======================================================= */

  const expiryCount = useMemo(() => {
    if (!Array.isArray(stock)) {
      return 0;
    }

    const today = new Date();

    return stock.filter((item) => {
      if (!item.expiry) {
        return false;
      }

      const expiryDate =
        new Date(item.expiry);

      if (
        Number.isNaN(
          expiryDate.getTime()
        )
      ) {
        return false;
      }

      const diff =
        expiryDate.getTime() -
        today.getTime();

      const days =
        diff /
        (1000 * 60 * 60 * 24);

      return (
        days >= 0 &&
        days <= 30
      );
    }).length;
  }, [stock]);

  /* =======================================================
     AUTO REFRESH
     
     Customer Payment के बाद same tab में भी
     Dashboard तुरंत refresh होगा.
  ======================================================= */

  useEffect(() => {
    const refreshDashboard = () => {
      setRefresh((prev) => prev + 1);
    };

    window.addEventListener(
      "storage",
      refreshDashboard
    );

    window.addEventListener(
      "customerPaymentUpdated",
      refreshDashboard
    );

    window.addEventListener(
      "customerLedgerUpdated",
      refreshDashboard
    );

    window.addEventListener(
      "supplierPaymentUpdated",
      refreshDashboard
    );

    const timer = setInterval(() => {
      setRefresh((prev) => prev + 1);
    }, 500);

    return () => {
      window.removeEventListener(
        "storage",
        refreshDashboard
      );

      window.removeEventListener(
        "customerPaymentUpdated",
        refreshDashboard
      );

      window.removeEventListener(
        "customerLedgerUpdated",
        refreshDashboard
      );

      window.removeEventListener(
        "supplierPaymentUpdated",
        refreshDashboard
      );

      clearInterval(timer);
    };
  }, []);

  /* =======================================================
     MONEY
  ======================================================= */

  const money = (value) =>
    `₹${Number(
      value || 0
    ).toFixed(2)}`;

  /* =======================================================
     LOGOUT
  ======================================================= */

  const logout = () => {
    if (
      window.confirm(
        "क्या आप Logout करना चाहते हैं?"
      )
    ) {
      localStorage.removeItem(
        "loggedIn"
      );

      if (onLogout) {
        onLogout();
      } else {
        window.location.reload();
      }
    }
  };

  /* =======================================================
     ROUTING
  ======================================================= */

  if (page === "purchase") {
    return (
      <Purchase
        stock={stock}
        setStock={setStock}
        goBack={goDashboard}
      />
    );
  }

  if (page === "stock") {
    return (
      <Stock
        stock={stock}
        setStock={setStock}
        goBack={goDashboard}
      />
    );
  }

  if (page === "sale") {
    return (
      <Sale
        stock={stock}
        setStock={setStock}
        goBack={goDashboard}
      />
    );
  }

  if (page === "billing") {
    return (
      <Billing
        stock={stock}
        setStock={setStock}
        goBack={goDashboard}
      />
    );
  }

  if (page === "expiry") {
    return (
      <Expiry
        stock={stock}
        goBack={goDashboard}
      />
    );
  }

  if (page === "barcode") {
    return (
      <BarcodeScanner
        stock={stock}
        goBack={goDashboard}
      />
    );
  }

  if (page === "customerLedger") {
    return (
      <CustomerLedger
        goBack={goDashboard}
        setPage={goTo}
      />
    );
  }

  if (page === "customerPayment") {
    return (
      <CustomerPayment
        goBack={goDashboard}
      />
    );
  }

  if (page === "supplierLedger") {
    return (
      <SupplierLedger
        goBack={goDashboard}
        setPage={goTo}
      />
    );
  }

  if (page === "supplierPayment") {
    return (
      <SupplierPayment
        goBack={goDashboard}
        setPage={goTo}
      />
    );
  }

  if (page === "reports") {
    return (
      <Reports
        bills={bills}
        sales={sales}
        purchases={purchases}
        customerPayments={
          customerPayments
        }
        supplierPayments={
          supplierPayments
        }
        goBack={goDashboard}
      />
    );
  }

  /* =======================================================
     MAIN DASHBOARD
  ======================================================= */

  return (
    <div style={pageStyle}>

      {/* HEADER */}

      <div style={headerStyle}>

        <div>
          <h1
            style={{
              margin: 0,
              fontSize: 25,
            }}
          >
            🏥 Shivam Medical ERP
          </h1>

          <div
            style={{
              marginTop: 4,
              fontSize: 13,
              opacity: 0.9,
            }}
          >
            Medical Store Management System
          </div>
        </div>

        <button
          onClick={logout}
          style={logoutButton}
        >
          🚪 Logout
        </button>

      </div>

      {/* SUMMARY */}

      <div style={summaryGrid}>

        <ClickableSummaryCard
          title="Total Sale"
          value={money(totalSale)}
          icon="💰"
          color="#1565c0"
          onClick={() =>
            goTo("reports")
          }
        />

        <ClickableSummaryCard
          title="Total Profit"
          value={money(totalProfit)}
          icon="📈"
          color="#2e7d32"
          onClick={() =>
            goTo("reports")
          }
        />

        <ClickableSummaryCard
          title="Customer Udhari"
          value={money(customerUdhari)}
          icon="👤"
          color={
            customerUdhari > 0
              ? "#d32f2f"
              : "#2e7d32"
          }
          onClick={() =>
            goTo(
              "customerLedger"
            )
          }
        />

        <ClickableSummaryCard
          title="Supplier Udhari"
          value={money(supplierUdhari)}
          icon="🏭"
          color={
            supplierUdhari > 0
              ? "#d32f2f"
              : "#2e7d32"
          }
          onClick={() =>
            goTo(
              "supplierLedger"
            )
          }
        />

        <ClickableSummaryCard
          title="Stock Quantity"
          value={totalStockQuantity}
          icon="📦"
          color="#00838f"
          onClick={() =>
            goTo("stock")
          }
        />

        <ClickableSummaryCard
          title="Expiry Alert"
          value={expiryCount}
          icon="📅"
          color={
            expiryCount > 0
              ? "#ef6c00"
              : "#2e7d32"
          }
          onClick={() =>
            goTo("expiry")
          }
        />

      </div>

      {/* CUSTOMER UDHARI ALERT */}

      {customerUdhari > 0 && (
        <div
          style={{
            ...alertBox,
            background:
              "linear-gradient(135deg,#ffebee,#fff5f5)",
            border:
              "1px solid #ef9a9a",
          }}
        >

          <div>
            <b
              style={{
                color: "#c62828",
                fontSize: 16,
              }}
            >
              ⚠️ Customer Udhari बाकी
            </b>

            <div
              style={{
                marginTop: 4,
                color: "#555",
                fontSize: 13,
              }}
            >
              कुल बाकी:{" "}
              <b
                style={{
                  color: "#c62828",
                }}
              >
                {money(
                  customerUdhari
                )}
              </b>
            </div>
          </div>

          <button
            onClick={() =>
              goTo(
                "customerLedger"
              )
            }
            style={redButton}
          >
            👤 Customer Ledger
          </button>

        </div>
      )}

      {/* SUPPLIER UDHARI ALERT */}

      {supplierUdhari > 0 && (
        <div
          style={{
            ...alertBox,
            background:
              "linear-gradient(135deg,#fff3e0,#fffaf4)",
            border:
              "1px solid #ffcc80",
          }}
        >

          <div>
            <b
              style={{
                color: "#ef6c00",
                fontSize: 16,
              }}
            >
              ⚠️ Supplier Udhari बाकी
            </b>

            <div
              style={{
                marginTop: 4,
                color: "#555",
                fontSize: 13,
              }}
            >
              कुल बाकी:{" "}
              <b
                style={{
                  color: "#ef6c00",
                }}
              >
                {money(
                  supplierUdhari
                )}
              </b>
            </div>
          </div>

          <button
            onClick={() =>
              goTo(
                "supplierLedger"
              )
            }
            style={orangeButton}
          >
            🏭 Supplier Ledger
          </button>

        </div>
      )}

      {/* QUICK MENU */}

      <div style={boxStyle}>

        <h2 style={sectionTitle}>
          ⚡ Quick Menu
        </h2>

        <div style={menuGrid}>

          <MenuButton
            icon="🛒"
            title="Purchase Entry"
            color="#1565c0"
            onClick={() =>
              goTo("purchase")
            }
          />

          <MenuButton
            icon="📦"
            title="Stock"
            color="#00838f"
            onClick={() =>
              goTo("stock")
            }
          />

          <MenuButton
            icon="💊"
            title="Sale Entry"
            color="#2e7d32"
            onClick={() =>
              goTo("sale")
            }
          />

          <MenuButton
            icon="🧾"
            title="Billing"
            color="#6a1b9a"
            onClick={() =>
              goTo("billing")
            }
          />

          <MenuButton
            icon="📷"
            title="Barcode Scanner"
            color="#3949ab"
            onClick={() =>
              goTo("barcode")
            }
          />

          <MenuButton
            icon="📊"
            title="Reports"
            color="#1565c0"
            onClick={() =>
              goTo("reports")
            }
          />

          <MenuButton
            icon="👤"
            title="Customer Ledger"
            color="#00838f"
            onClick={() =>
              goTo(
                "customerLedger"
              )
            }
          />

          <MenuButton
            icon="💰"
            title="Customer Payment"
            color="#2e7d32"
            onClick={() =>
              goTo(
                "customerPayment"
              )
            }
          />

          <MenuButton
            icon="🏭"
            title="Supplier Ledger"
            color="#ef6c00"
            onClick={() =>
              goTo(
                "supplierLedger"
              )
            }
          />

          <MenuButton
            icon="💵"
            title="Supplier Payment"
            color="#8e24aa"
            onClick={() =>
              goTo(
                "supplierPayment"
              )
            }
          />

          <MenuButton
            icon="📅"
            title="Expiry Alert"
            color="#d32f2f"
            badge={
              expiryCount > 0
                ? expiryCount
                : null
            }
            onClick={() =>
              goTo("expiry")
            }
          />

        </div>
      </div>

      {/* BUSINESS SUMMARY */}

      <div style={boxStyle}>

        <h2 style={sectionTitle}>
          📊 Business Summary
        </h2>

        <div style={businessGrid}>

          <InfoRow
            label="Total Sale"
            value={money(
              totalSale
            )}
            clickable
            onClick={() =>
              goTo("reports")
            }
          />

          <InfoRow
            label="Bill Paid"
            value={money(
              totalBillPaid
            )}
            clickable
            onClick={() =>
              goTo("reports")
            }
          />

          <InfoRow
            label="Customer Payment"
            value={money(
              totalCustomerPayment
            )}
            clickable
            onClick={() =>
              goTo("reports")
            }
          />

          <InfoRow
            label="Customer Udhari"
            value={money(
              customerUdhari
            )}
            danger={
              customerUdhari > 0
            }
            clickable
            onClick={() =>
              goTo(
                "customerLedger"
              )
            }
          />

          <InfoRow
            label="Total Purchase"
            value={money(
              totalPurchase
            )}
            clickable
            onClick={() =>
              goTo("reports")
            }
          />

          <InfoRow
            label="Supplier Payment"
            value={money(
              totalSupplierPayment
            )}
            clickable
            onClick={() =>
              goTo("reports")
            }
          />

          <InfoRow
            label="Supplier Udhari"
            value={money(
              supplierUdhari
            )}
            danger={
              supplierUdhari > 0
            }
            clickable
            onClick={() =>
              goTo(
                "supplierLedger"
              )
            }
          />

          <InfoRow
            label="Total Profit"
            value={money(
              totalProfit
            )}
            success
            clickable
            onClick={() =>
              goTo("reports")
            }
          />

        </div>
      </div>

      {/* FOOTER */}

      <div
        style={{
          textAlign: "center",
          color: "#777",
          fontSize: 12,
          padding: 15,
        }}
      >
        Shivam Medical ERP • Purchase • Sale •
        Billing • Stock • Barcode • Ledger • Reports
      </div>

    </div>
  );
}

/* =========================================================
   REPORTS
========================================================= */

function Reports({
  bills,
  sales,
  purchases,
  customerPayments,
  supplierPayments,
  goBack,
}) {
  const [reportType, setReportType] =
    useState("all");

  const [fromDate, setFromDate] =
    useState("");

  const [toDate, setToDate] =
    useState("");

  const money = (value) =>
    `₹${Number(
      value || 0
    ).toFixed(2)}`;

  const getItemDate = (item) => {
    return (
      item.date ||
      item.purchaseDate ||
      item.billDate ||
      ""
    );
  };

  const getItemTime = (item) => {
    if (item.time) {
      return item.time;
    }

    if (item.createdAt) {
      return new Date(
        item.createdAt
      ).toLocaleTimeString(
        "en-IN"
      );
    }

    return "-";
  };

  const isDateAllowed = (item) => {
    const itemDate =
      String(
        getItemDate(item)
      ).slice(0, 10);

    if (
      fromDate &&
      itemDate < fromDate
    ) {
      return false;
    }

    if (
      toDate &&
      itemDate > toDate
    ) {
      return false;
    }

    return true;
  };

  const reportRows = useMemo(() => {
    let rows = [];

    /* SALE */

    if (
      reportType === "all" ||
      reportType === "sale"
    ) {
      sales.forEach((sale) => {
        if (!isDateAllowed(sale)) {
          return;
        }

        rows.push({
          id:
            "sale_" +
            (sale.id ||
              Math.random()),

          type: "Sale",

          date:
            getItemDate(sale),

          time:
            getItemTime(sale),

          number:
            sale.billNumber ||
            sale.invoiceNumber ||
            "-",

          party:
            sale.customer ||
            "Cash Customer",

          detail:
            sale.medicine ||
            "-",

          amount:
            Number(
              sale.saleAmount ||
                sale.amount ||
                0
            ),

          profit:
            Number(
              sale.profit || 0
            ),

          udhari:
            Number(
              sale.pendingAmount ||
                sale.udhari ||
                0
            ),

          color:
            "#1565c0",
        });
      });
    }

    /* BILLING */

    if (
      reportType === "all" ||
      reportType === "sale"
    ) {
      bills.forEach((bill) => {
        if (!isDateAllowed(bill)) {
          return;
        }

        const billNo =
          bill.billNumber ||
          bill.invoiceNumber ||
          "-";

        const alreadyAdded =
          rows.some(
            (row) =>
              row.type === "Sale" &&
              row.number === billNo
          );

        if (alreadyAdded) {
          return;
        }

        rows.push({
          id:
            "bill_" +
            (bill.id ||
              Math.random()),

          type: "Bill",

          date:
            getItemDate(bill),

          time:
            getItemTime(bill),

          number: billNo,

          party:
            bill.customer ||
            "Cash Customer",

          detail: "Billing",

          amount:
            Number(
              bill.total ||
                bill.saleAmount ||
                bill.amount ||
                0
            ),

          profit:
            Number(
              bill.profit || 0
            ),

          udhari:
            Number(
              bill.pendingAmount ||
                bill.udhari ||
                0
            ),

          color:
            "#6a1b9a",
        });
      });
    }

    /* PURCHASE */

    if (
      reportType === "all" ||
      reportType === "purchase"
    ) {
      purchases.forEach(
        (purchase) => {
          if (
            !isDateAllowed(
              purchase
            )
          ) {
            return;
          }

          rows.push({
            id:
              "purchase_" +
              (purchase.id ||
                Math.random()),

            type: "Purchase",

            date:
              getItemDate(
                purchase
              ),

            time:
              getItemTime(
                purchase
              ),

            number:
              purchase.billNumber ||
              purchase.invoiceNumber ||
              "-",

            party:
              purchase.supplier ||
              purchase.company ||
              "-",

            detail:
              purchase.medicine ||
              "Purchase Entry",

            amount:
              Number(
                purchase.purchaseAmount ||
                  purchase.total ||
                  purchase.amount ||
                  0
              ),

            profit: 0,

            udhari:
              Number(
                purchase.pendingAmount ||
                  purchase.udhari ||
                  0
              ),

            color:
              "#ef6c00",
          });
        }
      );
    }

    /* CUSTOMER PAYMENT */

    if (
      reportType === "all" ||
      reportType ===
        "customerPayment"
    ) {
      customerPayments.forEach(
        (payment) => {
          if (
            !isDateAllowed(
              payment
            )
          ) {
            return;
          }

          rows.push({
            id:
              "customer_payment_" +
              (payment.id ||
                Math.random()),

            type:
              "Customer Payment",

            date:
              getItemDate(
                payment
              ),

            time:
              getItemTime(
                payment
              ),

            number: "-",

            party:
              payment.customer ||
              "-",

            detail:
              payment.mode ||
              "Payment",

            amount:
              Number(
                payment.amount ||
                  0
              ),

            profit: 0,

            udhari: 0,

            color:
              "#2e7d32",
          });
        }
      );
    }

    /* SUPPLIER PAYMENT */

    if (
      reportType === "all" ||
      reportType ===
        "supplierPayment"
    ) {
      supplierPayments.forEach(
        (payment) => {
          if (
            !isDateAllowed(
              payment
            )
          ) {
            return;
          }

          rows.push({
            id:
              "supplier_payment_" +
              (payment.id ||
                Math.random()),

            type:
              "Supplier Payment",

            date:
              getItemDate(
                payment
              ),

            time:
              getItemTime(
                payment
              ),

            number: "-",

            party:
              payment.supplier ||
              "-",

            detail:
              payment.mode ||
              "Payment",

            amount:
              Number(
                payment.amount ||
                  0
              ),

            profit: 0,

            udhari: 0,

            color:
              "#8e24aa",
          });
        }
      );
    }

    return rows.sort(
      (a, b) =>
        (
          String(b.date) +
          " " +
          String(b.time)
        ).localeCompare(
          String(a.date) +
          " " +
          String(a.time)
        )
    );
  }, [
    bills,
    sales,
    purchases,
    customerPayments,
    supplierPayments,
    reportType,
    fromDate,
    toDate,
  ]);

  const totalAmount =
    reportRows.reduce(
      (sum, row) =>
        sum +
        Number(row.amount || 0),
      0
    );

  const totalProfit =
    reportRows.reduce(
      (sum, row) =>
        sum +
        Number(row.profit || 0),
      0
    );

  const totalUdhari =
    reportRows.reduce(
      (sum, row) =>
        sum +
        Number(row.udhari || 0),
      0
    );

  const clearFilter = () => {
    setReportType("all");
    setFromDate("");
    setToDate("");
  };

  return (
    <div style={pageStyle}>

      <div style={headerStyle}>

        <div>
          <h2 style={{ margin: 0 }}>
            📊 Reports
          </h2>

          <div
            style={{
              fontSize: 13,
              marginTop: 3,
            }}
          >
            Shivam Medical ERP
          </div>
        </div>

        <button
          onClick={goBack}
          style={backButton}
        >
          ⬅️ Dashboard
        </button>

      </div>

      {/* FILTER */}

      <div style={boxStyle}>

        <h3 style={{ marginTop: 0 }}>
          🔎 Report Filter
        </h3>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit,minmax(180px,1fr))",
            gap: 10,
          }}
        >

          <div>
            <label style={labelStyle}>
              Report Type
            </label>

            <select
              value={reportType}
              onChange={(e) =>
                setReportType(
                  e.target.value
                )
              }
              style={selectStyle}
            >
              <option value="all">
                All Reports
              </option>

              <option value="sale">
                Sale / Billing
              </option>

              <option value="purchase">
                Purchase
              </option>

              <option value="customerPayment">
                Customer Payment
              </option>

              <option value="supplierPayment">
                Supplier Payment
              </option>
            </select>
          </div>

          <div>
            <label style={labelStyle}>
              From Date
            </label>

            <input
              type="date"
              value={fromDate}
              onChange={(e) =>
                setFromDate(
                  e.target.value
                )
              }
              style={selectStyle}
            />
          </div>

          <div>
            <label style={labelStyle}>
              To Date
            </label>

            <input
              type="date"
              value={toDate}
              onChange={(e) =>
                setToDate(
                  e.target.value
                )
              }
              style={selectStyle}
            />
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "end",
            }}
          >
            <button
              onClick={clearFilter}
              style={clearButton}
            >
              🔄 Clear Filter
            </button>
          </div>

        </div>
      </div>

      {/* REPORT SUMMARY */}

      <div style={summaryGrid}>

        <SummaryCard
          title="Report Entries"
          value={
            reportRows.length
          }
          icon="📋"
          color="#1565c0"
        />

        <SummaryCard
          title="Amount"
          value={money(totalAmount)}
          icon="💰"
          color="#00838f"
        />

        <SummaryCard
          title="Profit"
          value={money(totalProfit)}
          icon="📈"
          color="#2e7d32"
        />

        <SummaryCard
          title="Udhari"
          value={money(totalUdhari)}
          icon="⚠️"
          color="#d32f2f"
        />

      </div>

      {/* REPORT TABLE */}

      <div style={boxStyle}>

        <h3 style={{ marginTop: 0 }}>
          📑 Report Details
        </h3>

        {reportRows.length === 0 ? (
          <div
            style={{
              padding: 30,
              textAlign: "center",
              color: "#777",
            }}
          >
            इस Filter में कोई Report उपलब्ध नहीं है।
          </div>
        ) : (
          <div
            style={{
              overflowX: "auto",
            }}
          >

            <table style={tableStyle}>

              <thead>
                <tr>

                  <th style={thStyle}>
                    #
                  </th>

                  <th style={thStyle}>
                    Type
                  </th>

                  <th style={thStyle}>
                    Date
                  </th>

                  <th style={thStyle}>
                    Time
                  </th>

                  <th style={thStyle}>
                    Bill / No.
                  </th>

                  <th style={thStyle}>
                    Customer / Supplier
                  </th>

                  <th style={thStyle}>
                    Details
                  </th>

                  <th style={thStyle}>
                    Amount
                  </th>

                  <th style={thStyle}>
                    Profit
                  </th>

                  <th style={thStyle}>
                    Udhari
                  </th>

                </tr>
              </thead>

              <tbody>

                {reportRows.map(
                  (row, index) => (
                    <tr key={row.id}>

                      <td style={tdStyle}>
                        {index + 1}
                      </td>

                      <td
                        style={{
                          ...tdStyle,
                          color: row.color,
                          fontWeight:
                            "bold",
                        }}
                      >
                        {row.type}
                      </td>

                      <td style={tdStyle}>
                        {row.date || "-"}
                      </td>

                      <td
                        style={{
                          ...tdStyle,
                          fontWeight:
                            "bold",
                          color:
                            "#37474f",
                        }}
                      >
                        {row.time || "-"}
                      </td>

                      <td
                        style={{
                          ...tdStyle,
                          fontWeight:
                            "bold",
                          color:
                            row.number !==
                            "-"
                              ? "#6a1b9a"
                              : "#777",
                        }}
                      >
                        {row.number}
                      </td>

                      <td style={tdStyle}>
                        {row.party}
                      </td>

                      <td style={tdStyle}>
                        {row.detail}
                      </td>

                      <td
                        style={{
                          ...tdStyle,
                          fontWeight:
                            "bold",
                        }}
                      >
                        {money(
                          row.amount
                        )}
                      </td>

                      <td
                        style={{
                          ...tdStyle,
                          color:
                            "#2e7d32",
                          fontWeight:
                            "bold",
                        }}
                      >
                        {money(
                          row.profit
                        )}
                      </td>

                      <td
                        style={{
                          ...tdStyle,
                          color:
                            Number(
                              row.udhari
                            ) > 0
                              ? "#d32f2f"
                              : "#2e7d32",
                          fontWeight:
                            "bold",
                        }}
                      >
                        {money(
                          row.udhari
                        )}
                      </td>

                    </tr>
                  )
                )}

              </tbody>

            </table>

          </div>
        )}

      </div>

    </div>
  );
}

/* =========================================================
   SUMMARY CARD
========================================================= */

function SummaryCard({
  title,
  value,
  icon,
  color,
}) {
  return (
    <div
      style={{
        background: "white",
        padding: 15,
        borderRadius: 10,
        borderLeft:
          `5px solid ${color}`,
        boxShadow:
          "0 2px 8px rgba(0,0,0,0.06)",
      }}
    >

      <div style={{ fontSize: 25 }}>
        {icon}
      </div>

      <div
        style={{
          fontSize: 12,
          color: "#777",
          marginTop: 5,
        }}
      >
        {title}
      </div>

      <div
        style={{
          fontSize: 20,
          fontWeight: "bold",
          color,
          marginTop: 4,
        }}
      >
        {value}
      </div>

    </div>
  );
}

/* =========================================================
   CLICKABLE SUMMARY
========================================================= */

function ClickableSummaryCard({
  title,
  value,
  icon,
  color,
  onClick,
}) {
  return (
    <button
      onClick={onClick}
      style={{
        background: "white",
        padding: 15,
        borderRadius: 10,
        border: "none",
        borderLeft:
          `5px solid ${color}`,
        boxShadow:
          "0 2px 8px rgba(0,0,0,0.06)",
        textAlign: "left",
        cursor: "pointer",
      }}
    >

      <div style={{ fontSize: 25 }}>
        {icon}
      </div>

      <div
        style={{
          fontSize: 12,
          color: "#777",
          marginTop: 5,
        }}
      >
        {title}
      </div>

      <div
        style={{
          fontSize: 20,
          fontWeight: "bold",
          color,
          marginTop: 4,
        }}
      >
        {value}
      </div>

      <div
        style={{
          fontSize: 10,
          color: "#999",
          marginTop: 5,
        }}
      >
        Click to view report →
      </div>

    </button>
  );
}

/* =========================================================
   MENU BUTTON
========================================================= */

function MenuButton({
  icon,
  title,
  color,
  onClick,
  badge,
}) {
  return (
    <button
      onClick={onClick}
      style={{
        position: "relative",
        border: "none",
        background: "white",
        borderRadius: 10,
        padding: "18px 10px",
        cursor: "pointer",
        boxShadow:
          "0 2px 8px rgba(0,0,0,0.08)",
        borderTop:
          `4px solid ${color}`,
      }}
    >

      <div style={{ fontSize: 30 }}>
        {icon}
      </div>

      <div
        style={{
          marginTop: 8,
          fontWeight: "bold",
          color: "#333",
          fontSize: 13,
        }}
      >
        {title}
      </div>

      {badge !== null &&
        badge !== undefined && (
          <span
            style={{
              position: "absolute",
              top: 7,
              right: 7,
              minWidth: 20,
              height: 20,
              borderRadius: 20,
              background: "#d32f2f",
              color: "white",
              fontSize: 11,
              display: "flex",
              alignItems: "center",
              justifyContent:
                "center",
              fontWeight: "bold",
            }}
          >
            {badge}
          </span>
        )}

    </button>
  );
}

/* =========================================================
   INFO ROW
========================================================= */

function InfoRow({
  label,
  value,
  danger,
  success,
  clickable,
  onClick,
}) {
  return (
    <button
      onClick={onClick}
      disabled={!clickable}
      style={{
        display: "flex",
        justifyContent:
          "space-between",
        alignItems: "center",
        gap: 10,
        padding: "11px 0",
        border: "none",
        borderBottom:
          "1px solid #eee",
        background: "transparent",
        width: "100%",
        cursor:
          clickable
            ? "pointer"
            : "default",
        textAlign: "left",
      }}
    >

      <span
        style={{
          color: "#555",
          fontSize: 13,
        }}
      >
        {clickable && "🔗 "}
        {label}
      </span>

      <b
        style={{
          color:
            danger
              ? "#d32f2f"
              : success
              ? "#2e7d32"
              : "#1565c0",
        }}
      >
        {value}
      </b>

    </button>
  );
}

/* =========================================================
   STYLES
========================================================= */

const pageStyle = {
  minHeight: "100vh",
  padding: 15,
  background: "#f2f5f9",
  fontFamily:
    "Arial, sans-serif",
  boxSizing: "border-box",
};

const headerStyle = {
  background:
    "linear-gradient(135deg,#1565c0,#42a5f5)",
  color: "white",
  padding: "16px 18px",
  borderRadius: 12,
  marginBottom: 15,
  display: "flex",
  justifyContent:
    "space-between",
  alignItems: "center",
  gap: 10,
};

const logoutButton = {
  background: "white",
  color: "#d32f2f",
  border: "none",
  padding: "9px 14px",
  borderRadius: 7,
  fontWeight: "bold",
  cursor: "pointer",
};

const backButton = {
  background: "white",
  color: "#1565c0",
  border: "none",
  padding: "9px 14px",
  borderRadius: 7,
  fontWeight: "bold",
  cursor: "pointer",
};

const summaryGrid = {
  display: "grid",
  gridTemplateColumns:
    "repeat(auto-fit,minmax(170px,1fr))",
  gap: 10,
  marginBottom: 15,
};

const boxStyle = {
  background: "white",
  padding: 15,
  borderRadius: 10,
  marginBottom: 15,
  boxShadow:
    "0 2px 8px rgba(0,0,0,0.06)",
};

const sectionTitle = {
  marginTop: 0,
  marginBottom: 14,
};

const menuGrid = {
  display: "grid",
  gridTemplateColumns:
    "repeat(auto-fit,minmax(140px,1fr))",
  gap: 12,
};

const businessGrid = {
  display: "grid",
  gridTemplateColumns:
    "repeat(auto-fit,minmax(240px,1fr))",
  gap: "0 25px",
};

const alertBox = {
  padding: 14,
  borderRadius: 10,
  marginBottom: 12,
  display: "flex",
  justifyContent:
    "space-between",
  alignItems: "center",
  gap: 10,
  flexWrap: "wrap",
};

const redButton = {
  background: "#d32f2f",
  color: "white",
  border: "none",
  padding: "9px 13px",
  borderRadius: 7,
  fontWeight: "bold",
  cursor: "pointer",
};

const orangeButton = {
  background: "#ef6c00",
  color: "white",
  border: "none",
  padding: "9px 13px",
  borderRadius: 7,
  fontWeight: "bold",
  cursor: "pointer",
};

const labelStyle = {
  display: "block",
  fontSize: 12,
  color: "#555",
  marginBottom: 5,
  fontWeight: "bold",
};

const selectStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: 10,
  border: "1px solid #ccc",
  borderRadius: 7,
  background: "white",
  fontSize: 14,
};

const clearButton = {
  width: "100%",
  padding: 10,
  border: "none",
  borderRadius: 7,
  background: "#555",
  color: "white",
  fontWeight: "bold",
  cursor: "pointer",
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse",
  fontSize: 12,
};

const thStyle = {
  border: "1px solid #ddd",
  padding: 8,
  background: "#f1f5f9",
  whiteSpace: "nowrap",
};

const tdStyle = {
  border: "1px solid #ddd",
  padding: 8,
  whiteSpace: "nowrap",
};

export default Dashboard;