import React, { useState } from "react";

function PaymentHistory({ goBack }) {
  const [payments, setPayments] = useState(() => {
    try {
      const saved = localStorage.getItem("paymentHistory");
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error("Payment history error:", error);
      return [];
    }
  });

  const [search, setSearch] = useState("");

  const deletePayment = (index) => {
    if (!window.confirm("क्या आप यह payment history delete करना चाहते हैं?")) {
      return;
    }

    const updatedPayments = payments.filter(
      (_, paymentIndex) => paymentIndex !== index
    );

    setPayments(updatedPayments);

    localStorage.setItem(
      "paymentHistory",
      JSON.stringify(updatedPayments)
    );
  };

  const filteredPayments = payments.filter((payment) =>
    String(payment.customer || "")
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  const totalReceived = filteredPayments.reduce(
    (sum, payment) => sum + Number(payment.amount || 0),
    0
  );

  return (
    <div style={{ padding: "20px" }}>
      <h2>💰 Payment History</h2>

      <button onClick={goBack}>⬅️ Back</button>

      <hr />

      <input
        type="text"
        placeholder="🔍 Search Customer"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{
          padding: "8px",
          width: "250px",
        }}
      />

      <br />
      <br />

      <h3>
        💰 Total Payment Received: ₹{totalReceived.toFixed(2)}
      </h3>

      <hr />

      {filteredPayments.length === 0 ? (
        <h3>No Payment History</h3>
      ) : (
        <table
          border="1"
          cellPadding="8"
          style={{
            borderCollapse: "collapse",
            width: "100%",
          }}
        >
          <thead>
            <tr>
              <th>Customer</th>
              <th>Mobile</th>
              <th>Amount</th>
              <th>Date</th>
              <th>Time</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {filteredPayments.map((payment, index) => (
              <tr key={index}>
                <td>{payment.customer || "-"}</td>
                <td>{payment.mobile || "-"}</td>
                <td>₹{Number(payment.amount || 0).toFixed(2)}</td>
                <td>{payment.date || "-"}</td>
                <td>{payment.time || "-"}</td>
                <td>
                  <button onClick={() => deletePayment(index)}>
                    🗑️ Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default PaymentHistory;