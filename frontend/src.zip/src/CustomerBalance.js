export const getArray = (key) => {
  try {
    const data = JSON.parse(
      localStorage.getItem(key) || "[]"
    );

    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
};

export const normalizeCustomerName = (name) =>
  String(name || "")
    .trim()
    .toLowerCase();

export const normalizeMobile = (mobile) =>
  String(mobile || "").trim();

export const isSameCustomer = (
  item,
  customer,
  mobile
) => {
  return (
    normalizeCustomerName(item.customer) ===
      normalizeCustomerName(customer) &&
    normalizeMobile(item.mobile) ===
      normalizeMobile(mobile)
  );
};

/*
=========================================================
  CUSTOMER BALANCE
=========================================================
*/

export const getCustomerBalance = (
  customer,
  mobile
) => {
  const bills = getArray("bills");
  const sales = getArray("sales");
  const payments = getArray(
    "customerPayments"
  );

  const name = String(customer || "").trim();
  const phone = String(mobile || "").trim();

  if (!name) {
    return {
      totalCredit: 0,
      billPaid: 0,
      paymentReceived: 0,
      pending: 0,
    };
  }

  /*
  -------------------------------------------------------
  BILLS
  -------------------------------------------------------
  */

  const customerBills = bills.filter(
    (bill) =>
      isSameCustomer(
        bill,
        name,
        phone
      )
  );

  /*
  -------------------------------------------------------
  ONLY CREDIT / UDHARI BILLS
  -------------------------------------------------------
  */

  const creditBills =
    customerBills.filter((bill) => {
      const total = Number(
        bill.total || 0
      );

      const paid = Number(
        bill.paidAmount || 0
      );

      const pending = Number(
        bill.pendingAmount ||
          bill.udhari ||
          Math.max(total - paid, 0)
      );

      return (
        pending > 0 ||
        bill.credit === true ||
        bill.isCredit === true
      );
    });

  /*
  -------------------------------------------------------
  TOTAL BILL AMOUNT
  -------------------------------------------------------
  */

  const totalCredit =
    creditBills.reduce(
      (sum, bill) =>
        sum +
        Number(
          bill.total || 0
        ),
      0
    );

  /*
  -------------------------------------------------------
  BILL PAYMENT
  -------------------------------------------------------
  */

  const billPaid =
    creditBills.reduce(
      (sum, bill) =>
        sum +
        Number(
          bill.paidAmount || 0
        ),
      0
    );

  /*
  -------------------------------------------------------
  CUSTOMER LEDGER PAYMENTS
  -------------------------------------------------------
  */

  const paymentReceived =
    payments
      .filter((payment) =>
        isSameCustomer(
          payment,
          name,
          phone
        )
      )
      .reduce(
        (sum, payment) =>
          sum +
          Number(
            payment.amount || 0
          ),
        0
      );

  /*
  -------------------------------------------------------
  FINAL BALANCE
  -------------------------------------------------------
  */

  const pending = Math.max(
    totalCredit -
      billPaid -
      paymentReceived,
    0
  );

  return {
    totalCredit,
    billPaid,
    paymentReceived,
    pending,
  };
};