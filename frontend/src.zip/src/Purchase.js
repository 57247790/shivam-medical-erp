import { useState } from "react";

function Purchase({ stock, setStock, goBack }) {
  const [medicine, setMedicine] = useState("");
  const [company, setCompany] = useState("");
  const [batch, setBatch] = useState("");
  const [barcode, setBarcode] = useState("");
  const [supplier, setSupplier] = useState("");
  const [quantity, setQuantity] = useState("");

  const [rate, setRate] = useState("");
  const [mrp, setMrp] = useState("");
  const [saleRate, setSaleRate] = useState("");
  const [expiry, setExpiry] = useState("");

  const currentStock = Array.isArray(stock)
    ? stock
    : [];

  // =====================================================
  // TODAY DATE
  // =====================================================

  const getTodayDate = () => {
    const now = new Date();

    return `${now.getFullYear()}-${String(
      now.getMonth() + 1
    ).padStart(2, "0")}-${String(
      now.getDate()
    ).padStart(2, "0")}`;
  };

  // =====================================================
  // BARCODE AUTO-FILL
  // =====================================================

  const handleBarcodeChange = (value) => {
    setBarcode(value);

    const cleanBarcode =
      value.trim().toLowerCase();

    // Empty barcode
    if (!cleanBarcode) {
      return;
    }

    // Find barcode
    const found = currentStock.find(
      (item) =>
        String(item.barcode || "")
          .trim()
          .toLowerCase() ===
        cleanBarcode
    );

    // ===================================================
    // BARCODE FOUND
    // ===================================================

    if (found) {
      setMedicine(
        found.medicine || ""
      );

      setCompany(
        found.company || ""
      );

      setBatch(
        found.batch || ""
      );

      setSupplier(
        found.supplier || ""
      );

      setRate(
        found.purchaseRate ||
          found.rate ||
          ""
      );

      setMrp(
        found.mrp || ""
      );

      setSaleRate(
        found.saleRate || ""
      );

      setExpiry(
        found.expiry || ""
      );

      return;
    }

    // ===================================================
    // BARCODE NOT FOUND
    // ===================================================

    setMedicine("");
    setCompany("");
    setBatch("");
    setSupplier("");
    setRate("");
    setMrp("");
    setSaleRate("");
    setExpiry("");

    alert(
      "⚠️ Barcode नहीं मिला!\n\n" +
        "यह Barcode अभी Shivam Medical ERP के Stock में मौजूद नहीं है।\n\n" +
        "👉 अगर यह नई Medicine है तो बाकी details भरकर Purchase Save करें।\n\n" +
        "Barcode: " +
        value
    );
  };

  // =====================================================
  // SAVE PURCHASE
  // =====================================================

  const savePurchase = () => {
    // ===================================================
    // REQUIRED FIELDS
    // ===================================================

    if (
      !medicine.trim() ||
      !company.trim() ||
      !batch.trim() ||
      !barcode.trim() ||
      !supplier.trim() ||
      !quantity ||
      !rate ||
      !mrp ||
      !saleRate ||
      !expiry
    ) {
      alert(
        "⚠️ Please fill all fields"
      );
      return;
    }

    // ===================================================
    // NUMBERS
    // ===================================================

    const qty = Number(quantity);

    const purchaseRate =
      Number(rate);

    const medicineMrp =
      Number(mrp);

    const medicineSaleRate =
      Number(saleRate);

    if (qty <= 0) {
      alert(
        "⚠️ Quantity सही डालें"
      );
      return;
    }

    if (purchaseRate <= 0) {
      alert(
        "⚠️ Purchase Rate सही डालें"
      );
      return;
    }

    if (medicineMrp <= 0) {
      alert(
        "⚠️ MRP सही डालें"
      );
      return;
    }

    if (medicineSaleRate <= 0) {
      alert(
        "⚠️ Sale Rate सही डालें"
      );
      return;
    }

    if (
      medicineSaleRate >
      medicineMrp
    ) {
      alert(
        "⚠️ Sale Rate, MRP से ज्यादा नहीं हो सकता"
      );
      return;
    }

    // ===================================================
    // CLEAN DATA
    // ===================================================

    const cleanMedicine =
      medicine.trim();

    const cleanCompany =
      company.trim();

    const cleanBatch =
      batch.trim();

    const cleanBarcode =
      barcode.trim();

    const cleanSupplier =
      supplier.trim();

    // ===================================================
    // DATE / ID
    // ===================================================

    const now = new Date();

    const purchaseDate =
      getTodayDate();

    const createdAt =
      Date.now();

    // ===================================================
    // PURCHASE AMOUNT
    // ===================================================

    const purchaseAmount =
      qty * purchaseRate;

    // ===================================================
    // FIND EXISTING BARCODE
    // ===================================================

    const existingIndex =
      currentStock.findIndex(
        (item) =>
          String(item.barcode || "")
            .trim()
            .toLowerCase() ===
          cleanBarcode.toLowerCase()
      );

    let updatedStock;

    // ===================================================
    // EXISTING BARCODE
    // ===================================================

    if (existingIndex !== -1) {
      const existingItem =
        currentStock[
          existingIndex
        ];

      const updatedItem = {
        ...existingItem,

        medicine:
          cleanMedicine,

        company:
          cleanCompany,

        batch:
          cleanBatch,

        barcode:
          cleanBarcode,

        supplier:
          cleanSupplier,

        quantity:
          Number(
            existingItem.quantity || 0
          ) + qty,

        purchaseRate:
          purchaseRate,

        rate:
          purchaseRate,

        mrp:
          medicineMrp,

        saleRate:
          medicineSaleRate,

        expiry:
          expiry,

        purchaseDate:
          purchaseDate,

        date:
          purchaseDate,

        updatedAt:
          createdAt,
      };

      updatedStock = [
        ...currentStock,
      ];

      updatedStock[
        existingIndex
      ] = updatedItem;
    }

    // ===================================================
    // NEW BARCODE / NEW MEDICINE
    // ===================================================

    else {
      const newItem = {
        id:
          createdAt,

        medicine:
          cleanMedicine,

        company:
          cleanCompany,

        batch:
          cleanBatch,

        barcode:
          cleanBarcode,

        supplier:
          cleanSupplier,

        quantity:
          qty,

        purchaseRate:
          purchaseRate,

        rate:
          purchaseRate,

        mrp:
          medicineMrp,

        saleRate:
          medicineSaleRate,

        expiry:
          expiry,

        purchaseDate:
          purchaseDate,

        date:
          purchaseDate,

        createdAt:
          createdAt,
      };

      updatedStock = [
        ...currentStock,
        newItem,
      ];
    }

    // ===================================================
    // UPDATE STOCK
    // ===================================================

    setStock(
      updatedStock
    );

    localStorage.setItem(
      "stock",
      JSON.stringify(
        updatedStock
      )
    );

    // ===================================================
    // PURCHASE HISTORY
    // ===================================================

    let purchaseHistory = [];

    try {
      const saved =
        JSON.parse(
          localStorage.getItem(
            "purchaseHistory"
          ) || "[]"
        );

      if (
        Array.isArray(saved)
      ) {
        purchaseHistory =
          saved;
      }
    } catch {
      purchaseHistory = [];
    }

    // ===================================================
    // NEW PURCHASE RECORD
    // ===================================================

    const newPurchase = {
      id:
        createdAt,

      medicine:
        cleanMedicine,

      company:
        cleanCompany,

      batch:
        cleanBatch,

      barcode:
        cleanBarcode,

      supplier:
        cleanSupplier,

      quantity:
        qty,

      purchaseRate:
        purchaseRate,

      rate:
        purchaseRate,

      mrp:
        medicineMrp,

      saleRate:
        medicineSaleRate,

      purchaseAmount:
        purchaseAmount,

      expiry:
        expiry,

      purchaseDate:
        purchaseDate,

      date:
        purchaseDate,

      time:
        now.toLocaleTimeString(),

      createdAt:
        createdAt,
    };

    const updatedPurchaseHistory =
      [
        newPurchase,
        ...purchaseHistory,
      ];

    localStorage.setItem(
      "purchaseHistory",
      JSON.stringify(
        updatedPurchaseHistory
      )
    );

    // ===================================================
    // SUCCESS MESSAGE
    // ===================================================

    if (
      existingIndex !== -1
    ) {
      const newTotalStock =
        Number(
          updatedStock[
            existingIndex
          ].quantity || 0
        );

      alert(
        "✅ Existing Medicine में Purchase Add हो गया\n\n" +
          "Medicine: " +
          cleanMedicine +
          "\nBarcode: " +
          cleanBarcode +
          "\nAdded Quantity: " +
          qty +
          "\nNew Total Stock: " +
          newTotalStock
      );
    } else {
      alert(
        "✅ Purchase Saved Successfully\n\n" +
          "Medicine: " +
          cleanMedicine +
          "\nCompany: " +
          cleanCompany +
          "\nBatch: " +
          cleanBatch +
          "\nBarcode: " +
          cleanBarcode +
          "\nSupplier: " +
          cleanSupplier +
          "\nQuantity: " +
          qty +
          "\nPurchase Rate: ₹" +
          purchaseRate.toFixed(2) +
          "\nSale Rate: ₹" +
          medicineSaleRate.toFixed(2) +
          "\nMRP: ₹" +
          medicineMrp.toFixed(2)
      );
    }

    // ===================================================
    // RESET FORM
    // ===================================================

    setMedicine("");
    setCompany("");
    setBatch("");
    setBarcode("");
    setSupplier("");
    setQuantity("");

    setRate("");
    setMrp("");
    setSaleRate("");
    setExpiry("");
  };

  // =====================================================
  // UI
  // =====================================================

  return (
    <div
      style={{
        minHeight:
          "100vh",

        padding:
          "20px",

        background:
          "#f2f5f9",

        fontFamily:
          "Arial, sans-serif",

        boxSizing:
          "border-box",
      }}
    >
      {/* =================================================
          HEADER
      ================================================= */}

      <div
        style={{
          background:
            "linear-gradient(135deg,#1976d2,#42a5f5)",

          color:
            "white",

          padding:
            "20px",

          borderRadius:
            "12px",

          marginBottom:
            "20px",
        }}
      >
        <h1
          style={{
            margin:
              0,
          }}
        >
          🛒 Purchase Entry
        </h1>

        <p
          style={{
            marginBottom:
              0,
          }}
        >
          Medicine Purchase &
          Supplier Entry
        </p>
      </div>

      {/* =================================================
          FORM
      ================================================= */}

      <div
        style={{
          background:
            "white",

          padding:
            "25px",

          borderRadius:
            "12px",

          maxWidth:
            "700px",

          margin:
            "auto",

          boxShadow:
            "0 3px 10px rgba(0,0,0,0.08)",
        }}
      >
        <h2>
          💊 Medicine Details
        </h2>

        {/* =================================================
            MEDICINE
        ================================================= */}

        <input
          placeholder="Medicine Name"
          value={
            medicine
          }
          onChange={(e) =>
            setMedicine(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* =================================================
            COMPANY
        ================================================= */}

        <input
          placeholder="Company"
          value={
            company
          }
          onChange={(e) =>
            setCompany(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* =================================================
            BATCH
        ================================================= */}

        <input
          placeholder="Batch No."
          value={
            batch
          }
          onChange={(e) =>
            setBatch(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* =================================================
            BARCODE
        ================================================= */}

        <input
          placeholder="Barcode Scan / Enter Barcode"
          value={
            barcode
          }
          onChange={(e) =>
            handleBarcodeChange(
              e.target.value
            )
          }
          style={{
            ...inputStyle,

            border:
              "2px solid #1976d2",

            background:
              "#f8fbff",
          }}
          autoFocus
        />

        <div
          style={{
            marginTop:
              "-8px",

            marginBottom:
              "12px",

            padding:
              "10px",

            background:
              "#e3f2fd",

            color:
              "#1565c0",

            borderRadius:
              "6px",

            fontSize:
              "12px",

            fontWeight:
              "bold",
          }}
        >
          📷 Barcode Scan / Enter करें।
          <br />
          ✅ Barcode मिला तो Medicine
          Details Auto-Fill होंगी।
          <br />
          ⚠️ Barcode नहीं मिला तो Warning
          आएगी और नई Medicine की Entry
          कर सकते हैं।
        </div>

        {/* =================================================
            SUPPLIER
        ================================================= */}

        <input
          placeholder="Supplier Name"
          value={
            supplier
          }
          onChange={(e) =>
            setSupplier(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        <hr />

        <h2>
          💰 Rate & Quantity
        </h2>

        {/* =================================================
            QUANTITY
        ================================================= */}

        <input
          type="number"
          min="1"
          placeholder="Quantity"
          value={
            quantity
          }
          onChange={(e) =>
            setQuantity(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* =================================================
            PURCHASE RATE
        ================================================= */}

        <input
          type="number"
          step="0.01"
          placeholder="Purchase Rate ₹"
          value={
            rate
          }
          onChange={(e) =>
            setRate(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* =================================================
            MRP
        ================================================= */}

        <input
          type="number"
          step="0.01"
          placeholder="MRP ₹"
          value={
            mrp
          }
          onChange={(e) =>
            setMrp(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* =================================================
            SALE RATE
        ================================================= */}

        <input
          type="number"
          step="0.01"
          placeholder="Sale Rate ₹"
          value={
            saleRate
          }
          onChange={(e) =>
            setSaleRate(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* =================================================
            EXPIRY
        ================================================= */}

        <h3>
          📅 Expiry Date
        </h3>

        <input
          type="date"
          value={
            expiry
          }
          onChange={(e) =>
            setExpiry(
              e.target.value
            )
          }
          style={
            inputStyle
          }
        />

        {/* =================================================
            PURCHASE AMOUNT
        ================================================= */}

        <div
          style={{
            marginTop:
              "20px",

            padding:
              "18px",

            background:
              "#e8f5e9",

            borderRadius:
              "10px",
          }}
        >
          <h2
            style={{
              margin:
                0,

              color:
                "#2e7d32",
            }}
          >
            💰 Purchase Amount: ₹
            {quantity &&
            rate
              ? (
                  Number(
                    quantity
                  ) *
                  Number(
                    rate
                  )
                ).toFixed(2)
              : "0.00"}
          </h2>
        </div>

        {/* =================================================
            SAVE
        ================================================= */}

        <button
          type="button"
          onClick={
            savePurchase
          }
          style={{
            width:
              "100%",

            marginTop:
              "20px",

            padding:
              "14px",

            background:
              "#1976d2",

            color:
              "white",

            border:
              "none",

            borderRadius:
              "8px",

            fontSize:
              "17px",

            fontWeight:
              "bold",

            cursor:
              "pointer",
          }}
        >
          💾 Save Purchase
        </button>

        {/* =================================================
            BACK
        ================================================= */}

        <button
          type="button"
          onClick={
            goBack
          }
          style={{
            width:
              "100%",

            marginTop:
              "10px",

            padding:
              "13px",

            background:
              "#555",

            color:
              "white",

            border:
              "none",

            borderRadius:
              "8px",

            fontSize:
              "16px",

            cursor:
              "pointer",
          }}
        >
          ⬅️ Back
        </button>
      </div>
    </div>
  );
}

// =====================================================
// INPUT STYLE
// =====================================================

const inputStyle = {
  display:
    "block",

  width:
    "100%",

  boxSizing:
    "border-box",

  padding:
    "12px",

  marginTop:
    "10px",

  marginBottom:
    "15px",

  fontSize:
    "16px",

  border:
    "1px solid #ccc",

  borderRadius:
    "7px",
};

export default Purchase;