import { useState } from "react";

function Expiry({ stock, goBack }) {
  const [search, setSearch] = useState("");

  // =========================
  // TODAY
  // =========================

  const today = new Date();

  // =========================
  // EXPIRY STATUS
  // =========================

  const getExpiryStatus = (expiry) => {
    if (!expiry) {
      return {
        type: "unknown",
        text: "Expiry Date नहीं है",
      };
    }

    const expiryDate = new Date(expiry);

    if (isNaN(expiryDate.getTime())) {
      return {
        type: "unknown",
        text: "Invalid Expiry Date",
      };
    }

    const difference =
      expiryDate.getTime() -
      today.getTime();

    const daysLeft =
      Math.ceil(
        difference /
          (1000 * 60 * 60 * 24)
      );

    if (daysLeft < 0) {
      return {
        type: "expired",
        text:
          "🔴 Expired " +
          Math.abs(daysLeft) +
          " दिन पहले",
        days: daysLeft,
      };
    }

    if (daysLeft <= 30) {
      return {
        type: "warning",
        text:
          "🟡 Expiry in " +
          daysLeft +
          " दिन",
        days: daysLeft,
      };
    }

    return {
      type: "normal",
      text:
        "🟢 " +
        daysLeft +
        " दिन बाकी",
      days: daysLeft,
    };
  };

  // =========================
  // SEARCH
  // =========================

  const filteredStock = (
    Array.isArray(stock)
      ? stock
      : []
  ).filter((item) => {
    const text =
      search.toLowerCase();

    return (
      String(
        item.medicine || ""
      )
        .toLowerCase()
        .includes(text) ||
      String(
        item.company || ""
      )
        .toLowerCase()
        .includes(text) ||
      String(
        item.batch || ""
      )
        .toLowerCase()
        .includes(text)
    );
  });

  // =========================
  // SORT
  // EXPIRED FIRST
  // THEN EXPIRING SOON
  // THEN NORMAL
  // =========================

  const sortedStock =
    [...filteredStock].sort(
      (a, b) => {
        const statusA =
          getExpiryStatus(
            a.expiry
          );

        const statusB =
          getExpiryStatus(
            b.expiry
          );

        if (
          statusA.type ===
          "expired" &&
          statusB.type !==
            "expired"
        ) {
          return -1;
        }

        if (
          statusA.type !==
            "expired" &&
          statusB.type ===
            "expired"
        ) {
          return 1;
        }

        if (
          statusA.days !==
            undefined &&
          statusB.days !==
            undefined
        ) {
          return (
            statusA.days -
            statusB.days
          );
        }

        return 0;
      }
    );

  // =========================
  // COUNTS
  // =========================

  const allStock =
    Array.isArray(stock)
      ? stock
      : [];

  const expiredCount =
    allStock.filter(
      (item) =>
        getExpiryStatus(
          item.expiry
        ).type === "expired"
    ).length;

  const warningCount =
    allStock.filter(
      (item) =>
        getExpiryStatus(
          item.expiry
        ).type === "warning"
    ).length;

  const normalCount =
    allStock.filter(
      (item) =>
        getExpiryStatus(
          item.expiry
        ).type === "normal"
    ).length;

  // =========================
  // SCREEN
  // =========================

  return (
    <div
      style={{
        padding: "20px",
        fontFamily:
          "Arial, sans-serif",
      }}
    >
      <h2>
        📅 Expiry Management
      </h2>

      <button
        onClick={goBack}
        style={{
          padding:
            "8px 15px",
          marginBottom:
            "15px",
        }}
      >
        ⬅️ Back
      </button>

      <hr />

      {/* =========================
          SUMMARY
      ========================= */}

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit, minmax(180px, 1fr))",
          gap: "15px",
          marginBottom:
            "25px",
        }}
      >
        <div
          style={{
            padding: "20px",
            border:
              "2px solid #dc3545",
            borderRadius:
              "10px",
            background:
              "#ffe5e5",
          }}
        >
          <h3>
            🔴 Expired
          </h3>

          <h2>
            {expiredCount}
          </h2>
        </div>

        <div
          style={{
            padding: "20px",
            border:
              "2px solid #ffc107",
            borderRadius:
              "10px",
            background:
              "#fff3cd",
          }}
        >
          <h3>
            🟡 Expiring Soon
          </h3>

          <h2>
            {warningCount}
          </h2>

          <p>
            Within 30 Days
          </p>
        </div>

        <div
          style={{
            padding: "20px",
            border:
              "2px solid #28a745",
            borderRadius:
              "10px",
            background:
              "#e8f8ec",
          }}
        >
          <h3>
            🟢 Normal
          </h3>

          <h2>
            {normalCount}
          </h2>
        </div>
      </div>

      {/* =========================
          SEARCH
      ========================= */}

      <input
        type="text"
        placeholder="🔍 Medicine / Company / Batch Search"
        value={search}
        onChange={(e) =>
          setSearch(
            e.target.value
          )
        }
        style={{
          padding: "10px",
          width: "320px",
          marginBottom:
            "20px",
        }}
      />

      <hr />

      {/* =========================
          TABLE
      ========================= */}

      {sortedStock.length ===
      0 ? (
        <h3>
          📭 कोई Medicine नहीं मिली
        </h3>
      ) : (
        <div
          style={{
            overflowX:
              "auto",
          }}
        >
          <table
            border="1"
            cellPadding="8"
            style={{
              borderCollapse:
                "collapse",
              width: "100%",
              minWidth:
                "800px",
            }}
          >
            <thead>
              <tr>
                <th>
                  Medicine
                </th>

                <th>
                  Company
                </th>

                <th>
                  Batch
                </th>

                <th>
                  Stock
                </th>

                <th>
                  Expiry Date
                </th>

                <th>
                  Status
                </th>
              </tr>
            </thead>

            <tbody>
              {sortedStock.map(
                (
                  item,
                  index
                ) => {
                  const status =
                    getExpiryStatus(
                      item.expiry
                    );

                  let background =
                    "white";

                  if (
                    status.type ===
                    "expired"
                  ) {
                    background =
                      "#ffd6d6";
                  }

                  if (
                    status.type ===
                    "warning"
                  ) {
                    background =
                      "#fff3cd";
                  }

                  return (
                    <tr
                      key={index}
                      style={{
                        background,
                      }}
                    >
                      <td>
                        <b>
                          {
                            item.medicine
                          }
                        </b>
                      </td>

                      <td>
                        {
                          item.company ||
                          "-"
                        }
                      </td>

                      <td>
                        {
                          item.batch ||
                          "-"
                        }
                      </td>

                      <td>
                        {
                          item.quantity ||
                          0
                        }
                      </td>

                      <td>
                        {
                          item.expiry ||
                          "-"
                        }
                      </td>

                      <td>
                        <b>
                          {
                            status.text
                          }
                        </b>
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Expiry;