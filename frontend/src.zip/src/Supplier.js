import { useState } from "react";

function Supplier({ goBack }) {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");

  const saveSupplier = () => {
    if (!name || !mobile) {
      alert("Please fill all fields");
      return;
    }

    alert("Supplier Saved Successfully");

    setName("");
    setMobile("");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>🚚 Supplier</h2>

      <input
        type="text"
        placeholder="Supplier Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <br /><br />

      <input
        type="text"
        placeholder="Mobile Number"
        value={mobile}
        onChange={(e) => setMobile(e.target.value)}
      />

      <br /><br />

      <button onClick={saveSupplier}>
        Save Supplier
      </button>

      <button
        onClick={goBack}
        style={{ marginLeft: "10px" }}
      >
        ⬅️ Back
      </button>
    </div>
  );
}

export default Supplier;