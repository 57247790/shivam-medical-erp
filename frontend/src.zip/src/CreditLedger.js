import { useState } from "react";

function CreditLedger({ goBack }) {
  const [refresh, setRefresh] = useState(0);
  const [selectedCustomer, setSelectedCustomer] =
    useState(null);
  const [search, setSearch] = useState("");

  // =========================
  // BILL HISTORY
  // =========================

  let bills = [];

  try {
    bills = JSON.parse(
      localStorage.getItem("bills") || "[]"
    );
  } catch (error) {
    bills = [];
  }

  // =========================
  // CUSTOMER LIST
  // =========================

  const customerNames = [
    ...new Set(
      bills
        .filter((bill) => bill.credit)
        .map(
          (bill) =>
            String(
              bill.customer || "Unknown Customer"
            ).trim()
        )
    ),
  ];

  // =========================
  // CUSTOMER BILLS
  // =========================

  const getCustomerBills = (customerName) => {
    return bills.filter(
      (bill) =>
        bill.credit &&
        String(
          bill.customer || "Unknown Customer"
        ).trim() === customerName
    );
  };

  // =========================
  // TOTAL CREDIT
  // =========================

  const getCustomerTotal = (customerName) => {
    return getCustomerBills(customerName).reduce(
      (sum, bill) =>
        sum + Number(bill.total || 0),
      0
    );
  };

  // =========================
  // TOTAL PAID
  // =========================

  const getCustomerPaid = (customerName) => {
    return getCustomerBills(customerName).reduce(
      (sum, bill) =>
        sum + Number(bill.paidAmount || 0),
      0
    );
  };

  // =========================
  // PENDING
  // =========================

  const getCustomerPending = (customerName) => {
    const total =
      getCustomerTotal(customerName);

    const paid =
      getCustomerPaid(customerName);

    return Math.max(total - paid, 0);
  };

  // =========================
  // SEARCH
  // =========================

  const filteredCustomers =
    customerNames.filter((customer) =>
      customer
        .toLowerCase()
        .includes(search.toLowerCase())
    );

  // =========================
  // GRAND TOTAL
  // =========================

  const grandCredit =
    filteredCustomers.reduce(
      (sum, customer) =>
        sum + getCustomerTotal(customer),
      0
    );

  const grandPaid =
    filteredCustomers.reduce(
      (sum, customer) =>
        sum + getCustomerPaid(customer),
      0
    );

  const grandPending =
    filteredCustomers.reduce(
      (sum, customer) =>
        sum + getCustomerPending(customer),
      0
    );

  // =========================
  // SELECT CUSTOMER
  // =========================

  const selectedBills =
    selectedCustomer
      ? getCustomerBills(selectedCustomer)
      : [];

  const selectedTotal =
    selectedCustomer
      ? getCustomerTotal(selectedCustomer)
      : 0;

  const selectedPaid =
    selectedCustomer
      ? getCustomerPaid(selectedCustomer)
      : 0;

  const selectedPending =
    selectedCustomer
      ? getCustomerPending(selectedCustomer)
      : 0;

  // =========================
  // RECEIVE PAYMENT
  // =========================

  const receivePayment = (customerName) => {
    const pending =
      getCustomerPending(customerName);

    if (pending <= 0) {
      alert(
        "इस customer की कोई pending udhari नहीं है।"
      );
      return;
    }

    const amount = window.prompt(
      "Customer: " +
        customerName +
        "\nPending Udhari: ₹" +
        pending.toFixed(2) +
        "\n\nPayment Amount:"
    );

    if (amount === null) {
      return;
    }

    const payment = Number(amount);

    if (
      isNaN(payment) ||
      payment <= 0
    ) {
      alert(
        "❌ सही payment amount डालें।"
      );
      return;
    }

    if (payment > pending) {
      alert(
        "❌ Payment pending amount से ज्यादा नहीं हो सकती।"
      );
      return;
    }

    // =========================
    // CURRENT BILLS
    // =========================

    const allBills = [...bills];

    const customerBillIndexes = [];

    allBills.forEach(
      (bill, index) => {
        if (
          bill.credit &&
          String(
            bill.customer ||
              "Unknown Customer"
          ).trim() === customerName &&
          Number(
            bill.pendingAmount || 0
          ) > 0
        ) {
          customerBillIndexes.push(index);
        }
      }
    );

    let remainingPayment = payment;

    // सबसे पुराने bill से payment adjust
    for (
      let i = 0;
      i < customerBillIndexes.length;
      i++
    ) {
      if (remainingPayment <= 0) {
        break;
      }

      const billIndex =
        customerBillIndexes[i];

      const bill =
        allBills[billIndex];

      const billPending =
        Number(
          bill.pendingAmount || 0
        );

      const paymentForBill =
        Math.min(
          remainingPayment,
          billPending
        );

      allBills[billIndex] = {
        ...bill,

        paidAmount:
          Number(
            bill.paidAmount || 0
          ) + paymentForBill,

        pendingAmount:
          billPending -
          paymentForBill,
      };

      remainingPayment -=
        paymentForBill;
    }

    // =========================
    // SAVE BILLS
    // =========================

    localStorage.setItem(
      "bills",
      JSON.stringify(allBills)
    );

    // =========================
    // PAYMENT HISTORY
    // =========================

    let paymentHistory = [];

    try {
      paymentHistory = JSON.parse(
        localStorage.getItem(
          "creditPayments"
        ) || "[]"
      );
    } catch (error) {
      paymentHistory = [];
    }

    paymentHistory.push({
      customer: customerName,
      amount: payment,
      date:
        new Date().toLocaleDateString(),
      time:
        new Date().toLocaleTimeString(),
    });

    localStorage.setItem(
      "creditPayments",
      JSON.stringify(paymentHistory)
    );

    alert(
      "✅ Payment Successfully Saved\n\n" +
        "Customer: " +
        customerName +
        "\n" +
        "Payment: ₹" +
        payment.toFixed(2)
    );

    setRefresh(refresh + 1);
  };

  // =========================
  // SCREEN
  // =========================

  return (
    <div
      style={{
        padding: "20px",
        fontFamily:
          "Arial, sans-serif",
      }}
    >
      {/* =========================
          BACK
      ========================= */}

      <button
        onClick={goBack}
        style={{
          padding: "12px 25px",
          fontSize: "16px",
          cursor: "pointer",
          marginBottom: "15px",
        }}
      >
        ⬅️ Back to Dashboard
      </button>

      <h2>
        💳 Customer Udhari Ledger
      </h2>

      <hr />

      {/* =========================
          SEARCH
      ========================= */}

      <input
        type="text"
        placeholder="🔍 Search Customer"
        value={search}
        onChange={(e) =>
          setSearch(e.target.value)
        }
        style={{
          padding: "10px",
          width: "280px",
          fontSize: "16px",
        }}
      />

      <br />
      <br />

      {/* =========================
          SUMMARY
      ========================= */}

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit, minmax(190px, 1fr))",
          gap: "15px",
          marginBottom: "25px",
        }}
      >
        <div
          style={{
            padding: "15px",
            border: "1px solid #ccc",
            borderRadius: "8px",
          }}
        >
          <h3>
            👥 Customers
          </h3>

          <h2>
            {filteredCustomers.length}
          </h2>
        </div>

        <div
          style={{
            padding: "15px",
            border: "1px solid #ccc",
            borderRadius: "8px",
          }}
        >
          <h3>
            💰 Total Udhari
          </h3>

          <h2>
            ₹{grandCredit.toFixed(2)}
          </h2>
        </div>

        <div
          style={{
            padding: "15px",
            border: "1px solid #ccc",
            borderRadius: "8px",
            background: "#e8f5e9",
          }}
        >
          <h3>
            ✅ Total Paid
          </h3>

          <h2
            style={{
              color: "green",
            }}
          >
            ₹{grandPaid.toFixed(2)}
          </h2>
        </div>

        <div
          style={{
            padding: "15px",
            border: "1px solid #ccc",
            borderRadius: "8px",
            background:
              grandPending > 0
                ? "#ffe5e5"
                : "#e8f5e9",
          }}
        >
          <h3>
            🔴 Total Pending
          </h3>

          <h2
            style={{
              color:
                grandPending > 0
                  ? "red"
                  : "green",
            }}
          >
            ₹{grandPending.toFixed(2)}
          </h2>
        </div>
      </div>

      <hr />

      {/* =========================
          CUSTOMER TABLE
      ========================= */}

      {filteredCustomers.length ===
      0 ? (
        <h3>
          अभी कोई Udhari Customer नहीं है।
        </h3>
      ) : (
        <div
          style={{
            overflowX: "auto",
          }}
        >
          <table
            border="1"
            cellPadding="10"
            style={{
              borderCollapse:
                "collapse",
              width: "100%",
              minWidth: "800px",
            }}
          >
            <thead>
              <tr>
                <th>
                  Customer
                </th>

                <th>
                  Total Udhari
                </th>

                <th>
                  Paid
                </th>

                <th>
                  Pending
                </th>

                <th>
                  Action
                </th>
              </tr>
            </thead>

            <tbody>
              {filteredCustomers.map(
                (
                  customer,
                  index
                ) => {
                  const total =
                    getCustomerTotal(
                      customer
                    );

                  const paid =
                    getCustomerPaid(
                      customer
                    );

                  const pending =
                    getCustomerPending(
                      customer
                    );

                  return (
                    <tr
                      key={index}
                    >
                      <td>
                        <button
                          onClick={() =>
                            setSelectedCustomer(
                              customer
                            )
                          }
                          style={{
                            border:
                              "none",
                            background:
                              "none",
                            color:
                              "blue",
                            cursor:
                              "pointer",
                            fontWeight:
                              "bold",
                            fontSize:
                              "16px",
                          }}
                        >
                          {customer}
                        </button>
                      </td>

                      <td>
                        ₹
                        {total.toFixed(
                          2
                        )}
                      </td>

                      <td
                        style={{
                          color:
                            "green",
                          fontWeight:
                            "bold",
                        }}
                      >
                        ₹
                        {paid.toFixed(
                          2
                        )}
                      </td>

                      <td
                        style={{
                          color:
                            pending >
                            0
                              ? "red"
                              : "green",
                          fontWeight:
                            "bold",
                        }}
                      >
                        ₹
                        {pending.toFixed(
                          2
                        )}
                      </td>

                      <td>
                        {pending >
                        0 ? (
                          <button
                            onClick={() =>
                              receivePayment(
                                customer
                              )
                            }
                          >
                            💰 Payment जमा करें
                          </button>
                        ) : (
                          <span>
                            ✅ Paid
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* =========================
          SELECTED CUSTOMER LEDGER
      ========================= */}

      {selectedCustomer && (
        <div
          style={{
            marginTop: "30px",
            padding: "20px",
            border:
              "2px solid #333",
            borderRadius: "10px",
          }}
        >
          <h2>
            📋 Customer Ledger
          </h2>

          <h3>
            👤 {selectedCustomer}
          </h3>

          <hr />

          <h3>
            💰 Total Udhari: ₹
            {selectedTotal.toFixed(2)}
          </h3>

          <h3
            style={{
              color: "green",
            }}
          >
            ✅ Paid: ₹
            {selectedPaid.toFixed(2)}
          </h3>

          <h3
            style={{
              color:
                selectedPending > 0
                  ? "red"
                  : "green",
            }}
          >
            🔴 Pending: ₹
            {selectedPending.toFixed(2)}
          </h3>

          <hr />

          {/* =========================
              BILL HISTORY
          ========================= */}

          <h3>
            🧾 Udhari Bill History
          </h3>

          {selectedBills.length ===
          0 ? (
            <p>
              No Bill Found
            </p>
          ) : (
            <div
              style={{
                overflowX:
                  "auto",
              }}
            >
              <table
                border="1"
                cellPadding="8"
                style={{
                  borderCollapse:
                    "collapse",
                  width: "100%",
                  minWidth:
                    "750px",
                }}
              >
                <thead>
                  <tr>
                    <th>
                      Bill No
                    </th>

                    <th>
                      Date
                    </th>

                    <th>
                      Total
                    </th>

                    <th>
                      Paid
                    </th>

                    <th>
                      Pending
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {[...selectedBills]
                    .reverse()
                    .map(
                      (
                        bill,
                        index
                      ) => (
                        <tr
                          key={index}
                        >
                          <td>
                            {
                              bill.billNumber
                            }
                          </td>

                          <td>
                            {
                              bill.date
                            }
                            <br />
                            {
                              bill.time
                            }
                          </td>

                          <td>
                            ₹
                            {Number(
                              bill.total ||
                                0
                            ).toFixed(
                              2
                            )}
                          </td>

                          <td
                            style={{
                              color:
                                "green",
                            }}
                          >
                            ₹
                            {Number(
                              bill.paidAmount ||
                                0
                            ).toFixed(
                              2
                            )}
                          </td>

                          <td
                            style={{
                              color:
                                Number(
                                  bill.pendingAmount ||
                                    0
                                ) >
                                0
                                  ? "red"
                                  : "green",
                            }}
                          >
                            ₹
                            {Number(
                              bill.pendingAmount ||
                                0
                            ).toFixed(
                              2
                            )}
                          </td>
                        </tr>
                      )
                    )}
                </tbody>
              </table>
            </div>
          )}

          <hr />

          {/* =========================
              PAYMENT HISTORY
          ========================= */}

          <h3>
            💵 Payment History
          </h3>

          {(() => {
            let creditPayments = [];

            try {
              creditPayments =
                JSON.parse(
                  localStorage.getItem(
                    "creditPayments"
                  ) || "[]"
                );
            } catch (error) {
              creditPayments = [];
            }

            const customerPayments =
              creditPayments
                .filter(
                  (payment) =>
                    payment.customer ===
                    selectedCustomer
                )
                .reverse();

            if (
              customerPayments.length ===
              0
            ) {
              return (
                <p>
                  अभी कोई payment नहीं है।
                </p>
              );
            }

            return (
              <div
                style={{
                  overflowX:
                    "auto",
                }}
              >
                <table
                  border="1"
                  cellPadding="8"
                  style={{
                    borderCollapse:
                      "collapse",
                    width: "100%",
                  }}
                >
                  <thead>
                    <tr>
                      <th>
                        Amount
                      </th>

                      <th>
                        Date
                      </th>

                      <th>
                        Time
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {customerPayments.map(
                      (
                        payment,
                        index
                      ) => (
                        <tr
                          key={index}
                        >
                          <td
                            style={{
                              color:
                                "green",
                              fontWeight:
                                "bold",
                            }}
                          >
                            ₹
                            {Number(
                              payment.amount ||
                                0
                            ).toFixed(
                              2
                            )}
                          </td>

                          <td>
                            {
                              payment.date
                            }
                          </td>

                          <td>
                            {
                              payment.time
                            }
                          </td>
                        </tr>
                      )
                    )}
                  </tbody>
                </table>
              </div>
            );
          })()}

          <br />

          <button
            onClick={() =>
              setSelectedCustomer(null)
            }
          >
            ❌ Close Ledger
          </button>
        </div>
      )}
    </div>
  );
}

export default CreditLedger;