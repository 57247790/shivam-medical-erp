
import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

function Billing({ stock, setStock, goBack }) {
  const currentStock = Array.isArray(stock) ? stock : [];

  // =====================================================
  // REFS
  // =====================================================

  const barcodeRef = useRef(null);
  const qtyRef = useRef(null);

  // =====================================================
  // CUSTOMER
  // =====================================================

  const [customer, setCustomer] = useState("");
  const [mobile, setMobile] = useState("");

  // =====================================================
  // MEDICINE INPUT
  // =====================================================

  const [barcode, setBarcode] = useState("");
  const [medicine, setMedicine] = useState("");
  const [quantity, setQuantity] = useState("");

  // =====================================================
  // CART
  // =====================================================

  const [cart, setCart] = useState([]);

  // =====================================================
  // PAYMENT
  // =====================================================

  const [paymentType, setPaymentType] =
    useState("cash");

  const [paidAmount, setPaidAmount] =
    useState("");

  // =====================================================
  // CUSTOMER SUGGESTION
  // =====================================================

  const [showCustomerSuggestions, setShowCustomerSuggestions] =
    useState(false);

  // =====================================================
  // LAST BILL
  // =====================================================

  const [lastBill, setLastBill] = useState(null);

  // =====================================================
  // REFRESH
  // =====================================================

  const [refresh, setRefresh] = useState(0);

  // =====================================================
  // GET ARRAY
  // =====================================================

  const getArray = (key) => {
    try {
      const saved = JSON.parse(
        localStorage.getItem(key) || "[]"
      );

      return Array.isArray(saved)
        ? saved
        : [];
    } catch {
      return [];
    }
  };

  // =====================================================
  // BILL HISTORY
  // =====================================================

  const bills = useMemo(() => {
    return getArray("bills");
  }, [refresh, lastBill]);

  // =====================================================
  // BILL NUMBER
  // =====================================================

  const getNextBillNumber = () => {
    let lastNumber = 0;

    try {
      lastNumber = Number(
        localStorage.getItem(
          "lastBillNumber"
        ) || 0
      );
    } catch {
      lastNumber = 0;
    }

    const nextNumber =
      lastNumber + 1;

    localStorage.setItem(
      "lastBillNumber",
      String(nextNumber)
    );

    return (
      "SHIVAM-" +
      String(nextNumber).padStart(
        6,
        "0"
      )
    );
  };

  // =====================================================
  // DATE
  // =====================================================

  const getDate = () => {
    const now = new Date();

    return (
      now.getFullYear() +
      "-" +
      String(
        now.getMonth() + 1
      ).padStart(2, "0") +
      "-" +
      String(
        now.getDate()
      ).padStart(2, "0")
    );
  };

  // =====================================================
  // TIME
  // =====================================================

  const getTime = () => {
    return new Date().toLocaleTimeString(
      "en-IN",
      {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }
    );
  };

  // =====================================================
  // CUSTOMER LIST
  // =====================================================

  const customerList = useMemo(() => {
    const map = {};

    bills.forEach((bill) => {
      const name = String(
        bill.customer || ""
      ).trim();

      if (
        !name ||
        name === "Cash Customer"
      ) {
        return;
      }

      const key =
        name.toLowerCase();

      if (!map[key]) {
        map[key] = {
          customer: name,
          mobile:
            bill.mobile || "",
        };
      }
    });

    return Object.values(map);
  }, [bills]);

  // =====================================================
  // FILTER CUSTOMER
  // =====================================================

  const filteredCustomers =
    customer.trim()
      ? customerList.filter(
          (item) =>
            item.customer
              .toLowerCase()
              .includes(
                customer
                  .trim()
                  .toLowerCase()
              )
        )
      : [];

  // =====================================================
  // SELECT CUSTOMER
  // =====================================================

  const selectCustomer = (
    item
  ) => {
    setCustomer(
      item.customer
    );

    setMobile(
      item.mobile || ""
    );

    setShowCustomerSuggestions(
      false
    );
  };

  // =====================================================
  // CUSTOMER OLD BILLS
  // =====================================================

  const customerBills =
    useMemo(() => {
      if (!customer.trim()) {
        return [];
      }

      return bills
        .filter(
          (bill) =>
            String(
              bill.customer || ""
            )
              .trim()
              .toLowerCase() ===
            customer
              .trim()
              .toLowerCase()
        )
        .slice(0, 8);
    }, [
      bills,
      customer,
    ]);

  // =====================================================
  // SELECTED MEDICINE
  // =====================================================

  const selectedItem =
    currentStock.find(
      (item) =>
        String(
          item.medicine || ""
        )
          .trim()
          .toLowerCase() ===
        medicine
          .trim()
          .toLowerCase()
    );

  // =====================================================
  // SALE RATE
  // =====================================================

  const saleRate =
    selectedItem
      ? Number(
          selectedItem.saleRate ||
            selectedItem.mrp ||
            0
        )
      : 0;

  // =====================================================
  // CART TOTAL
  // =====================================================

  const totalAmount =
    cart.reduce(
      (sum, item) =>
        sum +
        Number(
          item.amount || 0
        ),
      0
    );

  // =====================================================
  // PAID
  // =====================================================

  const calculatedPaid =
    paymentType === "cash"
      ? totalAmount
      : Number(
          paidAmount || 0
        );

  // =====================================================
  // PENDING
  // =====================================================

  const pendingAmount =
    Math.max(
      totalAmount -
        calculatedPaid,
      0
    );

  // =====================================================
  // CART PROFIT
  // =====================================================

  const totalProfit =
    cart.reduce(
      (sum, item) =>
        sum +
        Number(
          item.profit || 0
        ),
      0
    );

  // =====================================================
  // BARCODE SEARCH
  // =====================================================

  const searchBarcode = () => {
    const cleanBarcode =
      barcode.trim();

    if (!cleanBarcode) {
      alert(
        "⚠️ पहले Barcode Scan करें।"
      );

      barcodeRef.current?.focus();

      return;
    }

    const found =
      currentStock.find(
        (item) =>
          String(
            item.barcode || ""
          )
            .trim()
            .toLowerCase() ===
          cleanBarcode
            .toLowerCase()
      );

    if (!found) {
      setMedicine("");

      alert(
        "❌ Barcode नहीं मिला!\n\n" +
          "पहले Purchase Entry में Barcode Save करें।"
      );

      barcodeRef.current?.focus();

      return;
    }

    const stockQty =
      Number(
        found.quantity || 0
      );

    if (stockQty <= 0) {
      alert(
        "⚠️ इस Medicine का Stock खत्म है।\n\n" +
          (found.medicine ||
            "")
      );

      barcodeRef.current?.focus();

      return;
    }

    // Medicine select
    setMedicine(
      found.medicine || ""
    );

    // Quantity खाली
    setQuantity("");

    // सबसे जरूरी:
    // Barcode डालते ही Qty पर cursor
    setTimeout(() => {
      qtyRef.current?.focus();
      qtyRef.current?.select();
    }, 50);
  };

  // =====================================================
  // BARCODE ENTER
  // =====================================================

  const handleBarcodeKeyDown = (
    e
  ) => {
    if (e.key === "Enter") {
      e.preventDefault();

      searchBarcode();
    }
  };

  // =====================================================
  // ADD MEDICINE TO CART
  // =====================================================

  const addMedicineToCart = () => {
    if (!medicine.trim()) {
      alert(
        "⚠️ पहले Barcode Scan करके Medicine Select करें।"
      );

      barcodeRef.current?.focus();

      return;
    }

    if (!quantity) {
      alert(
        "⚠️ Quantity डालें।"
      );

      qtyRef.current?.focus();

      return;
    }

    const qty =
      Number(quantity);

    if (
      Number.isNaN(qty) ||
      qty <= 0
    ) {
      alert(
        "⚠️ Quantity सही डालें।"
      );

      qtyRef.current?.focus();

      return;
    }

    const index =
      currentStock.findIndex(
        (item) =>
          String(
            item.medicine || ""
          )
            .trim()
            .toLowerCase() ===
          medicine
            .trim()
            .toLowerCase()
      );

    if (index === -1) {
      alert(
        "❌ Medicine Stock में नहीं मिली।"
      );

      barcodeRef.current?.focus();

      return;
    }

    const item =
      currentStock[index];

    const availableQty =
      Number(
        item.quantity || 0
      );

    // ===================================================
    // CHECK EXISTING CART QTY
    // ===================================================

    const alreadyAdded =
      cart.find(
        (cartItem) =>
          String(
            cartItem.medicine
          )
            .trim()
            .toLowerCase() ===
          String(
            item.medicine
          )
            .trim()
            .toLowerCase()
      );

    const alreadyQty =
      alreadyAdded
        ? Number(
            alreadyAdded.quantity ||
              0
          )
        : 0;

    if (
      qty + alreadyQty >
      availableQty
    ) {
      alert(
        "❌ Insufficient Stock!\n\n" +
          "Available: " +
          availableQty +
          "\nAlready Added: " +
          alreadyQty +
          "\nNew Qty: " +
          qty
      );

      qtyRef.current?.focus();

      return;
    }

    // ===================================================
    // RATE
    // ===================================================

    const finalSaleRate =
      Number(
        item.saleRate ||
          item.mrp ||
          0
      );

    const finalPurchaseRate =
      Number(
        item.purchaseRate ||
          item.rate ||
          0
      );

    if (
      finalSaleRate <= 0
    ) {
      alert(
        "⚠️ Sale Rate/MRP सही नहीं है।"
      );

      return;
    }

    // ===================================================
    // AMOUNT
    // ===================================================

    const amount =
      qty *
      finalSaleRate;

    const purchaseAmount =
      qty *
      finalPurchaseRate;

    const profit =
      amount -
      purchaseAmount;

    // ===================================================
    // IF MEDICINE ALREADY IN CART
    // ===================================================

    if (alreadyAdded) {
      setCart((oldCart) =>
        oldCart.map(
          (cartItem) => {
            if (
              String(
                cartItem.medicine
              )
                .trim()
                .toLowerCase() !==
              String(
                item.medicine
              )
                .trim()
                .toLowerCase()
            ) {
              return cartItem;
            }

            const newQty =
              Number(
                cartItem.quantity
              ) + qty;

            const newAmount =
              newQty *
              Number(
                cartItem.saleRate
              );

            const newPurchase =
              newQty *
              Number(
                cartItem.purchaseRate
              );

            return {
              ...cartItem,

              quantity:
                newQty,

              amount:
                newAmount,

              saleAmount:
                newAmount,

              purchaseAmount:
                newPurchase,

              profit:
                newAmount -
                newPurchase,
            };
          }
        )
      );
    } else {
      // =================================================
      // NEW MEDICINE
      // =================================================

      const cartItem = {
        cartId:
          Date.now() +
          Math.random(),

        medicine:
          item.medicine ||
          "",

        company:
          item.company ||
          "",

        batch:
          item.batch ||
          "",

        barcode:
          item.barcode ||
          "",

        quantity:
          qty,

        purchaseRate:
          finalPurchaseRate,

        saleRate:
          finalSaleRate,

        mrp:
          Number(
            item.mrp || 0
          ),

        purchaseAmount:
          purchaseAmount,

        saleAmount:
          amount,

        amount:
          amount,

        profit:
          profit,

        stockIndex:
          index,
      };

      setCart((oldCart) => [
        ...oldCart,
        cartItem,
      ]);
    }

    // ===================================================
    // RESET FOR NEXT MEDICINE
    // ===================================================

    setMedicine("");
    setQuantity("");
    setBarcode("");

    // वापस Barcode पर cursor
    setTimeout(() => {
      barcodeRef.current?.focus();
    }, 50);
  };

  // =====================================================
  // QTY ENTER
  // =====================================================

  const handleQtyKeyDown = (
    e
  ) => {
    if (e.key === "Enter") {
      e.preventDefault();

      addMedicineToCart();
    }
  };

  // =====================================================
  // REMOVE CART ITEM
  // =====================================================

  const removeCartItem = (
    cartId
  ) => {
    setCart((oldCart) =>
      oldCart.filter(
        (item) =>
          item.cartId !==
          cartId
      )
    );

    setTimeout(() => {
      barcodeRef.current?.focus();
    }, 50);
  };

  // =====================================================
  // CLEAR CART
  // =====================================================

  const clearCart = () => {
    if (
      cart.length === 0
    ) {
      return;
    }

    if (
      !window.confirm(
        "क्या पूरा Bill Clear करना है?"
      )
    ) {
      return;
    }

    setCart([]);

    setMedicine("");
    setQuantity("");
    setBarcode("");
    setPaidAmount("");

    setTimeout(() => {
      barcodeRef.current?.focus();
    }, 50);
  };

  // =====================================================
  // PAYMENT TYPE
  // =====================================================

  const changePaymentType = (
    type
  ) => {
    setPaymentType(type);

    if (type === "cash") {
      setPaidAmount(
        totalAmount
          ? String(
              totalAmount
            )
          : ""
      );
    } else {
      setPaidAmount("");
    }
  };

  // =====================================================
  // SAVE BILL
  // =====================================================

  const saveBill = () => {
    if (
      cart.length === 0
    ) {
      alert(
        "⚠️ पहले कम से कम 1 Medicine Add करें।"
      );

      barcodeRef.current?.focus();

      return;
    }

    // ===================================================
    // PAYMENT
    // ===================================================

    let finalPaidAmount =
      0;

    if (
      paymentType === "cash"
    ) {
      finalPaidAmount =
        totalAmount;
    } else {
      finalPaidAmount =
        Number(
          paidAmount || 0
        );

      if (
        Number.isNaN(
          finalPaidAmount
        ) ||
        finalPaidAmount < 0
      ) {
        alert(
          "⚠️ Paid Amount सही डालें।"
        );

        return;
      }

      if (
        finalPaidAmount >
        totalAmount
      ) {
        alert(
          "⚠️ Paid Amount Bill Total से ज्यादा नहीं हो सकता।"
        );

        return;
      }
    }

    // ===================================================
    // CUSTOMER
    // ===================================================

    const finalCustomer =
      customer.trim() ||
      "Cash Customer";

    const finalMobile =
      mobile.trim();

    // ===================================================
    // DATE TIME
    // ===================================================

    const date =
      getDate();

    const time =
      getTime();

    // ===================================================
    // BILL NUMBER
    // ===================================================

    const billNumber =
      getNextBillNumber();

    // ===================================================
    // FINAL PENDING
    // ===================================================

    const finalPending =
      Math.max(
        totalAmount -
          finalPaidAmount,
        0
      );

    // ===================================================
    // UPDATE STOCK
    // ===================================================

    const newStock =
      [...currentStock];

    cart.forEach(
      (cartItem) => {
        const stockIndex =
          newStock.findIndex(
            (stockItem) =>
              String(
                stockItem.medicine ||
                  ""
              )
                .trim()
                .toLowerCase() ===
              String(
                cartItem.medicine ||
                  ""
              )
                .trim()
                .toLowerCase()
          );

        if (
          stockIndex === -1
        ) {
          return;
        }

        const available =
          Number(
            newStock[
              stockIndex
            ].quantity || 0
          );

        newStock[
          stockIndex
        ] = {
          ...newStock[
            stockIndex
          ],

          quantity:
            available -
            Number(
              cartItem.quantity ||
                0
            ),
        };
      }
    );

    // ===================================================
    // SAVE STOCK
    // ===================================================

    setStock(newStock);

    localStorage.setItem(
      "stock",
      JSON.stringify(
        newStock
      )
    );

    // ===================================================
    // BILL ITEMS
    // ===================================================

    const billItems =
      cart.map(
        (item) => ({
          medicine:
            item.medicine,

          company:
            item.company,

          batch:
            item.batch,

          barcode:
            item.barcode,

          quantity:
            Number(
              item.quantity
            ),

          purchaseRate:
            Number(
              item.purchaseRate
            ),

          saleRate:
            Number(
              item.saleRate
            ),

          mrp:
            Number(
              item.mrp
            ),

          purchaseAmount:
            Number(
              item.purchaseAmount
            ),

          saleAmount:
            Number(
              item.saleAmount
            ),

          amount:
            Number(
              item.amount
            ),

          profit:
            Number(
              item.profit
            ),
        })
      );

    // ===================================================
    // BILL OBJECT
    // ===================================================

    const bill = {
      id:
        Date.now(),

      billNumber,

      customer:
        finalCustomer,

      mobile:
        finalMobile,

      // MULTIPLE MEDICINES
      items:
        billItems,

      // Compatibility:
      // First medicine information
      medicine:
        billItems[0]
          ?.medicine || "",

      company:
        billItems[0]
          ?.company || "",

      barcode:
        billItems[0]
          ?.barcode || "",

      quantity:
        billItems.reduce(
          (sum, item) =>
            sum +
            Number(
              item.quantity || 0
            ),
          0
        ),

      total:
        totalAmount,

      amount:
        totalAmount,

      saleAmount:
        totalAmount,

      purchaseAmount:
        cart.reduce(
          (sum, item) =>
            sum +
            Number(
              item.purchaseAmount ||
                0
            ),
          0
        ),

      profit:
        totalProfit,

      paymentType:
        paymentType,

      paymentMode:
        paymentType ===
        "cash"
          ? "नकद"
          : "उधारी",

      paidAmount:
        finalPaidAmount,

      pendingAmount:
        finalPending,

      udhari:
        finalPending,

      date:
        date,

      time:
        time,

      createdAt:
        Date.now(),
    };

    // ===================================================
    // SAVE BILLS
    // ===================================================

    let existingBills =
      getArray("bills");

    localStorage.setItem(
      "bills",
      JSON.stringify([
        ...existingBills,
        bill,
      ])
    );

    // ===================================================
    // SALES
    // ===================================================

    let sales =
      getArray("sales");

    billItems.forEach(
      (item, index) => {
        const saleRecord = {
          id:
            Date.now() +
            index +
            1,

          billNumber,

          customer:
            finalCustomer,

          mobile:
            finalMobile,

          medicine:
            item.medicine,

          company:
            item.company,

          batch:
            item.batch,

          barcode:
            item.barcode,

          quantity:
            item.quantity,

          purchaseRate:
            item.purchaseRate,

          saleRate:
            item.saleRate,

          purchaseAmount:
            item.purchaseAmount,

          saleAmount:
            item.saleAmount,

          amount:
            item.amount,

          paymentType:
            paymentType,

          paymentMode:
            paymentType ===
            "cash"
              ? "नकद"
              : "उधारी",

          // पूरे bill का payment
          // पहले item में रखा जाएगा
          paidAmount:
            index === 0
              ? finalPaidAmount
              : 0,

          pendingAmount:
            index === 0
              ? finalPending
              : 0,

          udhari:
            index === 0
              ? finalPending
              : 0,

          profit:
            item.profit,

          date:
            date,

          time:
            time,

          createdAt:
            Date.now() +
            index,
        };

        sales.push(
          saleRecord
        );
      }
    );

    localStorage.setItem(
      "sales",
      JSON.stringify(
        sales
      )
    );

    // ===================================================
    // LAST BILL
    // ===================================================

    setLastBill(bill);

    // ===================================================
    // SUCCESS
    // ===================================================

    alert(
      "✅ BILL SAVED SUCCESSFULLY\n\n" +
        "🧾 Bill No.: " +
        billNumber +
        "\n" +
        "👤 Customer: " +
        finalCustomer +
        "\n" +
        "💊 Medicines: " +
        billItems.length +
        "\n" +
        "💰 Total: ₹" +
        totalAmount.toFixed(
          2
        ) +
        "\n" +
        "💵 Paid: ₹" +
        finalPaidAmount.toFixed(
          2
        ) +
        "\n" +
        "⚠️ Pending: ₹" +
        finalPending.toFixed(
          2
        )
    );

    // ===================================================
    // RESET BILL
    // ===================================================

    setCart([]);

    setCustomer("");
    setMobile("");

    setBarcode("");
    setMedicine("");
    setQuantity("");

    setPaymentType(
      "cash"
    );

    setPaidAmount("");

    setShowCustomerSuggestions(
      false
    );

    setRefresh(
      (value) =>
        value + 1
    );

    // Barcode cursor
    setTimeout(() => {
      barcodeRef.current?.focus();
    }, 100);
  };

  // =====================================================
  // PRINT BILL
  // =====================================================

  const printBill = (
    billData = lastBill
  ) => {
    if (!billData) {
      alert(
        "⚠️ पहले Bill Generate & Save करें।"
      );

      return;
    }

    const printWindow =
      window.open(
        "",
        "_blank",
        "width=420,height=700"
      );

    if (!printWindow) {
      alert(
        "⚠️ Print Window नहीं खुली। Browser Popup Allow करें।"
      );

      return;
    }
// =====================================================
// WHATSAPP SHARE BILL
// =====================================================

const shareBillWhatsApp = (
  billData = lastBill
) => {
  if (!billData) {
    alert(
      "⚠️ पहले Bill Generate & Save करें।"
    );
    return;
  }

  const items =
    Array.isArray(billData.items)
      ? billData.items
      : [];

  let message =
    `🧾 *SHIVAM MEDICAL STORE*\n` +
    `Hatuniya\n\n` +
    `Bill No: ${billData.billNumber || "-"}\n` +
    `Date: ${billData.date || "-"} ${billData.time || ""}\n` +
    `Customer: ${billData.customer || "Cash Customer"}\n`;

  if (billData.mobile) {
    message +=
      `Mobile: ${billData.mobile}\n`;
  }

  message +=
    `\n━━━━━━━━━━━━━━━━━━\n` +
    `💊 *MEDICINES*\n` +
    `━━━━━━━━━━━━━━━━━━\n`;

  if (items.length > 0) {
    items.forEach((item, index) => {
      message +=
        `${index + 1}. ${item.medicine || "-"}\n` +
        `   Qty: ${Number(item.quantity || 0)} × ₹${Number(
          item.saleRate || 0
        ).toFixed(2)}\n` +
        `   Amount: ₹${Number(
          item.amount || 0
        ).toFixed(2)}\n\n`;
    });
  } else {
    message +=
      `${billData.medicine || "-"}\n` +
      `Qty: ${billData.quantity || 0}\n` +
      `Amount: ₹${Number(
        billData.total || 0
      ).toFixed(2)}\n\n`;
  }

  message +=
    `━━━━━━━━━━━━━━━━━━\n` +
    `💰 *TOTAL: ₹${Number(
      billData.total || 0
    ).toFixed(2)}*\n` +
    `💵 Paid: ₹${Number(
      billData.paidAmount || 0
    ).toFixed(2)}\n` +
    `🔴 Udhari: ₹${Number(
      billData.pendingAmount || 0
    ).toFixed(2)}\n` +
    `━━━━━━━━━━━━━━━━━━\n\n` +
    `धन्यवाद 🙏\n` +
    `SHIVAM MEDICAL STORE\n` +
    `Hatuniya`;

  const encodedMessage =
    encodeURIComponent(message);

  const mobile =
    String(
      billData.mobile || ""
    ).replace(/\D/g, "");

  let whatsappUrl;

  if (mobile.length >= 10) {
    whatsappUrl =
      `https://wa.me/${mobile}?text=${encodedMessage}`;
  } else {
    whatsappUrl =
      `https://wa.me/?text=${encodedMessage}`;
  }

  window.open(
    whatsappUrl,
    "_blank"
  );
};
    const money = (
      value
    ) =>
      Number(
        value || 0
      ).toFixed(2);

    const items =
      Array.isArray(
        billData.items
      )
        ? billData.items
        : [
            {
              medicine:
                billData.medicine ||
                "-",

              quantity:
                billData.quantity ||
                0,

              saleRate:
                billData.saleRate ||
                0,

              amount:
                billData.saleAmount ||
                billData.total ||
                0,
            },
          ];

    printWindow.document.write(`
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>
${billData.billNumber || "Shivam Bill"}
</title>

<style>

* {
  box-sizing: border-box;
}

html,
body {
  margin: 0;
  padding: 0;
  background: white;
  color: black;
  font-family: Arial, sans-serif;
}

body {
  font-size: 10px;
}

.bill {
  width: 72mm;
  margin: auto;
  padding: 4mm 3mm;
}

.center {
  text-align: center;
}

.shopName {
  font-size: 17px;
  font-weight: bold;
}

.subTitle {
  font-size: 10px;
  margin-top: 2px;
}

.small {
  font-size: 9px;
}

.line {
  border-top: 1px dashed black;
  margin: 6px 0;
}

.row {
  display: flex;
  justify-content: space-between;
  gap: 5px;
  margin: 2px 0;
}

.right {
  text-align: right;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  padding: 3px 1px;
  text-align: left;
  font-size: 9px;
}

th {
  border-bottom: 1px solid black;
}

td:last-child,
th:last-child {
  text-align: right;
}

.medicine {
  font-weight: bold;
}

.total {
  font-size: 14px;
  font-weight: bold;
}

.payment {
  font-weight: bold;
}

.footer {
  text-align: center;
  margin-top: 8px;
  font-size: 10px;
}

@media print {

  @page {
    size: 80mm auto;
    margin: 0;
  }

  html,
  body {
    width: 80mm;
  }

  .bill {
    width: 72mm;
  }

}

</style>

</head>

<body>

<div class="bill">

<div class="center">

<div class="shopName">
SHIVAM MEDICAL STORE
</div>

<div class="subTitle">
Shivam Medical ERP
</div>

<div class="small">
Hatuniya
</div>

</div>

<div class="line"></div>

<div class="row">
<span><b>Bill No.</b></span>
<span>
${billData.billNumber || "-"}
</span>
</div>

<div class="row">
<span><b>Date</b></span>
<span>
${billData.date || "-"}
</span>
</div>

<div class="row">
<span><b>Time</b></span>
<span>
${billData.time || "-"}
</span>
</div>

<div class="row">
<span><b>Customer</b></span>
<span class="right">
${billData.customer || "Cash Customer"}
</span>
</div>

${
  billData.mobile
    ? `
<div class="row">
<span><b>Mobile</b></span>
<span>
${billData.mobile}
</span>
</div>
`
    : ""
}

<div class="line"></div>

<table>

<thead>

<tr>

<th>Medicine</th>
<th>Qty</th>
<th>Rate</th>
<th>Amount</th>

</tr>

</thead>

<tbody>

${items
  .map(
    (item) => `
<tr>

<td class="medicine">
${item.medicine || "-"}
</td>

<td>
${item.quantity || 0}
</td>

<td>
₹${money(
      item.saleRate
    )}
</td>

<td>
₹${money(
      item.amount
    )}
</td>

</tr>
`
  )
  .join("")}

</tbody>

</table>

<div class="line"></div>

<div class="row">

<span class="total">
TOTAL
</span>

<span class="total">
₹${money(
      billData.total
    )}
</span>

</div>

<div class="row">

<span>
Payment
</span>

<span class="payment">
${
  billData.paymentMode ||
  "नकद"
}
</span>

</div>

<div class="row">

<span>
Paid
</span>

<span>
₹${money(
      billData.paidAmount
    )}
</span>

</div>

<div class="row">

<span>
Udhari
</span>

<span>
₹${money(
      billData.pendingAmount
    )}
</span>

</div>

<div class="line"></div>

<div class="footer">

<div>
धन्यवाद 🙏
</div>

<div>
SHIVAM MEDICAL STORE
</div>

<div>
Hatuniya
</div>

</div>

</div>

<script>

window.onload = function() {

setTimeout(
function() {
window.print();
},
300
);

};

window.onafterprint = function() {

setTimeout(
function() {
window.close();
},
300
);

};

</script>

</body>

</html>
`);

    printWindow.document.close();
  };

  // =====================================================
  // AUTO FOCUS BARCODE
  // =====================================================

  useEffect(() => {
    setTimeout(() => {
      barcodeRef.current?.focus();
    }, 100);
  }, []);

  // =====================================================
  // RETURN
  // =====================================================

  return (
    <div className="billingPage">

      {/* HEADER */}

      <div className="billingHeader">

        <div>
          <h1>
            🧾 Billing
          </h1>

          <span>
            Shivam Medical ERP
          </span>
        </div>

        <button
          type="button"
          onClick={goBack}
          className="headerBack"
        >
          ⬅️ Dashboard
        </button>

      </div>

      {/* CUSTOMER + BARCODE */}

      <div className="compactGrid">

        {/* CUSTOMER */}

        <div className="compactBox">

          <div className="boxTitle">
            👤 Customer
          </div>

          <div className="customerRow">

            <div className="suggestionWrap">

              <input
                placeholder="Customer Name"
                value={customer}
                onChange={(e) => {
                  setCustomer(
                    e.target.value
                  );

                  setShowCustomerSuggestions(
                    true
                  );
                }}
                onFocus={() =>
                  setShowCustomerSuggestions(
                    true
                  )
                }
                className="compactInput"
              />

              {showCustomerSuggestions &&
                filteredCustomers.length >
                  0 && (
                  <div className="suggestions">

                    {filteredCustomers.map(
                      (
                        item,
                        index
                      ) => (
                        <button
                          type="button"
                          key={index}
                          onClick={() =>
                            selectCustomer(
                              item
                            )
                          }
                        >
                          👤{" "}
                          {
                            item.customer
                          }

                          {item.mobile
                            ? ` • ${item.mobile}`
                            : ""}
                        </button>
                      )
                    )}

                  </div>
                )}

            </div>

            <input
              placeholder="Mobile"
              value={mobile}
              onChange={(e) =>
                setMobile(
                  e.target.value
                )
              }
              className="compactInput"
            />

          </div>

        </div>

        {/* BARCODE */}

        <div className="compactBox">

          <div className="boxTitle">
            📷 Barcode
          </div>

          <div className="barcodeRow">

            <input
              ref={barcodeRef}
              autoFocus
              placeholder="Scan Barcode"
              value={barcode}
              onChange={(e) =>
                setBarcode(
                  e.target.value
                )
              }
              onKeyDown={
                handleBarcodeKeyDown
              }
              className="compactInput barcodeInput"
            />

            <button
              type="button"
              onClick={
                searchBarcode
              }
              className="barcodeButton"
            >
              🔍 Search
            </button>

          </div>

        </div>

      </div>

      {/* MEDICINE */}

      <div className="compactBox">

        <div className="boxTitle">
          💊 Medicine
        </div>

        <div className="medicineRow">

          <select
            value={medicine}
            onChange={(e) => {
              setMedicine(
                e.target.value
              );

              setTimeout(() => {
                qtyRef.current?.focus();
              }, 50);
            }}
            className="compactInput medicineSelect"
          >

            <option value="">
              Select Medicine
            </option>

            {currentStock.map(
              (
                item,
                index
              ) => (
                <option
                  key={index}
                  value={
                    item.medicine
                  }
                >
                  {
                    item.medicine
                  }
                  {" • Stock: "}
                  {
                    item.quantity ||
                    0
                  }
                </option>
              )
            )}

          </select>

          <input
            ref={qtyRef}
            type="number"
            min="1"
            placeholder="Qty"
            value={quantity}
            onChange={(e) =>
              setQuantity(
                e.target.value
              )
            }
            onKeyDown={
              handleQtyKeyDown
            }
            className="compactInput qtyInput"
          />

        </div>

        {selectedItem && (
          <div className="medicineInfo">

            <span>
              📦 Stock:
              <b>
                {" "}
                {
                  selectedItem.quantity
                }
              </b>
            </span>

            <span>
              💰 Sale:
              <b>
                ₹
                {
                  saleRate.toFixed(
                    2
                  )
                }
              </b>
            </span>

            <span>
              🏷️ MRP:
              <b>
                ₹
                {Number(
                  selectedItem.mrp ||
                    0
                ).toFixed(2)}
              </b>
            </span>

            <span>
              🔢 Barcode:
              <b>
                {" "}
                {
                  selectedItem.barcode ||
                  "-"
                }
              </b>
            </span>

          </div>
        )}

        {/* ADD BUTTON */}

        <button
          type="button"
          onClick={
            addMedicineToCart
          }
          className="addMedicineButton"
        >
          ➕ Add Medicine
        </button>

      </div>

      {/* =================================================
          CART
      ================================================= */}

      <div className="cartBox">

        <div className="cartHeader">

          <div>
            🛒 Bill Medicines
            {" "}
            <span>
              ({cart.length})
            </span>
          </div>

          {cart.length > 0 && (
            <button
              type="button"
              onClick={
                clearCart
              }
              className="clearButton"
            >
              🗑️ Clear
            </button>
          )}

        </div>

        {cart.length === 0 ? (
          <div className="emptyCart">
            📦 अभी कोई Medicine Add नहीं है।
            <br />
            Barcode Scan करें और Quantity डालकर Enter दबाएँ।
          </div>
        ) : (
          <div className="cartList">

            {cart.map(
              (
                item,
                index
              ) => (
                <div
                  key={
                    item.cartId
                  }
                  className="cartRow"
                >

                  <div className="cartNumber">
                    {index + 1}
                  </div>

                  <div className="cartMedicine">
                    <b>
                      {
                        item.medicine
                      }
                    </b>

                    <small>
                      {
                        item.company ||
                        ""
                      }

                      {item.barcode
                        ? ` • ${item.barcode}`
                        : ""}
                    </small>
                  </div>

                  <div>
                    Qty
                    <b>
                      {" "}
                      {
                        item.quantity
                      }
                    </b>
                  </div>

                  <div>
                    ₹
                    {
                      Number(
                        item.saleRate
                      ).toFixed(2)
                    }
                  </div>

                  <div className="cartAmount">
                    ₹
                    {
                      Number(
                        item.amount
                      ).toFixed(2)
                    }
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      removeCartItem(
                        item.cartId
                      )
                    }
                    className="removeButton"
                  >
                    ✕
                  </button>

                </div>
              )
            )}

          </div>
        )}

      </div>

      {/* PAYMENT */}

      <div className="compactBox">

        <div className="boxTitle">
          💵 Payment
        </div>

        <div className="paymentRow">

          <button
            type="button"
            onClick={() =>
              changePaymentType(
                "cash"
              )
            }
            className={
              paymentType ===
              "cash"
                ? "paymentBtn cash active"
                : "paymentBtn cash"
            }
          >
            💵 नकद
          </button>

          <button
            type="button"
            onClick={() =>
              changePaymentType(
                "credit"
              )
            }
            className={
              paymentType ===
              "credit"
                ? "paymentBtn credit active"
                : "paymentBtn credit"
            }
          >
            ⚠️ उधारी
          </button>

          {paymentType ===
            "credit" && (
            <input
              type="number"
              min="0"
              step="0.01"
              placeholder="Paid ₹"
              value={
                paidAmount
              }
              onChange={(e) =>
                setPaidAmount(
                  e.target.value
                )
              }
              className="compactInput paidInput"
            />
          )}

        </div>

      </div>

      {/* TOTAL */}

      <div className="totalBox">

        <div>
          <span>
            Total
          </span>

          <strong>
            ₹
            {totalAmount.toFixed(
              2
            )}
          </strong>
        </div>

        <div>
          <span>
            Paid
          </span>

          <b>
            ₹
            {calculatedPaid.toFixed(
              2
            )}
          </b>
        </div>

        <div>
          <span>
            Udhari
          </span>

          <b
            className={
              pendingAmount >
              0
                ? "pending"
                : "paid"
            }
          >
            ₹
            {pendingAmount.toFixed(
              2
            )}
          </b>
        </div>

        <div>
          <span>
            Medicines
          </span>

          <b>
            {cart.length}
          </b>
        </div>

      </div>

      {/* OLD BILLS */}

      {customerBills.length >
        0 && (
        <div className="oldBills">

          <div className="oldBillsTitle">
            📜 {customer} के पुराने Bills
          </div>

          <div className="oldBillsList">

            {customerBills.map(
              (
                bill,
                index
              ) => (
                <div
                  key={index}
                  className="oldBillRow"
                >

                  <span>
                    🧾{" "}
                    <b>
                      {
                        bill.billNumber ||
                        "-"
                      }
                    </b>
                  </span>

                  <span>
                    {
                      bill.date ||
                      "-"
                    }
                  </span>

                  <span>
                    {
                      bill.time ||
                      ""
                    }
                  </span>

                  <span>
                    ₹
                    {Number(
                      bill.total ||
                        0
                    ).toFixed(
                      2
                    )}
                  </span>

                </div>
              )
            )}

          </div>

        </div>
      )}

      {/* ACTION BUTTONS */}

      <div className="actionRow">

        <button
          type="button"
          onClick={
            saveBill
          }
          className="saveButton"
        >
          🧾 Generate & Save Bill
        </button>

        <button
          type="button"
          onClick={() =>
            printBill()
          }
          className="printButton"
        >
          🖨️ Print Bill
        </button>

        <button
          type="button"
          onClick={
            goBack
          }
          className="dashboardButton"
        >
          ⬅️ Dashboard
        </button>

      </div>

      {/* LAST BILL */}

      {lastBill && (
        <div className="lastBill">

          <span>
            ✅ Last Bill:
            {" "}
            <b>
              {
                lastBill.billNumber
              }
            </b>
          </span>

          <button
            type="button"
            onClick={() =>
              printBill(
                lastBill
              )
            }
          >
            🖨️ Print
          </button>

        </div>
      )}

      {/* =================================================
          STYLE
      ================================================= */}

      <style>{`

        * {
          box-sizing: border-box;
        }

        .billingPage {
          min-height: 100vh;
          padding: 12px;
          background: #f2f5f9;
          font-family: Arial, sans-serif;
        }

        .billingHeader {
          background:
            linear-gradient(
              135deg,
              #6a1b9a,
              #ab47bc
            );

          color: white;
          padding: 12px 15px;
          border-radius: 10px;
          margin-bottom: 10px;

          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
        }

        .billingHeader h1 {
          margin: 0;
          font-size: 21px;
        }

        .billingHeader span {
          font-size: 11px;
          opacity: .9;
        }

        .headerBack {
          border: none;
          background: white;
          color: #6a1b9a;
          padding: 8px 11px;
          border-radius: 7px;
          font-weight: bold;
          cursor: pointer;
        }

        .compactGrid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }

        .compactBox,
        .cartBox {
          background: white;
          padding: 11px;
          border-radius: 9px;
          margin-bottom: 10px;

          box-shadow:
            0 2px 6px
            rgba(0,0,0,.06);
        }

        .boxTitle {
          font-size: 14px;
          font-weight: bold;
          color: #444;
          margin-bottom: 7px;
        }

        .customerRow {
          display: grid;
          grid-template-columns: 1.3fr 1fr;
          gap: 7px;
        }

        .barcodeRow {
          display: grid;
          grid-template-columns: 1fr auto;
          gap: 7px;
        }

        .medicineRow {
          display: grid;
          grid-template-columns: 1fr 100px;
          gap: 7px;
        }

        .compactInput {
          width: 100%;
          padding: 9px;
          border: 1px solid #ccc;
          border-radius: 7px;
          font-size: 13px;
          outline: none;
          background: white;
        }

        .compactInput:focus {
          border-color: #6a1b9a;

          box-shadow:
            0 0 0 2px
            rgba(106,27,154,.08);
        }

        .barcodeInput {
          border: 2px solid #3949ab;
        }

        .barcodeButton {
          border: none;
          background: #3949ab;
          color: white;
          padding: 0 13px;
          border-radius: 7px;
          font-weight: bold;
          cursor: pointer;
          white-space: nowrap;
        }

        .medicineInfo {
          display: flex;
          flex-wrap: wrap;
          gap: 8px 18px;
          margin-top: 8px;
          padding: 8px;
          background: #e3f2fd;
          border-radius: 7px;
          font-size: 11px;
          color: #444;
        }

        .suggestionWrap {
          position: relative;
        }

        .suggestions {
          position: absolute;
          left: 0;
          right: 0;
          top: 100%;
          background: white;
          border: 1px solid #ddd;
          border-radius: 7px;
          z-index: 100;
          max-height: 160px;
          overflow-y: auto;

          box-shadow:
            0 4px 12px
            rgba(0,0,0,.15);
        }

        .suggestions button {
          width: 100%;
          text-align: left;
          padding: 9px;
          border: none;
          border-bottom: 1px solid #eee;
          background: white;
          cursor: pointer;
          font-size: 12px;
        }

        .suggestions button:hover {
          background: #f3e5f5;
        }

        .addMedicineButton {
          width: 100%;
          margin-top: 9px;
          padding: 11px;
          border: none;
          border-radius: 7px;
          background: #00897b;
          color: white;
          font-weight: bold;
          cursor: pointer;
          font-size: 14px;
        }

        .cartHeader {
          display: flex;
          justify-content: space-between;
          align-items: center;

          font-size: 14px;
          font-weight: bold;
          color: #6a1b9a;

          margin-bottom: 8px;
        }

        .cartHeader span {
          color: #555;
        }

        .clearButton {
          border: none;
          background: #ffebee;
          color: #c62828;
          padding: 6px 10px;
          border-radius: 6px;
          font-weight: bold;
          cursor: pointer;
        }

        .emptyCart {
          padding: 18px;
          text-align: center;
          color: #777;
          background: #fafafa;
          border-radius: 7px;
          font-size: 12px;
          line-height: 1.8;
        }

        .cartList {
          overflow-x: auto;
        }

        .cartRow {
          display: grid;

          grid-template-columns:
            30px
            minmax(150px, 1fr)
            65px
            75px
            90px
            35px;

          gap: 7px;

          align-items: center;

          padding: 8px 4px;

          border-bottom:
            1px solid #eee;

          font-size: 11px;

          min-width: 500px;
        }

        .cartNumber {
          color: #777;
          font-weight: bold;
        }

        .cartMedicine b {
          display: block;
          color: #222;
        }

        .cartMedicine small {
          display: block;
          color: #777;
          margin-top: 2px;
          font-size: 9px;
        }

        .cartAmount {
          font-weight: bold;
          color: #2e7d32;
        }

        .removeButton {
          border: none;
          background: #ffebee;
          color: #d32f2f;
          border-radius: 5px;
          padding: 6px;
          cursor: pointer;
          font-weight: bold;
        }

        .paymentRow {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 7px;
        }

        .paymentBtn {
          padding: 10px;
          border-radius: 7px;
          font-weight: bold;
          cursor: pointer;
          background: white;
          font-size: 13px;
        }

        .paymentBtn.cash {
          color: #2e7d32;
          border: 1px solid #81c784;
        }

        .paymentBtn.cash.active {
          background: #e8f5e9;
          border: 2px solid #2e7d32;
        }

        .paymentBtn.credit {
          color: #d32f2f;
          border: 1px solid #ef9a9a;
        }

        .paymentBtn.credit.active {
          background: #ffebee;
          border: 2px solid #d32f2f;
        }

        .paidInput {
          grid-column: 1 / -1;
        }

        .totalBox {
          background:
            linear-gradient(
              135deg,
              #e8f5e9,
              #f1f8e9
            );

          border-radius: 9px;
          padding: 11px;
          margin-bottom: 10px;

          display: grid;
          grid-template-columns:
            repeat(4, 1fr);

          gap: 8px;
        }

        .totalBox div {
          background: white;
          padding: 8px;
          border-radius: 7px;
          text-align: center;
        }

        .totalBox span {
          display: block;
          font-size: 10px;
          color: #777;
          margin-bottom: 3px;
        }

        .totalBox strong {
          color: #2e7d32;
          font-size: 18px;
        }

        .totalBox b {
          font-size: 14px;
        }

        .pending {
          color: #d32f2f;
        }

        .paid {
          color: #2e7d32;
        }

        .oldBills {
          background: white;
          padding: 10px;
          border-radius: 9px;
          margin-bottom: 10px;

          box-shadow:
            0 2px 6px
            rgba(0,0,0,.06);
        }

        .oldBillsTitle {
          font-size: 13px;
          font-weight: bold;
          color: #6a1b9a;
          margin-bottom: 6px;
        }

        .oldBillsList {
          max-height: 120px;
          overflow-y: auto;
        }

        .oldBillRow {
          display: grid;
          grid-template-columns:
            1.4fr 1fr 1fr 1fr;

          gap: 5px;

          padding: 6px 3px;

          border-bottom:
            1px solid #eee;

          font-size: 10px;
        }

        .actionRow {
          display: grid;
          grid-template-columns:
            2fr 1fr 1fr;

          gap: 7px;
          margin-top: 5px;
        }

        .saveButton,
        .printButton,
        .dashboardButton {
          border: none;
          padding: 11px;
          border-radius: 7px;
          font-weight: bold;
          font-size: 13px;
          cursor: pointer;
        }

        .saveButton {
          background: #6a1b9a;
          color: white;
        }

        .printButton {
          background: #1565c0;
          color: white;
        }

        .dashboardButton {
          background: #555;
          color: white;
        }

        .lastBill {
          margin-top: 8px;
          background: #e8f5e9;
          border: 1px solid #a5d6a7;
          padding: 8px;
          border-radius: 7px;

          display: flex;
          justify-content: space-between;
          align-items: center;

          font-size: 11px;
        }

        .lastBill button {
          border: none;
          background: #2e7d32;
          color: white;
          padding: 6px 9px;
          border-radius: 5px;
          cursor: pointer;
          font-weight: bold;
        }

        @media (max-width: 700px) {

          .billingPage {
            padding: 8px;
          }

          .compactGrid {
            grid-template-columns: 1fr;
            gap: 0;
          }

          .customerRow {
            grid-template-columns:
              1fr 1fr;
          }

          .totalBox {
            grid-template-columns:
              1fr 1fr;
          }

          .actionRow {
            grid-template-columns:
              1fr;
          }

        }

        @media (max-width: 450px) {

          .customerRow {
            grid-template-columns:
              1fr;
          }

          .medicineRow {
            grid-template-columns:
              1fr 80px;
          }

          .totalBox strong {
            font-size: 16px;
          }

          .oldBillRow {
            grid-template-columns:
              1fr 1fr;
          }

        }

      `}</style>

    </div>
  );
}

export default Billing;
